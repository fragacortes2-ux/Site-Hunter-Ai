# SiteHunter AI

Plataforma de prospecção: pesquisa estabelecimentos reais no **Google Places**, verifica se têm site oficial, calcula um **Lead Score (0–100)**, organiza os melhores como leads em um **CRM** e gera mensagens de abordagem com **IA** (você revisa e envia manualmente).

Stack: Next.js 15 (App Router) · TypeScript · Tailwind CSS 3 · PostgreSQL · Prisma 6 · login próprio (bcrypt + sessão JWT em cookie httpOnly).

---

## 1. Estado do projeto (leia antes de usar)

> **Aviso honesto:** o ambiente onde este código foi escrito **bloqueia o npm (erro 403)**. Por isso o projeto **nunca foi instalado, compilado (`next build`) nem aberto no navegador**. Tudo que está marcado como "testado" abaixo foi testado de forma isolada, como descrito. O primeiro `npm install` e `npm run build` na sua máquina são, na prática, o primeiro teste real do conjunto — se algo falhar, copie a mensagem de erro e me envie.

### Implementado (código escrito)

| Área | O que existe |
|---|---|
| Conta | Cadastro, login, logout, exclusão de conta e dados (LGPD), limite de tentativas de login, proteção CSRF por verificação de origem |
| Pesquisa | Segmento, nome da empresa, cidade, estado, bairro/região, raio (1–50 km), paginação do Google (até 60 resultados) |
| Dados por empresa | Nome, categoria, endereço, cidade/UF, telefone, WhatsApp (só se divulgado em link público), Instagram/Facebook (só se aparecerem em links públicos), site, avaliação, nº de avaliações, fonte, data. O que não existe aparece como **"Não informado"** |
| Verificação de sites | `SEM SITE IDENTIFICADO`, `POSSUI SITE`, `SITE INDISPONÍVEL`, `VERIFICAÇÃO PENDENTE`; teste HTTP com proteção contra SSRF; links de Instagram/Facebook/Linktree/iFood etc. **não** contam como site; busca extra opcional (Brave ou Google Programmable Search) |
| Lead Score | 0–100 com detalhamento por critério; faixas 80–100 / 60–79 / 40–59 / 0–39 |
| Painel | Totais, taxa sem site, gráficos (situação do site, faixas de score, pesquisas por dia, funil de leads), melhores oportunidades, lembretes |
| Resultados | Tabela com filtros (só sem site, com telefone, com Instagram, segmento, cidade, estado, score mínimo, ordenação), paginação, página de detalhes, **exportação CSV** (respeita filtros) |
| CRM | Salvar lead, status (novo / contato realizado / interessado / cliente / perdido), observações, data do contato, lembretes, excluir lead, CSV de leads |
| IA | Análise da oportunidade, mensagem de WhatsApp, mensagem de Instagram, modelos de site; provedores: OpenAI, Anthropic ou compatível com OpenAI; texto editável, **nunca enviado automaticamente** |
| Controle de custos | Limites por pesquisa, por dia, por mês (Google), de IA e de buscas extras — todos no `.env` |
| Banco | PostgreSQL via Prisma; histórico de pesquisas; migração SQL inicial |

### O que foi testado (e como)

| Verificação | Resultado | Limite da verificação |
|---|---|---|
| 29 testes unitários (Lead Score, classificador de URLs/sites, SSRF, CSV, telefone) | Passaram | Lógica pura |
| 27 testes de integração do núcleo (pesquisa → Places → verificação de site → score → gravação; paginação; raio; erros do Google; limites; IA OpenAI/Anthropic/compatível; Brave/CSE) | Passaram | Usam **`fetch` simulado e banco em memória**. Provam a lógica e o formato das requisições segundo a documentação, **não** que o Google/OpenAI respondem como esperado com a sua chave |
| `migration.sql` aplicado em PostgreSQL 16 real e comparado ao `schema.prisma` (tabelas, colunas, obrigatoriedade, enums, índices, chaves estrangeiras) | Idêntico | Não foi aplicado pelo Prisma CLI |
| Checagem estática de tipos com TypeScript 6 | Sem erros | Feita com **declarações falsas (stubs)** de Next/React/Prisma/Zod; não substitui o `next build` |

### O que **não** foi testado

- `npm install`, `npm run build`, `npm run dev` e a execução do app.
- A interface no navegador (layout, responsividade, formulários) e os fluxos de login/sessão/cookies.
- Consultas Prisma reais (filtros, upsert, groupBy), rotas de API e exportação CSV rodando de ponta a ponta.
- Chamadas **reais** ao Google Places, OpenAI, Anthropic, Brave. Nenhum resultado desta plataforma foi obtido de APIs reais durante o desenvolvimento.
- Windows.

### O que depende de configuração externa

| Recurso | Necessário para | Sem isso |
|---|---|---|
| PostgreSQL + `DATABASE_URL` | Tudo | App não funciona |
| `AUTH_SECRET` | Login | Não é possível entrar |
| `GOOGLE_PLACES_API_KEY` (com cobrança ativa no Google Cloud) | Pesquisar empresas | A pesquisa fica **desativada** — o sistema nunca simula resultados |
| `AI_PROVIDER` + `AI_MODEL` + chave | Análises e mensagens | Painel de IA mostra aviso; o resto funciona |
| `SEARCH_PROVIDER` + chave (opcional) | Confirmar "sem site" também por busca na web | "Sem site identificado" passa a valer **somente para o cadastro do Google**, e isso aparece na tela |

---

## 2. Instalar e executar no Windows (passo a passo)

Todos os comandos abaixo são no **PowerShell**. Para abrir: tecle `Windows`, digite `PowerShell`, Enter.

### Passo 1 — Instalar o Node.js

1. Baixe o **Node.js 22 LTS** em https://nodejs.org e instale (Next, Next, Finish).
2. **Feche e abra o PowerShell de novo** e confira:
   ```powershell
   node -v
   npm -v
   ```
   `node -v` deve mostrar `v22.x.x` (mínimo `v20.9`).

> Se o PowerShell disser que "a execução de scripts foi desabilitada" ao rodar `npm`, rode uma vez:
> ```powershell
> Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
> ```

### Passo 2 — Ter um PostgreSQL (escolha UMA opção)

**Opção A — Docker Desktop (mais simples)**
1. Instale o Docker Desktop (https://www.docker.com/products/docker-desktop/) e abra-o até aparecer "Engine running".
2. Na pasta do projeto:
   ```powershell
   docker compose up -d
   ```
   Isso cria o banco `sitehunter` (usuário `sitehunter`, senha `sitehunter`, porta 5432). O `DATABASE_URL` padrão do `.env.example` já serve.

**Opção B — PostgreSQL instalado no Windows**
1. Baixe o instalador em https://www.postgresql.org/download/windows/ e instale (anote a **senha do usuário `postgres`** e a porta, normalmente 5432).
2. Crie o banco e o usuário (troque `SUA_SENHA_FORTE`):
   ```powershell
   & "C:\Program Files\PostgreSQL\16\bin\psql.exe" -U postgres -c "CREATE USER sitehunter WITH PASSWORD 'SUA_SENHA_FORTE';"
   & "C:\Program Files\PostgreSQL\16\bin\psql.exe" -U postgres -c "CREATE DATABASE sitehunter OWNER sitehunter;"
   ```
   (ajuste `16` para a versão instalada; ele pedirá a senha do `postgres`).
3. No `.env` (passo 4) use: `DATABASE_URL="postgresql://sitehunter:SUA_SENHA_FORTE@localhost:5432/sitehunter?schema=public"`

### Passo 3 — Abrir a pasta do projeto

Extraia o `.zip`, entre na pasta no Explorer, clique na barra de endereço, digite `powershell` e Enter. Ou:
```powershell
cd C:\caminho\para\sitehunter-ai
```

### Passo 4 — Criar o arquivo `.env`

```powershell
Copy-Item .env.example .env
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```
Copie o texto gerado, abra o `.env` no Bloco de Notas (`notepad .env`) e cole em `AUTH_SECRET="..."`. Deixe as chaves de API vazias por enquanto (passos 7 e 8). Salve.

### Passo 5 — Instalar as dependências e criar as tabelas

```powershell
npm install
npm run db:deploy
```
Se `npm run db:deploy` falhar por algum motivo da migração, use a alternativa (deriva as tabelas direto do `schema.prisma`):
```powershell
npm run db:push
```
> Use **um** dos dois no mesmo banco, não os dois.

### Passo 6 — Rodar

```powershell
npm run dev
```
Abra http://localhost:3000, clique em **Cadastre-se** e crie sua conta (senha com 10+ caracteres). Para parar o servidor: `Ctrl + C`.

### Passo 7 — Configurar o Google Places (obrigatório para pesquisar)

1. Acesse https://console.cloud.google.com e crie um projeto.
2. Ative a **cobrança** do projeto (o Google exige cartão; verifique os **preços e a franquia gratuita vigentes** na página da Places API — eles mudam).
3. Menu **APIs e serviços → Biblioteca**, procure **"Places API (New)"** e clique em **Ativar**. (Tem que ser a *New*, não a antiga "Places API".)
4. **APIs e serviços → Credenciais → Criar credenciais → Chave de API**.
5. Clique na chave → **Restrições de API → Restringir chave → marque apenas "Places API (New)"**. Salve.
6. **Faturamento → Orçamentos e alertas**: crie um orçamento mensal com alertas. Em **APIs e serviços → Places API (New) → Cotas**, defina um limite diário de requisições. Isso protege o seu cartão além dos limites do app.
7. Cole a chave no `.env`: `GOOGLE_PLACES_API_KEY="AIza..."`
8. Pare (`Ctrl + C`) e inicie (`npm run dev`) o servidor de novo.

> Cada pesquisa usa de 1 a 3 requisições (20 resultados por requisição), mais 1 se você informar raio. O pedido inclui campos de contato/site, que o Google cobra em faixa superior à dos campos básicos.

### Passo 8 — Configurar a IA (necessário para as mensagens)

**OpenAI**
1. https://platform.openai.com → crie uma chave em *API keys* (e adicione crédito/cobrança).
2. No `.env`:
   ```
   AI_PROVIDER="openai"
   AI_MODEL="gpt-4o-mini"
   OPENAI_API_KEY="sk-..."
   ```
   `AI_MODEL` precisa ser um modelo **disponível na sua conta**; se der "modelo não encontrado", troque pelo nome exato que aparece no painel da OpenAI.

**Outras opções:** `AI_PROVIDER="anthropic"` (use `ANTHROPIC_API_KEY` e `AI_MODEL`) ou `AI_PROVIDER="openai_compatible"` (use `AI_BASE_URL`, `AI_COMPATIBLE_API_KEY`, `AI_MODEL`). Chaves ficam só no servidor.

### Passo 9 (opcional) — Busca extra de sites

Sem ela, "sem site identificado" significa "sem site no cadastro do Google". Para reforçar: `SEARCH_PROVIDER="brave"` + `BRAVE_SEARCH_API_KEY` (https://brave.com/search/api/) ou `SEARCH_PROVIDER="google_cse"` + `GOOGLE_CSE_API_KEY` + `GOOGLE_CSE_ID`. Confira a disponibilidade e os termos atuais do provedor escolhido.

### Passo 10 — Rodar os testes

```powershell
npm run test:all
```
Roda os 56 testes descritos na seção 1 (exigem Node 22.6 ou superior para executar TypeScript direto).

### Problemas comuns no Windows

| Sintoma | Solução |
|---|---|
| `npm` não é reconhecido | Feche e reabra o PowerShell após instalar o Node |
| Erro de política de execução | Comando do Passo 1 |
| `ECONNREFUSED 127.0.0.1:5432` / `Can't reach database server` | O PostgreSQL não está rodando: abra o Docker Desktop e rode `docker compose up -d`, ou inicie o serviço do PostgreSQL |
| Porta 5432 já em uso (Docker + PostgreSQL instalado) | Use só um; ou mude a porta no `docker-compose.yml` e no `DATABASE_URL` |
| `EPERM` ao rodar `prisma generate` | Pare o `npm run dev` antes de instalar/gerar; feche programas que travam a pasta `node_modules` |
| Não consigo entrar / "AUTH_SECRET não configurado" | Preencha `AUTH_SECRET` (32+ caracteres) e reinicie o servidor |
| "O Google negou o acesso" | Confira: Places API **(New)** ativada, cobrança ativa, restrição da chave inclui Places API (New) |
| Tela de login volta sempre ao entrar, após `npm start` | Use `COOKIE_SECURE="false"` no `.env` quando rodar em `http://localhost` com `npm start` |
| Erros durante `npm run build` | Envie a mensagem completa para eu corrigir (a compilação real nunca foi executada) |

---

## 3. Publicar na internet

### Opção 1 — Vercel + banco gerenciado (Neon, Supabase, Railway…)

1. Crie um PostgreSQL gerenciado e copie a string de conexão.
2. Aplique as tabelas **do seu computador** apontando para esse banco:
   ```powershell
   $env:DATABASE_URL="postgresql://usuario:senha@host/banco?sslmode=require"
   npm run db:deploy
   ```
3. Suba o código para um repositório **privado** no GitHub (o `.gitignore` já exclui o `.env`).
4. Na Vercel: *Add New → Project*, importe o repositório e cadastre as variáveis do `.env.example` (`DATABASE_URL`, `AUTH_SECRET`, `GOOGLE_PLACES_API_KEY`, `AI_*`, limites…). Deixe `COOKIE_SECURE` vazio (em produção vira `true`).
5. Faça o deploy. O comando de build (`prisma generate && next build`) já está no `package.json`.
6. Pesquisas podem levar até ~90 s: **verifique o tempo máximo de execução de funções do seu plano** (o código pede até 120 s; se o plano permitir menos, reduza `MAX_RESULTS_PER_SEARCH`).
7. Depois de criar sua conta, defina `ALLOW_REGISTRATION="false"` para fechar novos cadastros (ou deixe aberto se for vender acesso).

### Opção 2 — Servidor próprio (VPS, Render, Railway…)

```bash
npm ci
npm run db:deploy
npm run build
npm start        # porta 3000; coloque Nginx/Caddy com HTTPS na frente
```

---

## 4. Responsabilidade, termos e LGPD

- **Termos do Google Places:** o Google restringe armazenar conteúdo da API além de certos prazos. Por isso o sistema apaga automaticamente empresas **não salvas como lead** após `GOOGLE_DATA_RETENTION_DAYS` (padrão 30). Dados de empresas salvas como lead permanecem no CRM; **revise os termos vigentes da Google Maps Platform com seu advogado antes de comercializar**, pois isso afeta o uso comercial.
- **LGPD:** só são usados dados comerciais públicos de empresas. Telefones de MEIs/profissionais autônomos podem ser dados pessoais: use para contato comercial legítimo, ofereça forma de recusa e respeite pedidos de não contato. Não há disparos automáticos: toda mensagem é revisada e enviada por você. Cada usuário pode excluir a conta e todos os seus dados em *Configurações*.
- **Lead Score** é uma heurística de priorização, não garantia de interesse.
- **"Sem site identificado"** não é certeza de que a empresa não tem site. Confirme manualmente antes de abordar (botão *Reverificar* na página da empresa).
- Se a busca extra encontrar um site candidato que responde, a empresa é marcada como "Possui site" com a observação de que deve ser confirmado.

## 5. Limitações conhecidas

- Limite de tentativas (login/pesquisa/IA por minuto) é **em memória por processo**: em hospedagem com várias instâncias/serverless, troque por Redis/Upstash. Os limites diários e mensais são persistidos no banco e valem em qualquer cenário.
- A verificação HTTP resolve o DNS antes de conectar (proteção SSRF), mas o `fetch` resolve de novo na conexão; não cobre ataques sofisticados de *DNS rebinding*. Rode em um ambiente sem acesso a redes internas sensíveis.
- Sites que bloqueiam robôs podem aparecer como existentes (HTTP 401/403/429) mesmo sem conteúdo útil; sites com certificado inválido ou lentos ficam como "Verificação pendente".
- O Google não informa Instagram, Facebook nem WhatsApp: eles só aparecem quando o link está no cadastro do Google ou em resultados de busca extra.
- Não há recuperação de senha por e-mail nem verificação de e-mail.

## 6. Estrutura de pastas

```
sitehunter-ai/
├─ prisma/
│  ├─ schema.prisma                 modelo de dados
│  └─ migrations/…/migration.sql    tabelas iniciais
├─ src/
│  ├─ middleware.ts                 proteção de rotas e CSRF
│  ├─ app/
│  │  ├─ login/ · register/         telas públicas
│  │  ├─ (app)/                     telas autenticadas
│  │  │  ├─ dashboard · search · companies (+ [id]) · leads · history · settings
│  │  └─ api/                       auth, search, companies, leads, reminders, ai, export, stats, account, health
│  ├─ components/                   interface (AppShell, gráficos, LeadCard, AiPanel…)
│  └─ lib/
│     ├─ prospecting.ts             núcleo: busca → verificação → score → gravação
│     ├─ places.ts                  Google Places API (New)
│     ├─ siteClassifier.ts · siteVerifier.ts · ssrf.ts · webSearch.ts
│     ├─ score.ts                   Lead Score
│     ├─ ai.ts                      OpenAI / Anthropic / compatível
│     └─ limits.ts · env.ts · auth.ts · filters.ts · queries.ts · csv.ts …
├─ tests/                           unitários + integration/ (fetch e banco simulados)
├─ docker-compose.yml               PostgreSQL local (opcional)
└─ .env.example
```
