import { test } from "node:test";
import assert from "node:assert/strict";
import { escapeCsvCell, toCsv } from "../src/lib/csv.ts";

test("escapa aspas, ponto e vírgula e quebras de linha", () => {
  assert.equal(escapeCsvCell('Casa "Boa"'), '"Casa ""Boa"""');
  assert.equal(escapeCsvCell("a;b"), '"a;b"');
  assert.equal(escapeCsvCell("a\nb"), '"a\nb"');
  assert.equal(escapeCsvCell(null), "");
  assert.equal(escapeCsvCell(42), "42");
});

test("neutraliza injeção de fórmulas", () => {
  assert.equal(escapeCsvCell("=1+1"), "'=1+1");
  assert.equal(escapeCsvCell("+55 11 99999"), "'+55 11 99999");
  assert.equal(escapeCsvCell("@cmd"), "'@cmd");
  assert.equal(escapeCsvCell("-2"), "'-2");
});

test("toCsv gera BOM, cabeçalho e linhas com CRLF", () => {
  const csv = toCsv(
    [{ n: "Padaria X", t: "1198" }],
    [
      { header: "Nome", value: (r) => r.n },
      { header: "Telefone", value: (r) => r.t },
    ],
  );
  assert.equal(csv, "﻿Nome;Telefone\r\nPadaria X;1198\r\n");
});
