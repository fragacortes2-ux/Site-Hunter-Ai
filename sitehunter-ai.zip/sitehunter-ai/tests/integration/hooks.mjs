// Resolve "@/..." e imports sem extensão para arquivos .ts, e troca pacotes ausentes
// (next, zod, @prisma/client) por stubs mínimos. Usado só nos testes de integração.
import { pathToFileURL, fileURLToPath } from "node:url";
import path from "node:path";
import fs from "node:fs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const stubs = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "stubs");
const STUB_MODULES = {
  "next/server": "next-server.mjs",
  zod: "zod.mjs",
  "@prisma/client": "prisma-client.mjs",
};

function tryFile(base) {
  for (const candidate of [base, `${base}.ts`, path.join(base, "index.ts")]) {
    if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate;
  }
  return null;
}

export async function resolve(specifier, context, nextResolve) {
  if (STUB_MODULES[specifier]) {
    return { url: pathToFileURL(path.join(stubs, STUB_MODULES[specifier])).href, shortCircuit: true };
  }
  if (specifier.startsWith("@/")) {
    const file = tryFile(path.join(root, "src", specifier.slice(2)));
    if (file) return { url: pathToFileURL(file).href, shortCircuit: true };
  }
  if ((specifier.startsWith("./") || specifier.startsWith("../")) && context.parentURL) {
    const file = tryFile(path.resolve(path.dirname(fileURLToPath(context.parentURL)), specifier));
    if (file) return { url: pathToFileURL(file).href, shortCircuit: true };
  }
  return nextResolve(specifier, context);
}
