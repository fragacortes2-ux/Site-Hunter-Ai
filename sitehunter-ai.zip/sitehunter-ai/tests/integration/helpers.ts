// Utilitários dos testes de integração: fetch simulado e banco em memória.
export type FetchCall = { url: string; init: RequestInit & { headers?: Record<string, string> } };

export function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
}

export function mockFetch(handler: (url: string, init: FetchCall["init"]) => Response | Promise<Response>) {
  const calls: FetchCall[] = [];
  const original = globalThis.fetch;
  globalThis.fetch = (async (input: string | URL, init?: FetchCall["init"]) => {
    const url = typeof input === "string" ? input : input.toString();
    calls.push({ url, init: init ?? {} });
    return handler(url, init ?? {});
  }) as typeof fetch;
  return {
    calls,
    restore() {
      globalThis.fetch = original;
    },
  };
}

type Row = Record<string, any>;

/** Banco em memória com apenas os métodos do Prisma usados pelo núcleo de prospecção. */
export function createFakePrisma() {
  const db: { searches: Row[]; companies: Row[]; placesUsage: Row[] } = { searches: [], companies: [], placesUsage: [] };
  let seq = 0;
  const fake = {
    _db: db,
    reset() {
      db.searches.length = 0;
      db.companies.length = 0;
      db.placesUsage.length = 0;
    },
    search: {
      count: async () => db.searches.length,
      aggregate: async () => ({ _sum: { placesRequests: db.searches.reduce((s, r) => s + (r.placesRequests ?? 0), 0) } }),
      create: async ({ data }: { data: Row }) => {
        const row = { id: `s${(seq += 1)}`, createdAt: new Date(), ...data };
        db.searches.push(row);
        return row;
      },
    },
    placesUsage: {
      aggregate: async () => ({ _sum: { requests: db.placesUsage.reduce((s, r) => s + (r.requests ?? 0), 0) } }),
      create: async ({ data }: { data: Row }) => {
        db.placesUsage.push(data);
        return data;
      },
    },
    company: {
      deleteMany: async () => ({ count: 0 }),
      findMany: async ({ where }: { where: Row }) => db.companies.filter((c) => where.placeId.in.includes(c.placeId)),
      findFirst: async ({ where }: { where: Row }) => db.companies.find((c) => c.id === where.id) ?? null,
      update: async ({ where, data }: { where: Row; data: Row }) => {
        const row = db.companies.find((c) => c.id === where.id)!;
        Object.assign(row, data);
        return row;
      },
      upsert: async ({ where, create, update }: { where: Row; create: Row; update: Row }) => {
        const key = where.userId_placeId;
        const existing = db.companies.find((c) => c.userId === key.userId && c.placeId === key.placeId);
        if (existing) {
          for (const [k, v] of Object.entries(update)) if (v !== undefined) existing[k] = v;
          return existing;
        }
        const row = { id: `c${(seq += 1)}`, discoveredAt: new Date(), ...create };
        db.companies.push(row);
        return row;
      },
    },
    $transaction: async (ops: Promise<unknown>[]) => Promise.all(ops),
  };
  return fake;
}
