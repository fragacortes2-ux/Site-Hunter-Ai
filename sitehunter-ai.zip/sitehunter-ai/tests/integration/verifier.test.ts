// Testes do verificador de sites e da busca extra, com fetch simulado.
import { test } from "node:test";
import assert from "node:assert/strict";
import { createFakePrisma, jsonResponse, mockFetch } from "./helpers.ts";

(globalThis as any).__fakePrisma = createFakePrisma();

const { checkReachable } = await import("@/lib/siteVerifier");
const { webSearch } = await import("@/lib/webSearch");

const IP = "http://93.184.216.34";

test("HTTP 200 -> ok", async () => {
  const m = mockFetch(() => new Response("<html>", { status: 200 }));
  try {
    const r = await checkReachable(`${IP}/`);
    assert.equal(r.state, "ok");
    assert.equal(r.httpStatus, 200);
    assert.equal(m.calls[0].init.method, "GET");
    assert.equal(m.calls[0].init.redirect, "manual");
  } finally {
    m.restore();
  }
});

test("401/403/429 (bloqueio de robô) contam como site existente", async () => {
  for (const status of [401, 403, 429]) {
    const m = mockFetch(() => new Response("", { status }));
    try {
      const r = await checkReachable(`${IP}/`);
      assert.equal(r.state, "ok", `status ${status}`);
    } finally {
      m.restore();
    }
  }
});

test("404, 410 e 5xx -> indisponível", async () => {
  for (const status of [404, 410, 500, 503]) {
    const m = mockFetch(() => new Response("", { status }));
    try {
      assert.equal((await checkReachable(`${IP}/`)).state, "unavailable", `status ${status}`);
    } finally {
      m.restore();
    }
  }
});

test("segue redirecionamentos e informa a URL final", async () => {
  const m = mockFetch((url) =>
    url === `${IP}/` ? new Response(null, { status: 301, headers: { location: "/home" } }) : new Response("ok", { status: 200 }),
  );
  try {
    const r = await checkReachable(`${IP}/`);
    assert.equal(r.state, "ok");
    assert.equal(r.finalUrl, `${IP}/home`);
    assert.equal(m.calls.length, 2);
  } finally {
    m.restore();
  }
});

test("SSRF: redirecionamento para rede interna é bloqueado e não é requisitado", async () => {
  const m = mockFetch((url) =>
    url === `${IP}/` ? new Response(null, { status: 302, headers: { location: "http://169.254.169.254/latest/meta-data/" } }) : new Response("segredo", { status: 200 }),
  );
  try {
    const r = await checkReachable(`${IP}/`);
    assert.equal(r.state, "unknown");
    assert.match(r.note, /bloqueado/i);
    assert.equal(m.calls.length, 1, "o destino interno não pode ser acessado");
  } finally {
    m.restore();
  }
});

test("SSRF: endereços internos informados diretamente são bloqueados", async () => {
  const m = mockFetch(() => new Response("segredo", { status: 200 }));
  try {
    for (const url of ["http://127.0.0.1/", "http://10.0.0.5/", "http://192.168.0.10/admin", "http://[::1]/", "http://localhost/"]) {
      const r = await checkReachable(url);
      assert.equal(r.state, "unknown", url);
    }
    assert.equal(m.calls.length, 0);
  } finally {
    m.restore();
  }
});

test("redirecionamento infinito termina como desconhecido", async () => {
  const m = mockFetch(() => new Response(null, { status: 302, headers: { location: "/loop" } }));
  try {
    const r = await checkReachable(`${IP}/`);
    assert.equal(r.state, "unknown");
    assert.match(r.note, /redirecionamentos/i);
  } finally {
    m.restore();
  }
});

test("tempo esgotado, conexão recusada e certificado inválido", async () => {
  const cases: Array<[Error, string, RegExp]> = [
    [Object.assign(new Error("t"), { name: "TimeoutError" }), "unknown", /Tempo esgotado/],
    [Object.assign(new TypeError("fetch failed"), { cause: { code: "ECONNREFUSED" } }), "unavailable", /recusada/],
    [Object.assign(new TypeError("fetch failed"), { cause: { code: "CERT_HAS_EXPIRED" } }), "unknown", /Certificado/],
    [Object.assign(new TypeError("fetch failed"), { cause: { code: "ENOTFOUND" } }), "unavailable", /DNS/],
  ];
  for (const [err, state, note] of cases) {
    const m = mockFetch(() => {
      throw err;
    });
    try {
      const r = await checkReachable(`${IP}/`);
      assert.equal(r.state, state);
      assert.match(r.note, note);
    } finally {
      m.restore();
    }
  }
});

test("URL inválida", async () => {
  const r = await checkReachable("não é url");
  assert.equal(r.state, "unknown");
});

test("Brave Search: monta a requisição e converte os resultados", async () => {
  process.env.SEARCH_PROVIDER = "brave";
  process.env.BRAVE_SEARCH_API_KEY = "brave-key";
  const m = mockFetch(() =>
    jsonResponse({
      web: {
        results: [
          { url: "https://www.pizzariabella.com.br/", title: "Pizzaria Bella", description: "Cardápio" },
          { title: "sem url" },
        ],
      },
    }),
  );
  try {
    const results = await webSearch('"Pizzaria Bella" Campinas');
    assert.equal(results.length, 1);
    assert.deepEqual(results[0], { url: "https://www.pizzariabella.com.br/", title: "Pizzaria Bella", snippet: "Cardápio" });
    const u = new URL(m.calls[0].url);
    assert.equal(u.origin + u.pathname, "https://api.search.brave.com/res/v1/web/search");
    assert.equal(u.searchParams.get("q"), '"Pizzaria Bella" Campinas');
    assert.equal(u.searchParams.get("country"), "br");
    assert.equal(m.calls[0].init.headers?.["X-Subscription-Token"], "brave-key");
  } finally {
    m.restore();
    process.env.SEARCH_PROVIDER = "none";
  }
});

test("Google Programmable Search: monta a requisição", async () => {
  process.env.SEARCH_PROVIDER = "google_cse";
  process.env.GOOGLE_CSE_API_KEY = "cse-key";
  process.env.GOOGLE_CSE_ID = "cse-id";
  const m = mockFetch(() => jsonResponse({ items: [{ link: "https://example.com.br", title: "Ex", snippet: "s" }] }));
  try {
    const results = await webSearch("Barbearia X Campinas");
    assert.equal(results[0].url, "https://example.com.br");
    const u = new URL(m.calls[0].url);
    assert.equal(u.origin + u.pathname, "https://www.googleapis.com/customsearch/v1");
    assert.equal(u.searchParams.get("key"), "cse-key");
    assert.equal(u.searchParams.get("cx"), "cse-id");
  } finally {
    m.restore();
    process.env.SEARCH_PROVIDER = "none";
  }
});

test("busca extra sem chave configurada falha de forma explícita", async () => {
  process.env.SEARCH_PROVIDER = "brave";
  delete process.env.BRAVE_SEARCH_API_KEY;
  try {
    await assert.rejects(() => webSearch("x"), /não configurado/);
  } finally {
    process.env.SEARCH_PROVIDER = "none";
  }
});
