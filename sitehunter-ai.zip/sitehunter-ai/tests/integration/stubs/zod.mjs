export class ZodError extends Error {
  constructor(issues = []) {
    super("ZodError");
    this.issues = issues;
  }
}
export const z = {};
