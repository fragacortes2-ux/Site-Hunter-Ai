export class NextResponse extends Response {
  static json(data, init = {}) {
    return new NextResponse(JSON.stringify(data), { status: init.status ?? 200, headers: { "content-type": "application/json", ...(init.headers ?? {}) } });
  }
}
export class NextRequest extends Request {}
