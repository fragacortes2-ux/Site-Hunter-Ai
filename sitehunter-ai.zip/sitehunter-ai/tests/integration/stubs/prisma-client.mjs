// Entrega o banco em memória criado pelo teste (globalThis.__fakePrisma).
export class PrismaClient {
  constructor() {
    return globalThis.__fakePrisma;
  }
}
export const Prisma = {};
