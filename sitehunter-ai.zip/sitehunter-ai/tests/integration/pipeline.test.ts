// Teste de integração do núcleo de pesquisa (Google Places -> verificação -> score -> gravação).
// Usa fetch simulado e banco em memória. NÃO chama o Google de verdade: valida a lógica do
// projeto e o formato das requisições conforme a documentação da Places API (New).
import { test, beforeEach, after } from "node:test";
import assert from "node:assert/strict";
import { createFakePrisma, jsonResponse, mockFetch } from "./helpers.ts";

const fake = createFakePrisma();
(globalThis as any).__fakePrisma = fake;

process.env.GOOGLE_PLACES_API_KEY = "chave-de-teste";
process.env.SEARCH_PROVIDER = "none";
process.env.MAX_PLACES_REQUESTS_PER_MONTH = "2000";

const { runSearch } = await import("@/lib/prospecting");

const OK_SITE = "http://93.184.216.34/"; // IP literal: dispensa DNS no teste
const DEAD_SITE = "http://198.51.100.7/";
const SLOW_SITE = "http://203.0.113.9/";

function place(id: string, name: string, extra: Record<string, unknown> = {}) {
  return {
    id,
    displayName: { text: name },
    formattedAddress: `Rua ${name}, 10 - Cambuí, Campinas - SP`,
    addressComponents: [
      { longText: "Cambuí", shortText: "Cambuí", types: ["sublocality_level_1", "sublocality"] },
      { longText: "Campinas", shortText: "Campinas", types: ["administrative_area_level_2", "political"] },
      { longText: "São Paulo", shortText: "SP", types: ["administrative_area_level_1", "political"] },
    ],
    nationalPhoneNumber: "(19) 99876-5432",
    primaryTypeDisplayName: { text: "Pizzaria" },
    rating: 4.6,
    userRatingCount: 180,
    googleMapsUri: `https://maps.google.com/?cid=${id}`,
    businessStatus: "OPERATIONAL",
    ...extra,
  };
}

let restore: (() => void) | null = null;
beforeEach(() => {
  fake.reset();
  process.env.GOOGLE_PLACES_API_KEY = "chave-de-teste";
});
after(() => restore?.());

function installFetch(placesPages: Array<Record<string, unknown>>) {
  let page = 0;
  const m = mockFetch((url) => {
    if (url.startsWith("https://places.googleapis.com/")) {
      const body = placesPages[Math.min(page, placesPages.length - 1)];
      page += 1;
      return jsonResponse(body);
    }
    if (url.startsWith(OK_SITE)) return new Response("<html></html>", { status: 200 });
    if (url.startsWith(DEAD_SITE)) return new Response("erro", { status: 503 });
    if (url.startsWith(SLOW_SITE)) throw Object.assign(new Error("timeout"), { name: "TimeoutError" });
    return new Response("not found", { status: 404 });
  });
  restore = m.restore;
  return m;
}

test("pesquisa classifica sites, calcula score e grava no banco", async () => {
  const m = installFetch([
    {
      places: [
        place("A", "Pizzaria Bella", { websiteUri: OK_SITE }),
        place("B", "Pizzaria Sem Site"),
        place("C", "Pizzaria Insta", { websiteUri: "https://www.instagram.com/pizza_insta/?hl=pt" }),
        place("D", "Pizzaria Fora do Ar", { websiteUri: DEAD_SITE }),
        place("E", "Pizzaria Fechada", { businessStatus: "CLOSED_PERMANENTLY" }),
        place("F", "Pizzaria Lenta", { websiteUri: SLOW_SITE }),
      ],
    },
  ]);
  try {
    const summary = await runSearch("u1", { segment: "Pizzarias", city: "Campinas", state: "SP" } as any);

    assert.equal(summary.total, 5, "o local fechado definitivamente deve ser descartado");
    assert.equal(summary.hasSite, 1);
    assert.equal(summary.noSite, 2);
    assert.equal(summary.unavailable, 1);
    assert.equal(summary.pending, 1);
    assert.equal(summary.newCount, 5);
    assert.equal(summary.placesRequests, 1);
    assert.match(summary.searchVerification, /Somente Google Places/);

    const byName = Object.fromEntries(fake._db.companies.map((c) => [c.name, c]));
    assert.equal(byName["Pizzaria Bella"].websiteStatus, "HAS_SITE");
    assert.equal(byName["Pizzaria Bella"].website, OK_SITE);
    assert.ok(byName["Pizzaria Bella"].leadScore <= 25, "empresa com site fica com score limitado");
    assert.equal(byName["Pizzaria Sem Site"].websiteStatus, "NO_SITE");
    assert.equal(byName["Pizzaria Sem Site"].website, null);
    assert.equal(byName["Pizzaria Sem Site"].verificationMethod, "places-only");
    assert.equal(byName["Pizzaria Insta"].websiteStatus, "NO_SITE");
    assert.equal(byName["Pizzaria Insta"].instagram, "https://www.instagram.com/pizza_insta");
    assert.equal(byName["Pizzaria Fora do Ar"].websiteStatus, "UNAVAILABLE");
    assert.equal(byName["Pizzaria Lenta"].websiteStatus, "PENDING");
    assert.ok(byName["Pizzaria Insta"].leadScore > byName["Pizzaria Sem Site"].leadScore, "Instagram público aumenta o score");
    assert.equal(byName["Pizzaria Sem Site"].city, "Campinas");
    assert.equal(byName["Pizzaria Sem Site"].state, "SP");
    assert.equal(byName["Pizzaria Sem Site"].neighborhood, "Cambuí");
    assert.equal(byName["Pizzaria Sem Site"].source, "Google Places");
    assert.equal(fake._db.searches.length, 1);
    assert.equal(fake._db.searches[0].noSiteCount, 2);

    // Formato da requisição à Places API (New)
    const placesCall = m.calls.find((c) => c.url.startsWith("https://places.googleapis.com/"))!;
    assert.equal(placesCall.url, "https://places.googleapis.com/v1/places:searchText");
    assert.equal(placesCall.init.method, "POST");
    assert.equal(placesCall.init.headers?.["X-Goog-Api-Key"], "chave-de-teste");
    const mask = placesCall.init.headers?.["X-Goog-FieldMask"] ?? "";
    for (const f of ["places.id", "places.displayName", "places.websiteUri", "places.nationalPhoneNumber", "places.userRatingCount", "nextPageToken"]) {
      assert.ok(mask.split(",").includes(f), `field mask deve incluir ${f}`);
    }
    const body = JSON.parse(String(placesCall.init.body));
    assert.equal(body.textQuery, "Pizzarias em Campinas, SP");
    assert.equal(body.languageCode, "pt-BR");
    assert.equal(body.regionCode, "BR");
    assert.equal(body.pageSize, 20);
    assert.equal(body.pageToken, undefined);
  } finally {
    m.restore();
  }
});

test("paginação: segue nextPageToken até o limite e não duplica locais", async () => {
  const first = Array.from({ length: 20 }, (_, i) => place(`P${i}`, `Loja ${i}`));
  const second = [place("P19", "Loja 19"), ...Array.from({ length: 4 }, (_, i) => place(`Q${i}`, `Outra ${i}`))];
  const m = installFetch([
    { places: first, nextPageToken: "TOKEN-2" },
    { places: second },
  ]);
  try {
    const summary = await runSearch("u1", { segment: "Lojas", city: "Campinas" } as any);
    assert.equal(summary.total, 24, "P19 repetido não pode contar duas vezes");
    assert.equal(summary.placesRequests, 2);
    const secondBody = JSON.parse(String(m.calls[1].init.body));
    assert.equal(secondBody.pageToken, "TOKEN-2");
    assert.equal(secondBody.textQuery, "Lojas em Campinas");
  } finally {
    m.restore();
  }
});

test("raio: geocodifica a região e usa locationBias circular", async () => {
  const m = installFetch([
    { places: [{ id: "G", displayName: { text: "Centro" }, location: { latitude: -22.9, longitude: -47.06 } }] },
    { places: [place("R1", "Barbearia Raio")] },
  ]);
  try {
    const summary = await runSearch("u1", { segment: "Barbearias", city: "Campinas", state: "SP", neighborhood: "Cambuí", radiusKm: 5 } as any);
    assert.equal(summary.placesRequests, 2);
    assert.equal(m.calls[0].init.headers?.["X-Goog-FieldMask"], "places.location");
    assert.equal(JSON.parse(String(m.calls[0].init.body)).textQuery, "Cambuí, Campinas, SP, Brasil");
    const body = JSON.parse(String(m.calls[1].init.body));
    assert.deepEqual(body.locationBias, { circle: { center: { latitude: -22.9, longitude: -47.06 }, radius: 5000 } });
    assert.equal(body.textQuery, "Barbearias em Cambuí, Campinas, SP");
  } finally {
    m.restore();
  }
});

test("redescobrir a mesma empresa não apaga Instagram já encontrado", async () => {
  const m = installFetch([{ places: [place("C", "Pizzaria Insta", { websiteUri: "https://instagram.com/pizza_insta" })] }]);
  try {
    await runSearch("u1", { segment: "Pizzarias", city: "Campinas" } as any);
    m.restore();
    const m2 = installFetch([{ places: [place("C", "Pizzaria Insta")] }]); // agora o Google não traz mais o link
    const again = await runSearch("u1", { segment: "Pizzarias", city: "Campinas" } as any);
    m2.restore();
    assert.equal(again.newCount, 0);
    assert.equal(fake._db.companies.length, 1);
    assert.equal(fake._db.companies[0].instagram, "https://www.instagram.com/pizza_insta");
  } finally {
    m.restore();
  }
});

test("erros do Google viram mensagens claras e nada é gravado", async () => {
  const m = mockFetch(() => jsonResponse({ error: { code: 403, message: "Places API (New) has not been used in project 123", status: "PERMISSION_DENIED" } }, 403));
  try {
    await assert.rejects(
      () => runSearch("u1", { segment: "Pizzarias", city: "Campinas" } as any),
      (e: any) => {
        assert.equal(e.status, 502);
        assert.match(e.message, /Places API \(New\)/);
        assert.match(e.message, /cobrança/);
        return true;
      },
    );
    assert.equal(fake._db.companies.length, 0);
    assert.equal(fake._db.searches.length, 0);
  } finally {
    m.restore();
  }
});

test("sem GOOGLE_PLACES_API_KEY a pesquisa é recusada sem chamar a rede nem inventar dados", async () => {
  delete process.env.GOOGLE_PLACES_API_KEY;
  const m = mockFetch(() => {
    throw new Error("não deveria chamar a rede");
  });
  try {
    await assert.rejects(
      () => runSearch("u1", { segment: "Pizzarias", city: "Campinas" } as any),
      (e: any) => e.status === 503 && /GOOGLE_PLACES_API_KEY/.test(e.message),
    );
    assert.equal(m.calls.length, 0);
    assert.equal(fake._db.companies.length, 0);
  } finally {
    m.restore();
  }
});

test("teto mensal de requisições ao Google bloqueia a pesquisa antes de consultar", async () => {
  process.env.MAX_PLACES_REQUESTS_PER_MONTH = "1";
  const m = mockFetch(() => {
    throw new Error("não deveria chamar a rede");
  });
  try {
    await assert.rejects(
      () => runSearch("u1", { segment: "Pizzarias", city: "Campinas" } as any), // estima 2 páginas > teto 1
      (e: any) => e.status === 429 && /Teto mensal/.test(e.message),
    );
    assert.equal(m.calls.length, 0);
  } finally {
    process.env.MAX_PLACES_REQUESTS_PER_MONTH = "2000";
    m.restore();
  }
});

test("limite diário de pesquisas por usuário", async () => {
  process.env.MAX_SEARCHES_PER_DAY = "2";
  fake._db.searches.push({ id: "x1", placesRequests: 1 }, { id: "x2", placesRequests: 1 });
  const m = mockFetch(() => {
    throw new Error("não deveria chamar a rede");
  });
  try {
    await assert.rejects(
      () => runSearch("u1", { segment: "Pizzarias", city: "Campinas" } as any),
      (e: any) => e.status === 429 && /Limite de 2 pesquisas/.test(e.message),
    );
  } finally {
    delete process.env.MAX_SEARCHES_PER_DAY;
    m.restore();
  }
});
