import { test } from "node:test";
import assert from "node:assert/strict";
import { computeLeadScore, tierFromScore, reviewsPoints, segmentRelevance } from "../src/lib/score.ts";

test("empresa sem site, com telefone, Instagram, WhatsApp e muitas avaliações é prioritária", () => {
  const r = computeLeadScore({
    websiteStatus: "NO_SITE",
    phone: "(11) 98765-4321",
    whatsapp: "5511987654321",
    instagram: "https://www.instagram.com/barbearia_x",
    ratingCount: 250,
    rating: 4.8,
    segment: "Barbearias",
    category: "Barbearia",
    address: "Rua A, 10",
    mapsUrl: "https://maps.google.com/?cid=1",
  });
  assert.equal(r.tier, "PRIORITY");
  assert.ok(r.score >= 80 && r.score <= 100);
  assert.equal(r.breakdown.reduce((s, i) => s + i.points, 0), r.score);
});

test("pontuação máxima possível é 100", () => {
  const r = computeLeadScore({
    websiteStatus: "NO_SITE",
    phone: "1",
    whatsapp: "1",
    instagram: "1",
    facebook: "1",
    ratingCount: 1000,
    rating: 5,
    segment: "Restaurantes",
    category: "Restaurante",
    address: "x",
    mapsUrl: "x",
  });
  assert.equal(r.score, 100);
});

test("empresa com site confirmado nunca passa de 25 (baixa prioridade)", () => {
  const r = computeLeadScore({
    websiteStatus: "HAS_SITE",
    phone: "1",
    whatsapp: "1",
    instagram: "1",
    facebook: "1",
    ratingCount: 1000,
    rating: 5,
    segment: "Restaurantes",
    category: "Restaurante",
    address: "x",
    mapsUrl: "x",
  });
  assert.ok(r.score <= 25);
  assert.equal(r.tier, "LOW");
});

test("sem site mas sem nenhum canal de contato pontua menos que sem site com telefone", () => {
  const base = { websiteStatus: "NO_SITE" as const, ratingCount: 30, segment: "Padarias" };
  const semCanal = computeLeadScore(base).score;
  const comTelefone = computeLeadScore({ ...base, phone: "(11) 3333-4444" }).score;
  assert.ok(comTelefone > semCanal);
});

test("ordem entre situações do site: sem site > indisponível > pendente > possui", () => {
  const mk = (websiteStatus: "NO_SITE" | "UNAVAILABLE" | "PENDING" | "HAS_SITE") =>
    computeLeadScore({ websiteStatus, phone: "1" }).score;
  assert.ok(mk("NO_SITE") > mk("UNAVAILABLE"));
  assert.ok(mk("UNAVAILABLE") > mk("PENDING"));
  assert.ok(mk("PENDING") > mk("HAS_SITE"));
});

test("faixas de classificação", () => {
  assert.equal(tierFromScore(100).tier, "PRIORITY");
  assert.equal(tierFromScore(80).tier, "PRIORITY");
  assert.equal(tierFromScore(79).tier, "GOOD");
  assert.equal(tierFromScore(60).tier, "GOOD");
  assert.equal(tierFromScore(59).tier, "MODERATE");
  assert.equal(tierFromScore(40).tier, "MODERATE");
  assert.equal(tierFromScore(39).tier, "LOW");
  assert.equal(tierFromScore(0).tier, "LOW");
});

test("pontos por volume de avaliações", () => {
  assert.equal(reviewsPoints(null), 0);
  assert.equal(reviewsPoints(2), 0);
  assert.equal(reviewsPoints(3), 3);
  assert.equal(reviewsPoints(10), 6);
  assert.equal(reviewsPoints(20), 8);
  assert.equal(reviewsPoints(50), 11);
  assert.equal(reviewsPoints(100), 13);
  assert.equal(reviewsPoints(200), 15);
});

test("relevância do segmento ignora acentos e maiúsculas", () => {
  assert.equal(segmentRelevance("Salões de Beleza"), 8);
  assert.equal(segmentRelevance("CLÍNICAS"), 8);
  assert.equal(segmentRelevance("Padarias"), 6);
  assert.equal(segmentRelevance("Fábrica de parafusos"), 4);
  assert.equal(segmentRelevance(null, null), 4);
});
