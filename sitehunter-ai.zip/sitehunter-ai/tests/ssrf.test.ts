import { test } from "node:test";
import assert from "node:assert/strict";
import { isPrivateAddress } from "../src/lib/ssrf.ts";

test("bloqueia endereços internos IPv4", () => {
  for (const ip of ["127.0.0.1", "10.1.2.3", "172.16.0.1", "172.31.255.255", "192.168.1.10", "169.254.169.254", "0.0.0.0", "100.64.0.1"]) {
    assert.equal(isPrivateAddress(ip), true, ip);
  }
});

test("permite endereços públicos IPv4", () => {
  for (const ip of ["8.8.8.8", "172.32.0.1", "172.15.255.255", "200.147.67.142", "1.1.1.1"]) {
    assert.equal(isPrivateAddress(ip), false, ip);
  }
});

test("IPv6: bloqueia loopback, ULA, link-local e IPv4 mapeado privado", () => {
  for (const ip of ["::1", "fc00::1", "fd12:3456::1", "fe80::1", "::ffff:127.0.0.1", "::ffff:10.0.0.1"]) {
    assert.equal(isPrivateAddress(ip), true, ip);
  }
  assert.equal(isPrivateAddress("2606:4700:4700::1111"), false);
  assert.equal(isPrivateAddress("::ffff:8.8.8.8"), false);
});

test("entrada que não é IP é tratada como inválida/bloqueada", () => {
  assert.equal(isPrivateAddress("not-an-ip"), true);
});
