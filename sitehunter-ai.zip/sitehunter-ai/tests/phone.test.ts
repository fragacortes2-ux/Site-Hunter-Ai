import { test } from "node:test";
import assert from "node:assert/strict";
import { toBrazilDigits, isLikelyBrazilMobile, whatsappLink } from "../src/lib/phone.ts";

test("toBrazilDigits normaliza formatos comuns", () => {
  assert.equal(toBrazilDigits("(11) 98765-4321"), "5511987654321");
  assert.equal(toBrazilDigits("+55 11 98765-4321"), "5511987654321");
  assert.equal(toBrazilDigits("(11) 3333-4444"), "551133334444");
  assert.equal(toBrazilDigits("123"), null);
  assert.equal(toBrazilDigits(null), null);
});

test("isLikelyBrazilMobile distingue celular de fixo", () => {
  assert.equal(isLikelyBrazilMobile("(11) 98765-4321"), true);
  assert.equal(isLikelyBrazilMobile("(11) 3333-4444"), false);
});

test("whatsappLink monta link wa.me com texto codificado", () => {
  assert.equal(whatsappLink("5511987654321"), "https://wa.me/5511987654321");
  assert.equal(whatsappLink("5511987654321", "Olá! Tudo bem?"), "https://wa.me/5511987654321?text=Ol%C3%A1!%20Tudo%20bem%3F");
  assert.equal(whatsappLink("12"), null);
});
