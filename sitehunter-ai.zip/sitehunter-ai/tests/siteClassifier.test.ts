import { test } from "node:test";
import assert from "node:assert/strict";
import {
  classifyUrl,
  normalizeUrl,
  instagramProfileUrl,
  facebookPageUrl,
  whatsappNumberFromUrl,
  extractSocials,
  nameTokens,
  pickCandidatesFromSearch,
} from "../src/lib/siteClassifier.ts";

test("normalizeUrl adiciona https e rejeita esquemas perigosos", () => {
  assert.equal(normalizeUrl("exemplo.com.br"), "https://exemplo.com.br/");
  assert.equal(normalizeUrl("  http://exemplo.com.br/menu  "), "http://exemplo.com.br/menu");
  assert.equal(normalizeUrl("javascript:alert(1)"), null);
  assert.equal(normalizeUrl("ftp://exemplo.com"), null);
  assert.equal(normalizeUrl("localhost"), null);
  assert.equal(normalizeUrl("https://user:pass@exemplo.com"), null);
  assert.equal(normalizeUrl(""), null);
  assert.equal(normalizeUrl(null), null);
});

test("classifyUrl separa site próprio de rede social e diretório", () => {
  assert.equal(classifyUrl("https://www.pizzariabella.com.br").kind, "official");
  assert.equal(classifyUrl("https://instagram.com/pizzariabella").kind, "social");
  assert.equal(classifyUrl("https://m.facebook.com/pizzariabella").kind, "social");
  assert.equal(classifyUrl("https://linktr.ee/pizzariabella").kind, "social");
  assert.equal(classifyUrl("https://wa.me/5511987654321").platform, "whatsapp");
  assert.equal(classifyUrl("https://www.ifood.com.br/delivery/sp/bella").kind, "directory");
  assert.equal(classifyUrl("https://www.tripadvisor.com.br/Restaurant").kind, "directory");
  assert.equal(classifyUrl("não é url").kind, "invalid");
});

test("domínio que apenas termina com nome de rede social não é confundido", () => {
  assert.equal(classifyUrl("https://notinstagram.com").kind, "official");
  assert.equal(classifyUrl("https://meufacebook.com.br").kind, "official");
});

test("instagramProfileUrl só aceita perfis", () => {
  assert.equal(instagramProfileUrl("https://www.instagram.com/barbearia_x/"), "https://www.instagram.com/barbearia_x");
  assert.equal(instagramProfileUrl("instagram.com/barbearia_x?igshid=abc"), "https://www.instagram.com/barbearia_x");
  assert.equal(instagramProfileUrl("https://www.instagram.com/p/ABC123/"), null);
  assert.equal(instagramProfileUrl("https://www.instagram.com/"), null);
  assert.equal(instagramProfileUrl("https://pizzaria.com.br"), null);
});

test("facebookPageUrl ignora links de compartilhamento", () => {
  assert.equal(facebookPageUrl("https://www.facebook.com/pizzariabella/"), "https://www.facebook.com/pizzariabella");
  assert.equal(facebookPageUrl("https://www.facebook.com/sharer/sharer.php?u=x"), null);
  assert.equal(
    facebookPageUrl("https://www.facebook.com/profile.php?id=100012345"),
    "https://www.facebook.com/profile.php?id=100012345",
  );
});

test("whatsappNumberFromUrl extrai número de links públicos", () => {
  assert.equal(whatsappNumberFromUrl("https://wa.me/5511987654321?text=oi"), "5511987654321");
  assert.equal(whatsappNumberFromUrl("https://api.whatsapp.com/send?phone=5511987654321"), "5511987654321");
  assert.equal(whatsappNumberFromUrl("https://wa.me/message/ABCDEF"), null);
  assert.equal(whatsappNumberFromUrl("https://pizzaria.com.br"), null);
});

test("extractSocials combina várias URLs", () => {
  const s = extractSocials([
    "https://instagram.com/loja_x",
    "https://facebook.com/lojax",
    "https://wa.me/5521999998888",
  ]);
  assert.equal(s.instagram, "https://www.instagram.com/loja_x");
  assert.equal(s.facebook, "https://www.facebook.com/lojax");
  assert.equal(s.whatsapp, "5521999998888");
});

test("nameTokens remove termos genéricos e acentos", () => {
  assert.deepEqual(nameTokens("Pizzaria Bella Nápoli"), ["bella", "napoli"]);
  assert.deepEqual(nameTokens("Barbearia do Zé"), []);
  assert.deepEqual(nameTokens("Studio Ana Paula Estética"), ["ana", "paula"]);
});

test("pickCandidatesFromSearch encontra o site oficial pelo nome", () => {
  const pick = pickCandidatesFromSearch(
    [
      { url: "https://www.ifood.com.br/delivery/bella-napoli", title: "Pizzaria Bella Napoli - iFood" },
      { url: "https://www.pizzariabellanapoli.com.br/", title: "Pizzaria Bella Napoli | Cardápio" },
      { url: "https://www.instagram.com/bellanapoli_pizzaria/", title: "Bella Napoli (@bellanapoli_pizzaria)" },
      { url: "https://www.facebook.com/bellanapolipizzaria", title: "Bella Napoli Pizzaria" },
    ],
    "Pizzaria Bella Nápoli",
  );
  assert.equal(pick.official?.host, "pizzariabellanapoli.com.br");
  assert.equal(pick.instagram, "https://www.instagram.com/bellanapoli_pizzaria");
  assert.equal(pick.facebook, "https://www.facebook.com/bellanapolipizzaria");
});

test("pickCandidatesFromSearch não aceita domínio sem relação com o nome", () => {
  const pick = pickCandidatesFromSearch(
    [
      { url: "https://www.guiadepizzarias.com.br/sp", title: "As melhores pizzarias de São Paulo" },
      { url: "https://www.outronome.com.br", title: "Outra empresa qualquer" },
    ],
    "Pizzaria Bella Nápoli",
  );
  assert.equal(pick.official, null);
});

test("pickCandidatesFromSearch não adivinha quando o nome só tem termos genéricos", () => {
  const pick = pickCandidatesFromSearch([{ url: "https://www.barbearia.com.br", title: "Barbearia" }], "Barbearia");
  assert.equal(pick.official, null);
});
