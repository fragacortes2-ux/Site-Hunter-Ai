import { NextResponse, type NextRequest } from "next/server";
import { jwtVerify } from "jose";

const COOKIE = "sh_session";
const PUBLIC_PAGES = new Set(["/login", "/register"]);
const PUBLIC_API = new Set(["/api/auth/login", "/api/auth/register", "/api/health"]);

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|icon.svg).*)"],
};

async function hasValidSession(req: NextRequest): Promise<boolean> {
  const token = req.cookies.get(COOKIE)?.value;
  const secret = process.env.AUTH_SECRET || "";
  if (!token || secret.length < 32) return false;
  try {
    await jwtVerify(token, new TextEncoder().encode(secret), { algorithms: ["HS256"] });
    return true;
  } catch {
    return false;
  }
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const isApi = pathname.startsWith("/api/");

  // Proteção CSRF: requisições que alteram dados precisam vir do mesmo site.
  if (!["GET", "HEAD", "OPTIONS"].includes(req.method)) {
    const origin = req.headers.get("origin");
    const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
    if (origin) {
      let originHost = "";
      try {
        originHost = new URL(origin).host;
      } catch {
        originHost = "";
      }
      if (!host || originHost !== host) {
        return NextResponse.json({ error: "Origem da requisição não permitida." }, { status: 403 });
      }
    }
  }

  if (PUBLIC_API.has(pathname)) return NextResponse.next();

  const valid = await hasValidSession(req);

  if (isApi) {
    if (!valid) return NextResponse.json({ error: "Não autenticado." }, { status: 401 });
    return NextResponse.next();
  }

  const isPublicPage = PUBLIC_PAGES.has(pathname);
  if (!valid && !isPublicPage) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.search = "";
    return NextResponse.redirect(url);
  }
  if (valid && isPublicPage) {
    const url = req.nextUrl.clone();
    url.pathname = "/dashboard";
    url.search = "";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}
