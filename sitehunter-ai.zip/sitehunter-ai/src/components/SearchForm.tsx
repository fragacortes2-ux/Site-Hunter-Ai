"use client";

import { useState } from "react";
import Link from "next/link";
import { IconSearch } from "@/components/Icons";
import { Notice } from "@/components/ui";
import { apiRequest } from "@/lib/apiClient";
import { BR_STATES, SEGMENT_SUGGESTIONS } from "@/lib/constants";

type Summary = {
  searchId: string;
  total: number;
  newCount: number;
  noSite: number;
  hasSite: number;
  unavailable: number;
  pending: number;
  placesRequests: number;
  searchVerification: string;
  warning: string | null;
};

export type SearchDefaults = {
  segment?: string;
  companyName?: string;
  city?: string;
  state?: string;
  neighborhood?: string;
  radiusKm?: string;
};

export function SearchForm({ defaults, disabled }: { defaults: SearchDefaults; disabled: boolean }) {
  const [segment, setSegment] = useState(defaults.segment ?? "");
  const [companyName, setCompanyName] = useState(defaults.companyName ?? "");
  const [city, setCity] = useState(defaults.city ?? "");
  const [state, setState] = useState(defaults.state ?? "");
  const [neighborhood, setNeighborhood] = useState(defaults.neighborhood ?? "");
  const [radiusKm, setRadiusKm] = useState(defaults.radiusKm ?? "");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [summary, setSummary] = useState<Summary | null>(null);

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setSummary(null);
    setBusy(true);
    try {
      const result = await apiRequest<Summary>("/api/search", "POST", {
        segment,
        companyName,
        city,
        state,
        neighborhood,
        radiusKm,
      });
      setSummary(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível concluir a pesquisa.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      <form onSubmit={submit} className="card card-pad space-y-5" noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="segment">
              Segmento comercial
            </label>
            <input
              id="segment"
              className="input"
              list="segment-options"
              placeholder="Ex.: Barbearias"
              value={segment}
              onChange={(e) => setSegment(e.target.value)}
              maxLength={80}
            />
            <datalist id="segment-options">
              {SEGMENT_SUGGESTIONS.map((s) => (
                <option key={s} value={s} />
              ))}
            </datalist>
          </div>
          <div>
            <label className="label" htmlFor="companyName">
              Nome da empresa <span className="text-zinc-600">(opcional)</span>
            </label>
            <input
              id="companyName"
              className="input"
              placeholder="Ex.: Pizzaria do Zé"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              maxLength={100}
            />
          </div>
          <div>
            <label className="label" htmlFor="city">
              Cidade
            </label>
            <input
              id="city"
              className="input"
              placeholder="Ex.: Campinas"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              maxLength={80}
              required
            />
          </div>
          <div>
            <label className="label" htmlFor="state">
              Estado
            </label>
            <select id="state" className="input" value={state} onChange={(e) => setState(e.target.value)}>
              <option value="">Qualquer</option>
              {BR_STATES.map((s) => (
                <option key={s.uf} value={s.uf}>
                  {s.uf} — {s.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="neighborhood">
              Bairro ou região <span className="text-zinc-600">(opcional)</span>
            </label>
            <input
              id="neighborhood"
              className="input"
              placeholder="Ex.: Cambuí"
              value={neighborhood}
              onChange={(e) => setNeighborhood(e.target.value)}
              maxLength={80}
            />
          </div>
          <div>
            <label className="label" htmlFor="radiusKm">
              Raio em km <span className="text-zinc-600">(opcional, 1 a 50)</span>
            </label>
            <input
              id="radiusKm"
              className="input"
              type="number"
              inputMode="numeric"
              min={1}
              max={50}
              placeholder="Ex.: 5"
              value={radiusKm}
              onChange={(e) => setRadiusKm(e.target.value)}
            />
            <p className="mt-1.5 text-xs text-zinc-500">Usa uma requisição extra ao Google para localizar o centro da área.</p>
          </div>
        </div>

        {error ? <Notice tone="error">{error}</Notice> : null}

        <div className="flex flex-wrap items-center gap-3">
          <button type="submit" className="btn-primary" disabled={busy || disabled}>
            {busy ? <span className="spinner" /> : <IconSearch width={16} height={16} />}
            {busy ? "Pesquisando e verificando sites…" : "Pesquisar empresas"}
          </button>
          {busy ? <p className="text-xs text-zinc-500">Isso pode levar de 20 a 90 segundos. Não feche a página.</p> : null}
        </div>
      </form>

      {summary ? (
        <div className="card card-pad animate-fade-in space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="text-base font-semibold text-white">Pesquisa concluída</h2>
              <p className="mt-1 text-sm text-zinc-400">
                {summary.total} estabelecimento(s) encontrado(s), {summary.newCount} novo(s) na sua base.
              </p>
            </div>
            <Link href={`/companies?searchId=${summary.searchId}`} className="btn-primary">
              Ver resultados
            </Link>
          </div>
          <dl className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              ["Sem site identificado", summary.noSite],
              ["Possui site", summary.hasSite],
              ["Site indisponível", summary.unavailable],
              ["Verificação pendente", summary.pending],
            ].map(([label, value]) => (
              <div key={label as string} className="rounded-lg border border-white/[0.06] bg-ink-900 p-3">
                <dt className="text-xs text-zinc-500">{label}</dt>
                <dd className="mt-1 text-xl font-semibold text-white">{value}</dd>
              </div>
            ))}
          </dl>
          <p className="text-xs text-zinc-500">
            Método de verificação: {summary.searchVerification}. Requisições ao Google nesta pesquisa: {summary.placesRequests}.
          </p>
          {summary.warning ? <Notice tone="warn">{summary.warning}</Notice> : null}
        </div>
      ) : null}
    </div>
  );
}
