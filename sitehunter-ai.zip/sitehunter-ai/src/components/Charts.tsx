// Gráficos em SVG puro (sem bibliotecas), renderizados no servidor com os dados reais do banco.

export type ChartSegment = { label: string; value: number; color: string };

export function DonutChart({
  segments,
  centerValue,
  centerLabel,
}: {
  segments: ChartSegment[];
  centerValue: string;
  centerLabel: string;
}) {
  const total = segments.reduce((sum, s) => sum + s.value, 0);
  const r = 52;
  const circumference = 2 * Math.PI * r;
  let offset = 0;

  return (
    <div className="flex flex-col items-center gap-6 sm:flex-row">
      <div className="relative h-40 w-40 shrink-0">
        <svg
          viewBox="0 0 140 140"
          className="h-full w-full -rotate-90"
          role="img"
          aria-label={`Distribuição: ${segments.map((s) => `${s.label} ${s.value}`).join(", ")}`}
        >
          <circle cx="70" cy="70" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="16" />
          {total > 0
            ? segments
                .filter((s) => s.value > 0)
                .map((s) => {
                  const len = (s.value / total) * circumference;
                  const el = (
                    <circle
                      key={s.label}
                      cx="70"
                      cy="70"
                      r={r}
                      fill="none"
                      stroke={s.color}
                      strokeWidth="16"
                      strokeDasharray={`${len} ${circumference - len}`}
                      strokeDashoffset={-offset}
                    />
                  );
                  offset += len;
                  return el;
                })
            : null}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-2xl font-semibold text-white">{centerValue}</span>
          <span className="text-[11px] text-zinc-500">{centerLabel}</span>
        </div>
      </div>
      <ul className="w-full space-y-2.5">
        {segments.map((s) => (
          <li key={s.label} className="flex items-center justify-between gap-3 text-sm">
            <span className="flex items-center gap-2 text-zinc-300">
              <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: s.color }} />
              {s.label}
            </span>
            <span className="font-mono text-zinc-400">
              {s.value}
              {total > 0 ? <span className="ml-1.5 text-zinc-600">({Math.round((s.value / total) * 100)}%)</span> : null}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function BarList({ items }: { items: ChartSegment[] }) {
  const max = Math.max(1, ...items.map((i) => i.value));
  return (
    <ul className="space-y-3.5">
      {items.map((i) => (
        <li key={i.label}>
          <div className="mb-1.5 flex items-center justify-between text-sm">
            <span className="text-zinc-300">{i.label}</span>
            <span className="font-mono text-zinc-400">{i.value}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-white/[0.06]">
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{ width: `${(i.value / max) * 100}%`, backgroundColor: i.color }}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}

export function ColumnChart({ data }: { data: { label: string; value: number }[] }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  const width = 560;
  const height = 150;
  const pad = 22;
  const slot = width / data.length;
  const bar = Math.min(26, slot * 0.6);

  return (
    <svg
      viewBox={`0 0 ${width} ${height + pad}`}
      className="h-44 w-full"
      role="img"
      aria-label={`Pesquisas por dia: ${data.map((d) => `${d.label} ${d.value}`).join(", ")}`}
    >
      {[0.25, 0.5, 0.75, 1].map((g) => (
        <line key={g} x1="0" x2={width} y1={height - g * height} y2={height - g * height} stroke="rgba(255,255,255,0.05)" />
      ))}
      {data.map((d, i) => {
        const h = (d.value / max) * (height - 12);
        const x = i * slot + (slot - bar) / 2;
        return (
          <g key={d.label}>
            <rect x={x} y={height - h} width={bar} height={Math.max(h, d.value > 0 ? 2 : 0)} rx="4" fill="#2f6bff" opacity={d.value > 0 ? 1 : 0.2} />
            {d.value > 0 ? (
              <text x={x + bar / 2} y={height - h - 5} textAnchor="middle" fontSize="10" fill="#a1a1aa">
                {d.value}
              </text>
            ) : null}
            {i % 2 === 0 ? (
              <text x={x + bar / 2} y={height + 15} textAnchor="middle" fontSize="9.5" fill="#71717a">
                {d.label}
              </text>
            ) : null}
          </g>
        );
      })}
    </svg>
  );
}
