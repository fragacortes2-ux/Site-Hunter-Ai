export function Logo({ size = 28 }: { size?: number }) {
  return (
    <span className="inline-flex items-center gap-2.5">
      <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
        <rect width="32" height="32" rx="8" fill="#12141a" stroke="rgba(255,255,255,0.08)" />
        <circle cx="15" cy="15" r="7" fill="none" stroke="#2f6bff" strokeWidth="2.5" />
        <path d="M20.5 20.5 26 26" stroke="#2f6bff" strokeWidth="2.5" strokeLinecap="round" />
      </svg>
      <span className="text-[15px] font-semibold tracking-tight text-white">
        SiteHunter <span className="text-electric-400">AI</span>
      </span>
    </span>
  );
}
