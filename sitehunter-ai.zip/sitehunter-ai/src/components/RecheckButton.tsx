"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { IconRefresh } from "@/components/Icons";
import { apiRequest } from "@/lib/apiClient";

export function RecheckButton({ companyId }: { companyId: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function recheck() {
    setBusy(true);
    setError(null);
    try {
      await apiRequest(`/api/companies/${companyId}/recheck`, "POST");
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Não foi possível reverificar.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <span className="inline-flex flex-col items-start gap-1">
      <button type="button" onClick={recheck} disabled={busy} className="btn-ghost">
        {busy ? <span className="spinner" /> : <IconRefresh width={16} height={16} />}
        Reverificar site e dados
      </button>
      {error ? <span className="max-w-xs text-xs text-red-300">{error}</span> : null}
    </span>
  );
}
