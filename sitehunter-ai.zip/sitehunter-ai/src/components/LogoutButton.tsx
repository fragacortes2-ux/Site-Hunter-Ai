"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { IconLogout } from "@/components/Icons";
import { apiRequest } from "@/lib/apiClient";

export function LogoutButton({ className }: { className?: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function logout() {
    setBusy(true);
    try {
      await apiRequest("/api/auth/logout", "POST");
    } catch {
      // mesmo com erro de rede, segue para a tela de login
    }
    router.push("/login");
    router.refresh();
  }

  return (
    <button type="button" onClick={logout} disabled={busy} className={className ?? "btn-ghost w-full"}>
      <IconLogout width={16} height={16} />
      Sair
    </button>
  );
}
