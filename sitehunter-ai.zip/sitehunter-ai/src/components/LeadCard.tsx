"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { IconBell, IconCheck, IconTrash } from "@/components/Icons";
import { LeadBadge, Notice, ScoreBadge, WebsiteBadge } from "@/components/ui";
import { apiRequest } from "@/lib/apiClient";
import { LEAD_STATUSES, LEAD_STATUS_LABELS } from "@/lib/constants";
import { formatDateTime, instagramHandle, isoToLocalInput, localInputToIso, stripProtocol } from "@/lib/format";

export type LeadCardData = {
  id: string;
  status: string;
  notes: string;
  contactedAt: string | null;
  company: {
    id: string;
    name: string;
    category: string | null;
    city: string | null;
    state: string | null;
    phone: string | null;
    instagram: string | null;
    website: string | null;
    websiteStatus: string;
    leadScore: number;
  };
  reminders: { id: string; dueAt: string; note: string; done: boolean }[];
};

export function LeadCard({ lead }: { lead: LeadCardData }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [notes, setNotes] = useState(lead.notes);
  const [contacted, setContacted] = useState(isoToLocalInput(lead.contactedAt));
  const [reminderAt, setReminderAt] = useState("");
  const [reminderNote, setReminderNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function run(fn: () => Promise<unknown>) {
    setBusy(true);
    setError(null);
    try {
      await fn();
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ocorreu um erro.");
    } finally {
      setBusy(false);
    }
  }

  const patch = (body: Record<string, unknown>) => run(() => apiRequest(`/api/leads/${lead.id}`, "PATCH", body));

  const addReminder = () =>
    run(async () => {
      if (!reminderAt || !reminderNote.trim()) throw new Error("Informe a data/hora e a descrição do lembrete.");
      await apiRequest(`/api/leads/${lead.id}/reminders`, "POST", { dueAt: localInputToIso(reminderAt), note: reminderNote });
      setReminderAt("");
      setReminderNote("");
    });

  const toggleReminder = (id: string, done: boolean) => run(() => apiRequest(`/api/reminders/${id}`, "PATCH", { done }));
  const deleteReminder = (id: string) => run(() => apiRequest(`/api/reminders/${id}`, "DELETE"));
  const deleteLead = () => {
    if (!window.confirm(`Excluir o lead "${lead.company.name}"? A empresa continua na sua lista de resultados.`)) return;
    return run(() => apiRequest(`/api/leads/${lead.id}`, "DELETE"));
  };

  const pending = lead.reminders.filter((r) => !r.done);
  const now = Date.now();
  const notesChanged = notes !== lead.notes;

  return (
    <article className="card animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-3 p-4">
        <div className="min-w-0">
          <Link href={`/companies/${lead.company.id}`} className="block truncate text-sm font-semibold text-white hover:text-electric-300">
            {lead.company.name}
          </Link>
          <p className="mt-0.5 truncate text-xs text-zinc-500">
            {[lead.company.category, [lead.company.city, lead.company.state].filter(Boolean).join(" - ")].filter(Boolean).join(" · ")}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <LeadBadge status={lead.status} />
          <WebsiteBadge status={lead.company.websiteStatus} />
          <ScoreBadge score={lead.company.leadScore} />
          {pending.length > 0 ? (
            <span className="badge border-amber-500/30 bg-amber-500/10 text-amber-300">
              <IconBell width={12} height={12} /> {pending.length}
            </span>
          ) : null}
          <button type="button" className="btn-ghost !px-3 !py-1.5 text-xs" onClick={() => setOpen((v) => !v)} aria-expanded={open}>
            {open ? "Fechar" : "Gerenciar"}
          </button>
        </div>
      </div>

      {open ? (
        <div className="space-y-5 border-t border-white/[0.06] p-4">
          <dl className="grid gap-3 text-sm sm:grid-cols-3">
            <div>
              <dt className="text-xs text-zinc-500">Telefone</dt>
              <dd className="text-zinc-200">{lead.company.phone ?? "Não informado"}</dd>
            </div>
            <div>
              <dt className="text-xs text-zinc-500">Instagram</dt>
              <dd className="text-zinc-200">
                {lead.company.instagram ? (
                  <a href={lead.company.instagram} target="_blank" rel="noopener noreferrer" className="text-electric-300 hover:underline">
                    {instagramHandle(lead.company.instagram)}
                  </a>
                ) : (
                  "Não informado"
                )}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-zinc-500">Site</dt>
              <dd className="truncate text-zinc-200">
                {lead.company.website ? (
                  <a href={lead.company.website} target="_blank" rel="noopener noreferrer" className="text-electric-300 hover:underline">
                    {stripProtocol(lead.company.website)}
                  </a>
                ) : (
                  "Não informado"
                )}
              </dd>
            </div>
          </dl>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor={`status-${lead.id}`}>
                Status do lead
              </label>
              <select
                id={`status-${lead.id}`}
                className="input"
                value={lead.status}
                disabled={busy}
                onChange={(e) => patch({ status: e.target.value })}
              >
                {LEAD_STATUSES.map((s) => (
                  <option key={s} value={s}>
                    {LEAD_STATUS_LABELS[s]}
                  </option>
                ))}
              </select>
              <div className="mt-2 flex flex-wrap gap-2">
                <button type="button" className="btn-ghost !px-2.5 !py-1 text-xs" disabled={busy} onClick={() => patch({ status: "CONTACTED" })}>
                  Marcar contato realizado
                </button>
                <button type="button" className="btn-ghost !px-2.5 !py-1 text-xs" disabled={busy} onClick={() => patch({ status: "INTERESTED" })}>
                  Marcar interessado
                </button>
                <button type="button" className="btn-ghost !px-2.5 !py-1 text-xs" disabled={busy} onClick={() => patch({ status: "CLIENT" })}>
                  Marcar cliente
                </button>
              </div>
            </div>
            <div>
              <label className="label" htmlFor={`contacted-${lead.id}`}>
                Data do contato
              </label>
              <input
                id={`contacted-${lead.id}`}
                type="datetime-local"
                className="input"
                value={contacted}
                disabled={busy}
                onChange={(e) => {
                  setContacted(e.target.value);
                  patch({ contactedAt: e.target.value ? localInputToIso(e.target.value) : null });
                }}
              />
              <p className="mt-1.5 text-xs text-zinc-500">Último registro: {formatDateTime(lead.contactedAt)}</p>
            </div>
          </div>

          <div>
            <label className="label" htmlFor={`notes-${lead.id}`}>
              Observações
            </label>
            <textarea
              id={`notes-${lead.id}`}
              className="input min-h-24 resize-y"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              maxLength={5000}
              placeholder="Anote conversas, objeções, orçamento combinado…"
            />
            <button type="button" className="btn-primary mt-2" disabled={busy || !notesChanged} onClick={() => patch({ notes })}>
              Salvar observações
            </button>
          </div>

          <div>
            <p className="label">Lembretes de acompanhamento</p>
            {lead.reminders.length === 0 ? <p className="mb-3 text-sm text-zinc-500">Nenhum lembrete criado.</p> : null}
            <ul className="mb-3 space-y-2">
              {lead.reminders.map((r) => {
                const overdue = !r.done && new Date(r.dueAt).getTime() < now;
                return (
                  <li key={r.id} className="flex items-center gap-3 rounded-lg border border-white/[0.06] bg-ink-900 px-3 py-2">
                    <button
                      type="button"
                      aria-label={r.done ? "Reabrir lembrete" : "Concluir lembrete"}
                      disabled={busy}
                      onClick={() => toggleReminder(r.id, !r.done)}
                      className={`grid h-5 w-5 shrink-0 place-items-center rounded border ${
                        r.done ? "border-emerald-500/50 bg-emerald-500/20 text-emerald-300" : "border-white/20 text-transparent hover:border-electric-400"
                      }`}
                    >
                      <IconCheck width={13} height={13} />
                    </button>
                    <div className="min-w-0 flex-1">
                      <p className={`truncate text-sm ${r.done ? "text-zinc-500 line-through" : "text-zinc-200"}`}>{r.note}</p>
                      <p className={`text-xs ${overdue ? "text-red-300" : "text-zinc-500"}`}>
                        {formatDateTime(r.dueAt)}
                        {overdue ? " · atrasado" : ""}
                      </p>
                    </div>
                    <button type="button" aria-label="Excluir lembrete" disabled={busy} onClick={() => deleteReminder(r.id)} className="text-zinc-500 hover:text-red-300">
                      <IconTrash width={16} height={16} />
                    </button>
                  </li>
                );
              })}
            </ul>
            <div className="grid gap-2 sm:grid-cols-[200px_1fr_auto]">
              <input type="datetime-local" className="input" aria-label="Data e hora do lembrete" value={reminderAt} onChange={(e) => setReminderAt(e.target.value)} />
              <input
                className="input"
                aria-label="Descrição do lembrete"
                placeholder="Ex.: Retornar com proposta"
                value={reminderNote}
                onChange={(e) => setReminderNote(e.target.value)}
                maxLength={300}
              />
              <button type="button" className="btn-ghost" disabled={busy} onClick={addReminder}>
                Adicionar
              </button>
            </div>
          </div>

          {error ? <Notice tone="error">{error}</Notice> : null}

          <div className="flex justify-end border-t border-white/[0.06] pt-4">
            <button type="button" className="btn-danger" disabled={busy} onClick={deleteLead}>
              <IconTrash width={16} height={16} />
              Excluir lead
            </button>
          </div>
        </div>
      ) : null}
    </article>
  );
}
