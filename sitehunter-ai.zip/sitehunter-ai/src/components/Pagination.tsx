import Link from "next/link";

function windowPages(page: number, pages: number): (number | "gap")[] {
  const out: (number | "gap")[] = [];
  const show = new Set<number>([1, pages, page - 1, page, page + 1]);
  let last = 0;
  for (let p = 1; p <= pages; p += 1) {
    if (!show.has(p)) continue;
    if (p - last > 1) out.push("gap");
    out.push(p);
    last = p;
  }
  return out;
}

export function Pagination({
  page,
  pages,
  total,
  pageSize,
  hrefFor,
}: {
  page: number;
  pages: number;
  total: number;
  pageSize: number;
  hrefFor: (page: number) => string;
}) {
  if (total === 0) return null;
  const from = (page - 1) * pageSize + 1;
  const to = Math.min(total, page * pageSize);
  const item = "inline-flex h-8 min-w-8 items-center justify-center rounded-md border px-2 text-xs";
  return (
    <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
      <p className="text-xs text-zinc-500">
        Mostrando {from}–{to} de {total}
      </p>
      {pages > 1 ? (
        <nav className="flex flex-wrap items-center gap-1.5" aria-label="Paginação">
          {page > 1 ? (
            <Link href={hrefFor(page - 1)} className={`${item} border-white/10 text-zinc-300 hover:bg-white/[0.06]`}>
              ← Anterior
            </Link>
          ) : null}
          {windowPages(page, pages).map((p, i) =>
            p === "gap" ? (
              <span key={`gap-${i}`} className="px-1 text-zinc-600">
                …
              </span>
            ) : (
              <Link
                key={p}
                href={hrefFor(p)}
                aria-current={p === page ? "page" : undefined}
                className={`${item} ${
                  p === page
                    ? "border-electric-500/60 bg-electric-500/15 text-electric-300"
                    : "border-white/10 text-zinc-300 hover:bg-white/[0.06]"
                }`}
              >
                {p}
              </Link>
            ),
          )}
          {page < pages ? (
            <Link href={hrefFor(page + 1)} className={`${item} border-white/10 text-zinc-300 hover:bg-white/[0.06]`}>
              Próxima →
            </Link>
          ) : null}
        </nav>
      ) : null}
    </div>
  );
}
