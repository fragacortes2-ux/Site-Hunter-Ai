"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Notice } from "@/components/ui";
import { apiRequest } from "@/lib/apiClient";

export function DeleteAccount() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function remove(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!window.confirm("Isto apaga sua conta, leads, lembretes e pesquisas de forma definitiva. Continuar?")) return;
    setBusy(true);
    setError(null);
    try {
      await apiRequest("/api/account", "DELETE", { password });
      router.push("/login");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível excluir a conta.");
      setBusy(false);
    }
  }

  if (!open) {
    return (
      <button type="button" className="btn-danger" onClick={() => setOpen(true)}>
        Excluir minha conta e meus dados
      </button>
    );
  }

  return (
    <form onSubmit={remove} className="max-w-sm space-y-3">
      <label className="label" htmlFor="delete-password">
        Confirme sua senha
      </label>
      <input id="delete-password" type="password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
      {error ? <Notice tone="error">{error}</Notice> : null}
      <div className="flex gap-2">
        <button type="submit" className="btn-danger" disabled={busy}>
          {busy ? <span className="spinner" /> : null}
          Excluir definitivamente
        </button>
        <button type="button" className="btn-ghost" onClick={() => setOpen(false)} disabled={busy}>
          Cancelar
        </button>
      </div>
    </form>
  );
}
