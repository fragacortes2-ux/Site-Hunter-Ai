"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Logo } from "@/components/Logo";
import { LogoutButton } from "@/components/LogoutButton";
import { IconBuilding, IconClock, IconDashboard, IconMenu, IconSearch, IconSettings, IconUsers, IconX } from "@/components/Icons";

type NavItem = { href: string; label: string; Icon: typeof IconDashboard };

const NAV: NavItem[] = [
  { href: "/dashboard", label: "Painel", Icon: IconDashboard },
  { href: "/search", label: "Nova pesquisa", Icon: IconSearch },
  { href: "/companies", label: "Empresas", Icon: IconBuilding },
  { href: "/leads", label: "Leads (CRM)", Icon: IconUsers },
  { href: "/history", label: "Histórico", Icon: IconClock },
  { href: "/settings", label: "Configurações", Icon: IconSettings },
];

function NavLinks({ pathname, onNavigate }: { pathname: string; onNavigate?: () => void }) {
  return (
    <ul className="space-y-1">
      {NAV.map(({ href, label, Icon }) => {
        const active = pathname === href || pathname.startsWith(`${href}/`);
        return (
          <li key={href}>
            <Link
              href={href}
              onClick={onNavigate}
              aria-current={active ? "page" : undefined}
              className={`flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm transition ${
                active
                  ? "bg-electric-500/15 text-white shadow-[inset_0_0_0_1px_rgba(95,140,255,0.25)]"
                  : "text-zinc-400 hover:bg-white/[0.05] hover:text-zinc-100"
              }`}
            >
              <Icon className={active ? "text-electric-400" : ""} />
              {label}
            </Link>
          </li>
        );
      })}
    </ul>
  );
}

export function AppShell({ user, children }: { user: { name: string; email: string }; children: React.ReactNode }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <div className="min-h-screen lg:flex">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-white/[0.06] bg-ink-900/60 px-3 py-4 lg:sticky lg:top-0 lg:flex lg:h-screen">
        <div className="px-3 pb-5 pt-1">
          <Logo />
        </div>
        <nav className="flex-1" aria-label="Navegação principal">
          <NavLinks pathname={pathname} />
        </nav>
        <div className="mt-4 space-y-3 border-t border-white/[0.06] px-1 pt-4">
          <div className="px-2">
            <p className="truncate text-sm font-medium text-zinc-200">{user.name}</p>
            <p className="truncate text-xs text-zinc-500">{user.email}</p>
          </div>
          <LogoutButton />
        </div>
      </aside>

      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-white/[0.06] bg-ink-950/90 px-4 backdrop-blur lg:hidden">
          <Logo size={24} />
          <button
            type="button"
            className="btn-ghost !px-2.5"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-label={open ? "Fechar menu" : "Abrir menu"}
          >
            {open ? <IconX /> : <IconMenu />}
          </button>
        </header>
        {open ? (
          <div className="border-b border-white/[0.06] bg-ink-900 p-3 lg:hidden">
            <NavLinks pathname={pathname} onNavigate={() => setOpen(false)} />
            <div className="mt-3 flex items-center justify-between gap-3 border-t border-white/[0.06] pt-3">
              <p className="truncate text-xs text-zinc-500">{user.email}</p>
              <LogoutButton className="btn-ghost shrink-0" />
            </div>
          </div>
        ) : null}
        <main className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 lg:px-8 lg:py-8">{children}</main>
      </div>
    </div>
  );
}
