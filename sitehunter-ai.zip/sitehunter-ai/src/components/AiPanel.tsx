"use client";

import { useEffect, useState } from "react";
import { IconCopy, IconExternal, IconSparkle } from "@/components/Icons";
import { Notice } from "@/components/ui";
import { apiRequest } from "@/lib/apiClient";
import { whatsappLink } from "@/lib/phone";

type Kind = "analysis" | "whatsapp" | "instagram" | "site_models";
type Tone = "profissional" | "amigavel" | "direto";

const KINDS: { kind: Kind; label: string }[] = [
  { kind: "analysis", label: "Analisar oportunidade" },
  { kind: "whatsapp", label: "Mensagem de WhatsApp" },
  { kind: "instagram", label: "Mensagem de Instagram" },
  { kind: "site_models", label: "Modelos de site" },
];

const STORAGE_KEY = "sitehunter:sender";

export function AiPanel({
  companyId,
  aiConfigured,
  aiLabel,
  whatsappDigits,
  instagramUrl,
}: {
  companyId: string;
  aiConfigured: boolean;
  aiLabel: string;
  whatsappDigits: string | null;
  instagramUrl: string | null;
}) {
  const [tone, setTone] = useState<Tone>("profissional");
  const [senderName, setSenderName] = useState("");
  const [agencyName, setAgencyName] = useState("");
  const [offer, setOffer] = useState("");
  const [kind, setKind] = useState<Kind | null>(null);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState<Kind | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // Lembra os dados do remetente neste navegador (conveniência; funciona sem isso).
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const saved = JSON.parse(raw) as { senderName?: string; agencyName?: string; offer?: string };
        setSenderName(saved.senderName ?? "");
        setAgencyName(saved.agencyName ?? "");
        setOffer(saved.offer ?? "");
      }
    } catch {
      /* armazenamento indisponível */
    }
  }, []);

  function persist(next: { senderName: string; agencyName: string; offer: string }) {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* ignora */
    }
  }

  async function generate(k: Kind) {
    setBusy(k);
    setError(null);
    setCopied(false);
    persist({ senderName, agencyName, offer });
    try {
      const res = await apiRequest<{ text: string }>("/api/ai", "POST", {
        companyId,
        kind: k,
        tone,
        senderName,
        agencyName,
        offer,
      });
      setKind(k);
      setText(res.text);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Não foi possível gerar o texto.");
    } finally {
      setBusy(null);
    }
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setError("Não foi possível copiar automaticamente. Selecione o texto e copie manualmente.");
    }
  }

  const waHref = kind === "whatsapp" && text ? whatsappLink(whatsappDigits, text) : null;

  return (
    <section className="card card-pad space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 text-base font-semibold text-white">
            <IconSparkle className="text-electric-400" /> Inteligência artificial
          </h2>
          <p className="mt-1 text-sm text-zinc-400">
            Os textos são rascunhos editáveis. Nada é enviado automaticamente: você revisa e envia por conta própria.
          </p>
        </div>
        {aiConfigured ? <span className="badge border-white/10 text-zinc-400">{aiLabel}</span> : null}
      </div>

      {!aiConfigured ? (
        <Notice tone="warn">
          A IA ainda não está configurada. Defina <code className="font-mono">AI_PROVIDER</code>, <code className="font-mono">AI_MODEL</code> e a chave
          do provedor no arquivo <code className="font-mono">.env</code> e reinicie o servidor (veja o README).
        </Notice>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="ai-sender">
            Seu nome <span className="text-zinc-600">(opcional)</span>
          </label>
          <input id="ai-sender" className="input" value={senderName} onChange={(e) => setSenderName(e.target.value)} maxLength={80} />
        </div>
        <div>
          <label className="label" htmlFor="ai-agency">
            Sua agência/empresa <span className="text-zinc-600">(opcional)</span>
          </label>
          <input id="ai-agency" className="input" value={agencyName} onChange={(e) => setAgencyName(e.target.value)} maxLength={80} />
        </div>
        <div className="sm:col-span-2">
          <label className="label" htmlFor="ai-offer">
            O que você oferece <span className="text-zinc-600">(opcional — a IA usa apenas isto)</span>
          </label>
          <input
            id="ai-offer"
            className="input"
            placeholder="Ex.: sites institucionais com botão de WhatsApp e Google Maps"
            value={offer}
            onChange={(e) => setOffer(e.target.value)}
            maxLength={400}
          />
        </div>
        <div>
          <label className="label" htmlFor="ai-tone">
            Tom das mensagens
          </label>
          <select id="ai-tone" className="input" value={tone} onChange={(e) => setTone(e.target.value as Tone)}>
            <option value="profissional">Profissional</option>
            <option value="amigavel">Amigável</option>
            <option value="direto">Direto</option>
          </select>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {KINDS.map((k) => (
          <button key={k.kind} type="button" className={kind === k.kind ? "btn-primary" : "btn-ghost"} disabled={!aiConfigured || busy !== null} onClick={() => generate(k.kind)}>
            {busy === k.kind ? <span className="spinner" /> : null}
            {k.label}
          </button>
        ))}
      </div>

      {error ? <Notice tone="error">{error}</Notice> : null}

      {text ? (
        <div className="space-y-3 animate-fade-in">
          <label className="label" htmlFor="ai-output">
            Resultado (editável)
          </label>
          <textarea id="ai-output" className="input min-h-48 resize-y leading-relaxed" value={text} onChange={(e) => setText(e.target.value)} />
          <div className="flex flex-wrap items-center gap-2">
            <button type="button" className="btn-ghost" onClick={copy}>
              <IconCopy width={16} height={16} />
              {copied ? "Copiado!" : "Copiar texto"}
            </button>
            {waHref ? (
              <a href={waHref} target="_blank" rel="noopener noreferrer" className="btn-ghost">
                <IconExternal width={16} height={16} />
                Abrir no WhatsApp (você envia)
              </a>
            ) : null}
            {kind === "instagram" && instagramUrl ? (
              <a href={instagramUrl} target="_blank" rel="noopener noreferrer" className="btn-ghost">
                <IconExternal width={16} height={16} />
                Abrir perfil no Instagram
              </a>
            ) : null}
          </div>
          {kind === "whatsapp" && waHref ? (
            <p className="text-xs text-zinc-500">
              O número vem do cadastro público do Google e não é garantido que tenha WhatsApp. Confira antes de enviar.
            </p>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}
