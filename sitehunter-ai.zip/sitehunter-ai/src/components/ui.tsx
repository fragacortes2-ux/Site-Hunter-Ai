import Link from "next/link";
import { WEBSITE_STATUS_LABELS, LEAD_STATUS_LABELS } from "@/lib/constants";
import { tierFromScore } from "@/lib/score";

const STATUS_STYLES: Record<string, string> = {
  NO_SITE: "border-electric-500/40 bg-electric-500/15 text-electric-300",
  HAS_SITE: "border-emerald-500/30 bg-emerald-500/10 text-emerald-300",
  UNAVAILABLE: "border-amber-500/30 bg-amber-500/10 text-amber-300",
  PENDING: "border-zinc-500/30 bg-zinc-500/10 text-zinc-300",
};

export function WebsiteBadge({ status }: { status: string }) {
  return <span className={`badge ${STATUS_STYLES[status] ?? STATUS_STYLES.PENDING}`}>{WEBSITE_STATUS_LABELS[status] ?? status}</span>;
}

const LEAD_STYLES: Record<string, string> = {
  NEW: "border-zinc-500/30 bg-zinc-500/10 text-zinc-300",
  CONTACTED: "border-sky-500/30 bg-sky-500/10 text-sky-300",
  INTERESTED: "border-amber-500/30 bg-amber-500/10 text-amber-300",
  CLIENT: "border-emerald-500/30 bg-emerald-500/10 text-emerald-300",
  LOST: "border-red-500/30 bg-red-500/10 text-red-300",
};

export function LeadBadge({ status }: { status: string }) {
  return <span className={`badge ${LEAD_STYLES[status] ?? LEAD_STYLES.NEW}`}>{LEAD_STATUS_LABELS[status] ?? status}</span>;
}

const TIER_COLORS: Record<string, string> = {
  PRIORITY: "text-electric-300 border-electric-500/40 bg-electric-500/15",
  GOOD: "text-emerald-300 border-emerald-500/30 bg-emerald-500/10",
  MODERATE: "text-amber-300 border-amber-500/30 bg-amber-500/10",
  LOW: "text-zinc-400 border-zinc-600/40 bg-zinc-500/10",
};

export function ScoreBadge({ score }: { score: number }) {
  const t = tierFromScore(score);
  return (
    <span className={`badge ${TIER_COLORS[t.tier]}`} title={t.label}>
      <span className="font-mono text-[12px] font-semibold">{score}</span>
      <span className="hidden text-[10px] opacity-80 sm:inline">{t.label.split(" ").slice(-1)[0]}</span>
    </span>
  );
}

export function PageHeader({
  title,
  subtitle,
  actions,
}: {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-xl font-semibold tracking-tight text-white sm:text-2xl">{title}</h1>
        {subtitle ? <p className="mt-1 max-w-2xl text-sm text-zinc-400">{subtitle}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function EmptyState({
  title,
  text,
  href,
  cta,
}: {
  title: string;
  text: string;
  href?: string;
  cta?: string;
}) {
  return (
    <div className="card bg-grid flex flex-col items-center px-6 py-14 text-center">
      <p className="text-base font-medium text-white">{title}</p>
      <p className="mt-1.5 max-w-md text-sm text-zinc-400">{text}</p>
      {href && cta ? (
        <Link href={href} className="btn-primary mt-5">
          {cta}
        </Link>
      ) : null}
    </div>
  );
}

export function Notice({ tone = "info", children }: { tone?: "info" | "warn" | "error"; children: React.ReactNode }) {
  const styles = {
    info: "border-electric-500/30 bg-electric-500/10 text-electric-300",
    warn: "border-amber-500/30 bg-amber-500/10 text-amber-200",
    error: "border-red-500/30 bg-red-500/10 text-red-300",
  }[tone];
  return <div className={`rounded-lg border px-3.5 py-2.5 text-sm ${styles}`}>{children}</div>;
}

export function Stat({
  label,
  value,
  hint,
  accent,
}: {
  label: string;
  value: string;
  hint?: string;
  accent?: boolean;
}) {
  return (
    <div className="card card-pad animate-fade-in">
      <p className="text-xs font-medium text-zinc-400">{label}</p>
      <p className={`mt-2 text-3xl font-semibold tracking-tight ${accent ? "text-electric-300" : "text-white"}`}>{value}</p>
      {hint ? <p className="mt-1 text-xs text-zinc-500">{hint}</p> : null}
    </div>
  );
}
