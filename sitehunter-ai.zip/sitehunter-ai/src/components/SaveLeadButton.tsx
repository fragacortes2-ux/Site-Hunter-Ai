"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { LeadBadge } from "@/components/ui";
import { apiRequest } from "@/lib/apiClient";

export function SaveLeadButton({
  companyId,
  lead,
  size = "sm",
}: {
  companyId: string;
  lead: { id: string; status: string } | null;
  size?: "sm" | "md";
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (lead) {
    return (
      <Link href="/leads" title="Abrir no CRM">
        <LeadBadge status={lead.status} />
      </Link>
    );
  }

  async function save() {
    setBusy(true);
    setError(null);
    try {
      await apiRequest("/api/leads", "POST", { companyId });
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Erro ao salvar.");
      setBusy(false);
    }
  }

  return (
    <span className="inline-flex flex-col items-start gap-1">
      <button type="button" onClick={save} disabled={busy} className={size === "sm" ? "btn-ghost !px-2.5 !py-1 text-xs" : "btn-primary"}>
        {busy ? <span className="spinner" /> : null}
        Salvar como lead
      </button>
      {error ? <span className="text-[11px] text-red-300">{error}</span> : null}
    </span>
  );
}
