"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { apiRequest } from "@/lib/apiClient";

export function AuthForm({ mode, registrationOpen = true }: { mode: "login" | "register"; registrationOpen?: boolean }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const isRegister = mode === "register";

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await apiRequest(isRegister ? "/api/auth/register" : "/api/auth/login", "POST", isRegister ? { name, email, password } : { email, password });
      router.push("/dashboard");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível continuar.");
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      {isRegister ? (
        <div>
          <label className="label" htmlFor="name">
            Nome
          </label>
          <input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" required />
        </div>
      ) : null}
      <div>
        <label className="label" htmlFor="email">
          E-mail
        </label>
        <input
          id="email"
          type="email"
          className="input"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          autoComplete="email"
          required
        />
      </div>
      <div>
        <label className="label" htmlFor="password">
          Senha
        </label>
        <input
          id="password"
          type="password"
          className="input"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete={isRegister ? "new-password" : "current-password"}
          minLength={isRegister ? 10 : undefined}
          required
        />
        {isRegister ? <p className="mt-1.5 text-xs text-zinc-500">Use pelo menos 10 caracteres.</p> : null}
      </div>

      {error ? (
        <p role="alert" className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">
          {error}
        </p>
      ) : null}

      <button type="submit" className="btn-primary w-full" disabled={busy}>
        {busy ? <span className="spinner" /> : null}
        {isRegister ? "Criar conta" : "Entrar"}
      </button>

      <p className="text-center text-sm text-zinc-500">
        {isRegister ? (
          <>
            Já tem conta?{" "}
            <Link href="/login" className="text-electric-300 hover:underline">
              Entrar
            </Link>
          </>
        ) : registrationOpen ? (
          <>
            Ainda não tem conta?{" "}
            <Link href="/register" className="text-electric-300 hover:underline">
              Cadastre-se
            </Link>
          </>
        ) : (
          "Novos cadastros estão desativados nesta instalação."
        )}
      </p>
    </form>
  );
}
