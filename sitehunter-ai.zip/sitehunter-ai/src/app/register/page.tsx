import type { Metadata } from "next";
import Link from "next/link";
import { AuthForm } from "@/components/AuthForm";
import { Logo } from "@/components/Logo";
import { Notice } from "@/components/ui";
import { allowRegistration, authSecretOk } from "@/lib/env";

export const metadata: Metadata = { title: "Criar conta" };
export const dynamic = "force-dynamic";

export default function RegisterPage() {
  const open = allowRegistration();
  return (
    <main className="bg-grid grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-sm animate-fade-in">
        <div className="mb-8 flex justify-center">
          <Logo size={34} />
        </div>
        <div className="card card-pad">
          <h1 className="text-lg font-semibold text-white">Criar conta</h1>
          <p className="mb-5 mt-1 text-sm text-zinc-400">Seus dados e leads ficam separados dos de outros usuários.</p>
          {!authSecretOk() ? (
            <div className="mb-4">
              <Notice tone="error">
                A variável <code className="font-mono">AUTH_SECRET</code> não está configurada (mínimo de 32 caracteres). Edite o arquivo{" "}
                <code className="font-mono">.env</code>, reinicie o servidor e tente novamente.
              </Notice>
            </div>
          ) : null}
          {open ? (
            <AuthForm mode="register" />
          ) : (
            <div className="space-y-4">
              <Notice tone="warn">Novos cadastros estão desativados nesta instalação (ALLOW_REGISTRATION=false).</Notice>
              <Link href="/login" className="btn-ghost w-full">
                Voltar para o login
              </Link>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
