import type { Metadata } from "next";
import { AuthForm } from "@/components/AuthForm";
import { Logo } from "@/components/Logo";
import { Notice } from "@/components/ui";
import { allowRegistration, authSecretOk } from "@/lib/env";

export const metadata: Metadata = { title: "Entrar" };
export const dynamic = "force-dynamic";

export default function LoginPage() {
  return (
    <main className="bg-grid grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-sm animate-fade-in">
        <div className="mb-8 flex justify-center">
          <Logo size={34} />
        </div>
        <div className="card card-pad">
          <h1 className="text-lg font-semibold text-white">Entrar</h1>
          <p className="mb-5 mt-1 text-sm text-zinc-400">Acesse sua conta para continuar prospectando.</p>
          {!authSecretOk() ? (
            <div className="mb-4">
              <Notice tone="error">
                A variável <code className="font-mono">AUTH_SECRET</code> não está configurada (mínimo de 32 caracteres). Edite o arquivo{" "}
                <code className="font-mono">.env</code>, reinicie o servidor e tente novamente.
              </Notice>
            </div>
          ) : null}
          <AuthForm mode="login" registrationOpen={allowRegistration()} />
        </div>
      </div>
    </main>
  );
}
