import { requireUser } from "@/lib/auth";
import { ApiError, json, readJson, route } from "@/lib/http";
import { rateLimit } from "@/lib/rateLimit";
import { runSearch } from "@/lib/prospecting";
import { searchSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";
// A pesquisa consulta o Google e valida sites; pode levar de 20 a 90 segundos.
export const maxDuration = 120;

export const POST = route(async (req) => {
  const user = await requireUser();
  const rl = rateLimit(`search:${user.id}`, 6, 60 * 1000);
  if (!rl.ok) throw new ApiError(429, `Aguarde ${rl.retryAfterSec}s antes de pesquisar novamente.`);

  const input = searchSchema.parse(await readJson(req));
  const summary = await runSearch(user.id, input);
  return json(summary);
});
