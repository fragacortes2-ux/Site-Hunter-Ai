import { prisma } from "@/lib/db";
import { json, route } from "@/lib/http";

export const dynamic = "force-dynamic";

export const GET = route(async () => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return json({ ok: true, database: "ok" });
  } catch {
    return json({ ok: false, database: "erro" }, 503);
  }
});
