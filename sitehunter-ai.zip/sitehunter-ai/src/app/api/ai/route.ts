import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { generateText } from "@/lib/ai";
import { assertAiAllowed } from "@/lib/limits";
import { ApiError, json, readJson, route } from "@/lib/http";
import { rateLimit } from "@/lib/rateLimit";
import { aiSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export const POST = route(async (req) => {
  const user = await requireUser();
  const rl = rateLimit(`ai:${user.id}`, 20, 60 * 1000);
  if (!rl.ok) throw new ApiError(429, `Aguarde ${rl.retryAfterSec}s antes de gerar novamente.`);

  const body = aiSchema.parse(await readJson(req));
  const company = await prisma.company.findFirst({ where: { id: body.companyId, userId: user.id } });
  if (!company) throw new ApiError(404, "Empresa não encontrada.");

  await assertAiAllowed(user.id);

  const result = await generateText(
    body.kind,
    {
      name: company.name,
      category: company.category,
      segment: company.segment,
      address: company.address,
      city: company.city,
      state: company.state,
      phone: company.phone,
      instagram: company.instagram,
      facebook: company.facebook,
      website: company.website,
      websiteStatus: company.websiteStatus,
      websiteNote: company.websiteNote,
      verificationMethod: company.verificationMethod,
      rating: company.rating,
      ratingCount: company.ratingCount,
      leadScore: company.leadScore,
    },
    { tone: body.tone, senderName: body.senderName, agencyName: body.agencyName, offer: body.offer },
  );

  await prisma.aiUsage.create({ data: { userId: user.id, kind: body.kind } });
  return json(result);
});
