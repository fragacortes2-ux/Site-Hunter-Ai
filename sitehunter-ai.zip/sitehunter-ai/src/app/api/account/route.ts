import { destroySession, requireUser, verifyPassword } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { ApiError, json, readJson, route } from "@/lib/http";
import { rateLimit } from "@/lib/rateLimit";
import { deleteAccountSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

/** Exclusão da conta e de todos os dados do usuário (LGPD — direito de eliminação). */
export const DELETE = route(async (req) => {
  const user = await requireUser();
  const rl = rateLimit(`delete-account:${user.id}`, 5, 15 * 60 * 1000);
  if (!rl.ok) throw new ApiError(429, "Muitas tentativas. Aguarde alguns minutos.");

  const { password } = deleteAccountSchema.parse(await readJson(req));
  const record = await prisma.user.findUnique({ where: { id: user.id }, select: { passwordHash: true } });
  if (!record || !(await verifyPassword(password, record.passwordHash))) {
    throw new ApiError(401, "Senha incorreta.");
  }

  await prisma.user.delete({ where: { id: user.id } });
  await destroySession();
  return json({ ok: true });
});
