import { requireUser } from "@/lib/auth";
import { ApiError, json, routeWithParams } from "@/lib/http";
import { rateLimit } from "@/lib/rateLimit";
import { recheckCompany } from "@/lib/prospecting";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export const POST = routeWithParams<{ id: string }>(async (_req, { id }) => {
  const user = await requireUser();
  const rl = rateLimit(`recheck:${user.id}`, 20, 10 * 60 * 1000);
  if (!rl.ok) throw new ApiError(429, `Muitas reverificações. Tente novamente em ${rl.retryAfterSec}s.`);
  const company = await recheckCompany(user.id, id);
  return json({ company });
});
