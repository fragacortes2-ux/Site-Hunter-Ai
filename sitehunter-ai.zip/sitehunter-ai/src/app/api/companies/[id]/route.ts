import { requireUser } from "@/lib/auth";
import { ApiError, json, routeWithParams } from "@/lib/http";
import { getCompanyDetail } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const GET = routeWithParams<{ id: string }>(async (_req, { id }) => {
  const user = await requireUser();
  const detail = await getCompanyDetail(user.id, id);
  if (!detail) throw new ApiError(404, "Empresa não encontrada.");
  return json(detail);
});
