import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { buildCompanyOrderBy, buildCompanyWhere, parseCompanyFilters } from "@/lib/filters";
import { json, route } from "@/lib/http";

export const dynamic = "force-dynamic";

export const GET = route(async (req) => {
  const user = await requireUser();
  const f = parseCompanyFilters(req.nextUrl.searchParams);
  const where = buildCompanyWhere(user.id, f);

  const [total, items] = await Promise.all([
    prisma.company.count({ where }),
    prisma.company.findMany({
      where,
      orderBy: buildCompanyOrderBy(f.sort),
      skip: (f.page - 1) * f.pageSize,
      take: f.pageSize,
      select: {
        id: true,
        name: true,
        category: true,
        segment: true,
        city: true,
        state: true,
        phone: true,
        instagram: true,
        website: true,
        websiteStatus: true,
        leadScore: true,
        rating: true,
        ratingCount: true,
        discoveredAt: true,
        lead: { select: { id: true, status: true } },
      },
    }),
  ]);

  return json({
    items,
    total,
    page: f.page,
    pageSize: f.pageSize,
    pages: Math.max(1, Math.ceil(total / f.pageSize)),
  });
});
