import { requireUser } from "@/lib/auth";
import { json, route } from "@/lib/http";
import { getDashboardStats } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const GET = route(async () => {
  const user = await requireUser();
  return json(await getDashboardStats(user.id));
});
