import { prisma } from "@/lib/db";
import { createSession, hashPassword } from "@/lib/auth";
import { allowRegistration } from "@/lib/env";
import { ApiError, json, readJson, route } from "@/lib/http";
import { clientIp, rateLimit } from "@/lib/rateLimit";
import { registerSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

export const POST = route(async (req) => {
  if (!allowRegistration()) {
    throw new ApiError(403, "Novos cadastros estão desativados nesta instalação.");
  }
  const rl = rateLimit(`register:${clientIp(req)}`, 5, 60 * 60 * 1000);
  if (!rl.ok) throw new ApiError(429, `Muitas tentativas. Tente novamente em ${rl.retryAfterSec}s.`);

  const body = registerSchema.parse(await readJson(req));

  const exists = await prisma.user.findUnique({ where: { email: body.email }, select: { id: true } });
  if (exists) throw new ApiError(409, "Este e-mail já está cadastrado.");

  let user: { id: string; email: string; name: string };
  try {
    user = await prisma.user.create({
      data: { name: body.name, email: body.email, passwordHash: await hashPassword(body.password) },
      select: { id: true, email: true, name: true },
    });
  } catch (e) {
    if ((e as { code?: string }).code === "P2002") throw new ApiError(409, "Este e-mail já está cadastrado.");
    throw e;
  }

  await createSession(user.id);
  return json({ user }, 201);
});
