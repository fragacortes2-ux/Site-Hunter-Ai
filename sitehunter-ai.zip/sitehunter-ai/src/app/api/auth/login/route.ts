import { prisma } from "@/lib/db";
import { createSession, getDummyHash, verifyPassword } from "@/lib/auth";
import { ApiError, json, readJson, route } from "@/lib/http";
import { clientIp, rateLimit, resetRateLimit } from "@/lib/rateLimit";
import { loginSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

export const POST = route(async (req) => {
  const body = loginSchema.parse(await readJson(req));

  const key = `login:${clientIp(req)}:${body.email}`;
  const rl = rateLimit(key, 8, 15 * 60 * 1000);
  if (!rl.ok) {
    throw new ApiError(429, `Muitas tentativas de login. Tente novamente em ${Math.ceil(rl.retryAfterSec / 60)} min.`);
  }

  const user = await prisma.user.findUnique({ where: { email: body.email } });
  // Sempre compara um hash para não revelar, pelo tempo de resposta, se o e-mail existe.
  const valid = await verifyPassword(body.password, user?.passwordHash ?? (await getDummyHash()));
  if (!user || !valid) throw new ApiError(401, "E-mail ou senha incorretos.");

  resetRateLimit(key);
  await createSession(user.id);
  return json({ user: { id: user.id, email: user.email, name: user.name } });
});
