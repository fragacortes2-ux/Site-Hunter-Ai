import { destroySession } from "@/lib/auth";
import { json, route } from "@/lib/http";

export const dynamic = "force-dynamic";

export const POST = route(async () => {
  await destroySession();
  return json({ ok: true });
});
