import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { LEAD_STATUSES } from "@/lib/constants";
import { ApiError, json, readJson, route } from "@/lib/http";
import { leadCreateSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

export const GET = route(async (req) => {
  const user = await requireUser();
  const status = req.nextUrl.searchParams.get("status");
  if (status && !(LEAD_STATUSES as readonly string[]).includes(status)) {
    throw new ApiError(400, "Status inválido.");
  }

  const leads = await prisma.lead.findMany({
    where: { userId: user.id, ...(status ? { status: status as (typeof LEAD_STATUSES)[number] } : {}) },
    orderBy: { updatedAt: "desc" },
    take: 500,
    include: {
      company: {
        select: {
          id: true,
          name: true,
          category: true,
          city: true,
          state: true,
          phone: true,
          whatsapp: true,
          instagram: true,
          website: true,
          websiteStatus: true,
          leadScore: true,
        },
      },
      reminders: { orderBy: [{ done: "asc" }, { dueAt: "asc" }] },
    },
  });

  const counts = await prisma.lead.groupBy({ by: ["status"], where: { userId: user.id }, _count: { _all: true } });
  return json({
    leads,
    counts: Object.fromEntries(counts.map((c) => [c.status, c._count._all])),
  });
});

export const POST = route(async (req) => {
  const user = await requireUser();
  const { companyId } = leadCreateSchema.parse(await readJson(req));

  const company = await prisma.company.findFirst({ where: { id: companyId, userId: user.id }, select: { id: true } });
  if (!company) throw new ApiError(404, "Empresa não encontrada.");

  const existing = await prisma.lead.findUnique({ where: { companyId } });
  if (existing) return json({ lead: existing, created: false });

  const lead = await prisma.lead.create({ data: { userId: user.id, companyId } });
  return json({ lead, created: true }, 201);
});
