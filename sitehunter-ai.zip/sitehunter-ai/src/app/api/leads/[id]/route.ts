import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { ApiError, json, readJson, routeWithParams } from "@/lib/http";
import { leadPatchSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

export const PATCH = routeWithParams<{ id: string }>(async (req, { id }) => {
  const user = await requireUser();
  const body = leadPatchSchema.parse(await readJson(req));

  const lead = await prisma.lead.findFirst({ where: { id, userId: user.id } });
  if (!lead) throw new ApiError(404, "Lead não encontrado.");

  const data: { status?: (typeof body)["status"]; notes?: string; contactedAt?: Date | null } = {};
  if (body.status) data.status = body.status;
  if (body.notes !== undefined) data.notes = body.notes;
  if (body.contactedAt !== undefined) {
    data.contactedAt = body.contactedAt === null ? null : new Date(body.contactedAt);
  } else if (body.status === "CONTACTED" && !lead.contactedAt) {
    data.contactedAt = new Date();
  }

  const updated = await prisma.lead.update({ where: { id: lead.id }, data });
  return json({ lead: updated });
});

export const DELETE = routeWithParams<{ id: string }>(async (_req, { id }) => {
  const user = await requireUser();
  const res = await prisma.lead.deleteMany({ where: { id, userId: user.id } });
  if (res.count === 0) throw new ApiError(404, "Lead não encontrado.");
  return json({ ok: true });
});
