import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { ApiError, json, readJson, routeWithParams } from "@/lib/http";
import { reminderCreateSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

export const POST = routeWithParams<{ id: string }>(async (req, { id }) => {
  const user = await requireUser();
  const body = reminderCreateSchema.parse(await readJson(req));

  const lead = await prisma.lead.findFirst({ where: { id, userId: user.id }, select: { id: true } });
  if (!lead) throw new ApiError(404, "Lead não encontrado.");

  const reminder = await prisma.reminder.create({
    data: { userId: user.id, leadId: lead.id, dueAt: new Date(body.dueAt), note: body.note },
  });
  return json({ reminder }, 201);
});
