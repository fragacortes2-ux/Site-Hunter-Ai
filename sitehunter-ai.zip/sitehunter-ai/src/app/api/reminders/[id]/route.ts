import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { ApiError, json, readJson, routeWithParams } from "@/lib/http";
import { reminderPatchSchema } from "@/lib/validators";

export const dynamic = "force-dynamic";

export const PATCH = routeWithParams<{ id: string }>(async (req, { id }) => {
  const user = await requireUser();
  const body = reminderPatchSchema.parse(await readJson(req));
  const res = await prisma.reminder.updateMany({ where: { id, userId: user.id }, data: { done: body.done } });
  if (res.count === 0) throw new ApiError(404, "Lembrete não encontrado.");
  return json({ ok: true });
});

export const DELETE = routeWithParams<{ id: string }>(async (_req, { id }) => {
  const user = await requireUser();
  const res = await prisma.reminder.deleteMany({ where: { id, userId: user.id } });
  if (res.count === 0) throw new ApiError(404, "Lembrete não encontrado.");
  return json({ ok: true });
});
