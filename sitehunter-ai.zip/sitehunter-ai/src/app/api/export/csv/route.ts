import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { toCsv, type CsvColumn } from "@/lib/csv";
import { buildCompanyOrderBy, buildCompanyWhere, parseCompanyFilters } from "@/lib/filters";
import { LEAD_STATUS_LABELS, WEBSITE_STATUS_LABELS } from "@/lib/constants";
import { formatDateTime } from "@/lib/format";
import { route } from "@/lib/http";
import { tierFromScore } from "@/lib/score";

export const dynamic = "force-dynamic";

const MAX_ROWS = 5000;

type Row = Awaited<ReturnType<typeof loadRows>>[number];

function loadRows(userId: string, params: URLSearchParams, leadsOnly: boolean) {
  const f = parseCompanyFilters(params);
  const where = buildCompanyWhere(userId, { ...f, onlyLeads: leadsOnly || f.onlyLeads });
  return prisma.company.findMany({
    where,
    orderBy: buildCompanyOrderBy(f.sort),
    take: MAX_ROWS,
    include: {
      lead: { include: { reminders: { where: { done: false }, orderBy: { dueAt: "asc" }, take: 1 } } },
    },
  });
}

const baseColumns: CsvColumn<Row>[] = [
  { header: "Nome", value: (r) => r.name },
  { header: "Categoria", value: (r) => r.category },
  { header: "Segmento pesquisado", value: (r) => r.segment },
  { header: "Endereço", value: (r) => r.address },
  { header: "Bairro", value: (r) => r.neighborhood },
  { header: "Cidade", value: (r) => r.city },
  { header: "UF", value: (r) => r.state },
  { header: "Telefone", value: (r) => r.phone ?? "Não informado" },
  { header: "WhatsApp", value: (r) => r.whatsapp ?? "Não informado" },
  { header: "Instagram", value: (r) => r.instagram ?? "Não informado" },
  { header: "Facebook", value: (r) => r.facebook ?? "Não informado" },
  { header: "Site", value: (r) => r.website ?? "Não informado" },
  { header: "Situação do site", value: (r) => WEBSITE_STATUS_LABELS[r.websiteStatus] },
  { header: "Observação da verificação", value: (r) => r.websiteNote },
  { header: "Método de verificação", value: (r) => r.verificationMethod },
  { header: "Lead Score", value: (r) => r.leadScore },
  { header: "Classificação", value: (r) => tierFromScore(r.leadScore).label },
  { header: "Avaliação", value: (r) => r.rating },
  { header: "Nº de avaliações", value: (r) => r.ratingCount },
  { header: "Google Maps", value: (r) => r.mapsUrl },
  { header: "Fonte", value: (r) => r.source },
  { header: "Data da descoberta", value: (r) => formatDateTime(r.discoveredAt) },
];

const leadColumns: CsvColumn<Row>[] = [
  { header: "Status do lead", value: (r) => (r.lead ? LEAD_STATUS_LABELS[r.lead.status] : "") },
  { header: "Data do contato", value: (r) => formatDateTime(r.lead?.contactedAt) },
  { header: "Próximo lembrete", value: (r) => (r.lead?.reminders[0] ? formatDateTime(r.lead.reminders[0].dueAt) : "") },
  { header: "Observações", value: (r) => r.lead?.notes ?? "" },
];

export const GET = route(async (req) => {
  const user = await requireUser();
  const params = req.nextUrl.searchParams;
  const leadsOnly = params.get("scope") === "leads";

  const rows = await loadRows(user.id, params, leadsOnly);
  const csv = toCsv(rows, leadsOnly ? [...baseColumns, ...leadColumns] : [...baseColumns, ...leadColumns.slice(0, 1)]);

  const date = new Date().toISOString().slice(0, 10);
  const filename = `sitehunter-${leadsOnly ? "leads" : "empresas"}-${date}.csv`;
  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
});
