import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { IconDownload } from "@/components/Icons";
import { LeadCard, type LeadCardData } from "@/components/LeadCard";
import { EmptyState, PageHeader } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { LEAD_STATUSES, LEAD_STATUS_LABELS } from "@/lib/constants";
import { prisma } from "@/lib/db";

export const metadata: Metadata = { title: "Leads (CRM)" };
export const dynamic = "force-dynamic";

type SP = Record<string, string | string[] | undefined>;

export default async function LeadsPage({ searchParams }: { searchParams: Promise<SP> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const sp = await searchParams;
  const rawStatus = Array.isArray(sp.status) ? sp.status[0] : sp.status;
  const status = (LEAD_STATUSES as readonly string[]).includes(rawStatus ?? "") ? (rawStatus as (typeof LEAD_STATUSES)[number]) : undefined;

  const [leads, counts] = await Promise.all([
    prisma.lead.findMany({
      where: { userId: user.id, ...(status ? { status } : {}) },
      orderBy: { updatedAt: "desc" },
      take: 500,
      include: {
        company: {
          select: {
            id: true,
            name: true,
            category: true,
            city: true,
            state: true,
            phone: true,
            instagram: true,
            website: true,
            websiteStatus: true,
            leadScore: true,
          },
        },
        reminders: { orderBy: [{ done: "asc" }, { dueAt: "asc" }] },
      },
    }),
    prisma.lead.groupBy({ by: ["status"], where: { userId: user.id }, _count: { _all: true } }),
  ]);

  const countOf = (s: string) => counts.find((c) => c.status === s)?._count._all ?? 0;
  const totalLeads = counts.reduce((sum, c) => sum + c._count._all, 0);

  const data: LeadCardData[] = leads.map((l) => ({
    id: l.id,
    status: l.status,
    notes: l.notes,
    contactedAt: l.contactedAt ? l.contactedAt.toISOString() : null,
    company: l.company,
    reminders: l.reminders.map((r) => ({ id: r.id, dueAt: r.dueAt.toISOString(), note: r.note, done: r.done })),
  }));

  const tab = (active: boolean) =>
    `rounded-lg border px-3 py-1.5 text-xs transition ${
      active ? "border-electric-500/50 bg-electric-500/15 text-white" : "border-white/10 text-zinc-400 hover:bg-white/[0.05]"
    }`;

  return (
    <div className="space-y-5">
      <PageHeader
        title="Leads (CRM)"
        subtitle="Acompanhe cada empresa até virar cliente. Tudo fica salvo no banco de dados."
        actions={
          <a href="/api/export/csv?scope=leads" className="btn-ghost">
            <IconDownload width={16} height={16} />
            Exportar leads em CSV
          </a>
        }
      />

      <div className="flex flex-wrap gap-2">
        <Link href="/leads" className={tab(!status)}>
          Todos ({totalLeads})
        </Link>
        {LEAD_STATUSES.map((s) => (
          <Link key={s} href={`/leads?status=${s}`} className={tab(status === s)}>
            {LEAD_STATUS_LABELS[s]} ({countOf(s)})
          </Link>
        ))}
      </div>

      {data.length === 0 ? (
        <EmptyState
          title={status ? "Nenhum lead com este status" : "Você ainda não salvou nenhum lead"}
          text="Na lista de empresas, use “Salvar como lead” nas melhores oportunidades para acompanhá-las aqui."
          href="/companies?onlyNoSite=1"
          cta="Ver empresas sem site"
        />
      ) : (
        <div className="space-y-3">
          {data.map((lead) => (
            <LeadCard key={lead.id} lead={lead} />
          ))}
        </div>
      )}
    </div>
  );
}
