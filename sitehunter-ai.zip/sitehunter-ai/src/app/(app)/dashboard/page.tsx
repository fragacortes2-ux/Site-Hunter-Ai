import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { BarList, ColumnChart, DonutChart } from "@/components/Charts";
import { EmptyState, Notice, PageHeader, ScoreBadge, Stat } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { LEAD_STATUSES, LEAD_STATUS_LABELS } from "@/lib/constants";
import { getIntegrationStatus } from "@/lib/env";
import { formatDateTime, formatNumber, formatPercent, shortDayLabel } from "@/lib/format";
import { getDashboardStats } from "@/lib/queries";

export const metadata: Metadata = { title: "Painel" };
export const dynamic = "force-dynamic";

const LEAD_COLORS: Record<string, string> = {
  NEW: "#71717a",
  CONTACTED: "#38bdf8",
  INTERESTED: "#fbbf24",
  CLIENT: "#34d399",
  LOST: "#f87171",
};

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const [stats, integrations] = await Promise.all([getDashboardStats(user.id), Promise.resolve(getIntegrationStatus())]);

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Olá, ${user.name.split(" ")[0]}`}
        subtitle="Resumo da sua prospecção. Todos os números vêm das pesquisas reais já realizadas."
        actions={
          <Link href="/search" className="btn-primary">
            Nova pesquisa
          </Link>
        }
      />

      {!integrations.places ? (
        <Notice tone="warn">
          O Google Places ainda não está configurado, então não é possível pesquisar empresas. Defina <code className="font-mono">GOOGLE_PLACES_API_KEY</code>{" "}
          no arquivo <code className="font-mono">.env</code> e reinicie o servidor. Detalhes em{" "}
          <Link href="/settings" className="underline">
            Configurações
          </Link>{" "}
          e no README.
        </Notice>
      ) : null}

      {stats.total === 0 ? (
        <EmptyState
          title="Nenhuma empresa na sua base ainda"
          text="Faça sua primeira pesquisa por segmento e cidade. O sistema consulta o Google Places, verifica se cada empresa tem site e calcula o Lead Score."
          href="/search"
          cta="Fazer primeira pesquisa"
        />
      ) : (
        <>
          <section className="grid grid-cols-2 gap-3 lg:grid-cols-3 xl:grid-cols-6">
            <Stat label="Empresas encontradas" value={formatNumber(stats.total)} />
            <Stat label="Sem site identificado" value={formatNumber(stats.noSite)} accent />
            <Stat label="Com site" value={formatNumber(stats.hasSite)} />
            <Stat label="Oportunidades prioritárias" value={formatNumber(stats.priority)} hint="Lead Score de 80 a 100" accent />
            <Stat label="Pesquisas realizadas" value={formatNumber(stats.searchCount)} />
            <Stat label="Taxa sem site identificado" value={formatPercent(stats.noSiteRate)} hint="sobre o total de empresas" />
          </section>

          <section className="grid gap-4 lg:grid-cols-2">
            <div className="card card-pad">
              <h2 className="mb-4 text-sm font-semibold text-white">Situação do site</h2>
              <DonutChart
                centerValue={formatNumber(stats.total)}
                centerLabel="empresas"
                segments={[
                  { label: "Sem site identificado", value: stats.noSite, color: "#2f6bff" },
                  { label: "Possui site", value: stats.hasSite, color: "#34d399" },
                  { label: "Site indisponível", value: stats.unavailable, color: "#fbbf24" },
                  { label: "Verificação pendente", value: stats.pending, color: "#71717a" },
                ]}
              />
            </div>
            <div className="card card-pad">
              <h2 className="mb-4 text-sm font-semibold text-white">Classificação por Lead Score</h2>
              <BarList
                items={[
                  { label: "Prioritária (80–100)", value: stats.tiers.priority, color: "#2f6bff" },
                  { label: "Boa (60–79)", value: stats.tiers.good, color: "#34d399" },
                  { label: "Moderada (40–59)", value: stats.tiers.moderate, color: "#fbbf24" },
                  { label: "Baixa prioridade (0–39)", value: stats.tiers.low, color: "#71717a" },
                ]}
              />
              <p className="mt-4 text-xs text-zinc-500">O Lead Score é uma heurística de priorização e não garante interesse comercial.</p>
            </div>
          </section>

          <section className="grid gap-4 lg:grid-cols-2">
            <div className="card card-pad">
              <h2 className="mb-2 text-sm font-semibold text-white">Pesquisas nos últimos 14 dias</h2>
              <ColumnChart data={stats.searchesPerDay.map((d) => ({ label: shortDayLabel(d.key), value: d.count }))} />
            </div>
            <div className="card card-pad">
              <h2 className="mb-4 text-sm font-semibold text-white">Funil de leads</h2>
              <BarList
                items={LEAD_STATUSES.map((s) => ({
                  label: LEAD_STATUS_LABELS[s],
                  value: stats.leadsByStatus[s] ?? 0,
                  color: LEAD_COLORS[s],
                }))}
              />
            </div>
          </section>

          <section className="grid gap-4 lg:grid-cols-2">
            <div className="card card-pad">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-sm font-semibold text-white">Melhores oportunidades sem site</h2>
                <Link href="/companies?onlyNoSite=1&sort=score_desc" className="text-xs text-electric-300 hover:underline">
                  Ver todas
                </Link>
              </div>
              {stats.top.length === 0 ? (
                <p className="text-sm text-zinc-500">Nenhuma empresa sem site identificado até agora.</p>
              ) : (
                <ul className="divide-y divide-white/[0.06]">
                  {stats.top.map((c) => (
                    <li key={c.id} className="flex items-center justify-between gap-3 py-2.5">
                      <div className="min-w-0">
                        <Link href={`/companies/${c.id}`} className="block truncate text-sm font-medium text-zinc-100 hover:text-electric-300">
                          {c.name}
                        </Link>
                        <p className="truncate text-xs text-zinc-500">
                          {[c.category, [c.city, c.state].filter(Boolean).join(" - ")].filter(Boolean).join(" · ")}
                        </p>
                      </div>
                      <ScoreBadge score={c.leadScore} />
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="card card-pad">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-sm font-semibold text-white">Lembretes (próximos 7 dias e atrasados)</h2>
                <Link href="/leads" className="text-xs text-electric-300 hover:underline">
                  Abrir CRM
                </Link>
              </div>
              {stats.reminders.length === 0 ? (
                <p className="text-sm text-zinc-500">Nenhum lembrete pendente.</p>
              ) : (
                <ul className="divide-y divide-white/[0.06]">
                  {stats.reminders.map((r) => (
                    <li key={r.id} className="py-2.5">
                      <p className="truncate text-sm text-zinc-200">{r.note}</p>
                      <p className={`text-xs ${r.overdue ? "text-red-300" : "text-zinc-500"}`}>
                        <Link href={`/companies/${r.companyId}`} className="hover:underline">
                          {r.companyName}
                        </Link>{" "}
                        · {formatDateTime(r.dueAt)}
                        {r.overdue ? " · atrasado" : ""}
                      </p>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </section>
        </>
      )}
    </div>
  );
}
