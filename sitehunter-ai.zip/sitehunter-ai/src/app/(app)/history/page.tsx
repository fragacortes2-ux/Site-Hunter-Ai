import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { EmptyState, PageHeader } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { formatDateTime } from "@/lib/format";

export const metadata: Metadata = { title: "Histórico de pesquisas" };
export const dynamic = "force-dynamic";

export default async function HistoryPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const searches = await prisma.search.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 100,
  });

  return (
    <div className="space-y-5">
      <PageHeader
        title="Histórico de pesquisas"
        subtitle="Suas últimas 100 pesquisas. “Ver resultados” mostra as empresas cuja pesquisa mais recente foi esta."
      />

      {searches.length === 0 ? (
        <EmptyState title="Nenhuma pesquisa realizada" text="Quando você pesquisar empresas, o histórico aparecerá aqui." href="/search" cta="Nova pesquisa" />
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full min-w-[760px] border-collapse">
            <thead className="border-b border-white/[0.06]">
              <tr>
                <th className="th">Data</th>
                <th className="th">Pesquisa</th>
                <th className="th">Local</th>
                <th className="th">Resultados</th>
                <th className="th">Sem site</th>
                <th className="th">Req. Google</th>
                <th className="th" />
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05]">
              {searches.map((s) => {
                const repeat = new URLSearchParams();
                if (s.segment) repeat.set("segment", s.segment);
                if (s.companyName) repeat.set("companyName", s.companyName);
                if (s.city) repeat.set("city", s.city);
                if (s.state) repeat.set("state", s.state);
                if (s.neighborhood) repeat.set("neighborhood", s.neighborhood);
                if (s.radiusKm) repeat.set("radiusKm", String(s.radiusKm));
                return (
                  <tr key={s.id} className="hover:bg-white/[0.02]">
                    <td className="td whitespace-nowrap text-zinc-500">{formatDateTime(s.createdAt)}</td>
                    <td className="td max-w-[260px] truncate text-zinc-100">{[s.segment, s.companyName].filter(Boolean).join(" · ") || s.query}</td>
                    <td className="td whitespace-nowrap">
                      {[s.neighborhood, s.city, s.state].filter(Boolean).join(", ")}
                      {s.radiusKm ? ` (raio ${s.radiusKm} km)` : ""}
                    </td>
                    <td className="td font-mono">{s.resultCount}</td>
                    <td className="td font-mono text-electric-300">{s.noSiteCount}</td>
                    <td className="td font-mono text-zinc-500">{s.placesRequests}</td>
                    <td className="td">
                      <div className="flex justify-end gap-2">
                        <Link href={`/companies?searchId=${s.id}`} className="btn-ghost !px-2.5 !py-1 text-xs">
                          Ver resultados
                        </Link>
                        <Link href={`/search?${repeat.toString()}`} className="btn-ghost !px-2.5 !py-1 text-xs">
                          Repetir
                        </Link>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
