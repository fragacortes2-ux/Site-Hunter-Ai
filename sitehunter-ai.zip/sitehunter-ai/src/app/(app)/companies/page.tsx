import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { IconDownload } from "@/components/Icons";
import { Pagination } from "@/components/Pagination";
import { SaveLeadButton } from "@/components/SaveLeadButton";
import { EmptyState, PageHeader, ScoreBadge, WebsiteBadge } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { BR_STATES, WEBSITE_STATUSES, WEBSITE_STATUS_LABELS } from "@/lib/constants";
import { prisma } from "@/lib/db";
import { buildCompanyOrderBy, buildCompanyWhere, companyFilterSchema } from "@/lib/filters";
import { formatDate, instagramHandle, stripProtocol } from "@/lib/format";

export const metadata: Metadata = { title: "Empresas" };
export const dynamic = "force-dynamic";

type SP = Record<string, string | string[] | undefined>;

function toParams(sp: SP): URLSearchParams {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(sp)) {
    const v = Array.isArray(value) ? value[0] : value;
    if (v !== undefined && v !== "") params.set(key, v);
  }
  return params;
}

export default async function CompaniesPage({ searchParams }: { searchParams: Promise<SP> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const params = toParams(await searchParams);
  const parsed = companyFilterSchema.safeParse(Object.fromEntries(params.entries()));
  const f = parsed.success ? parsed.data : companyFilterSchema.parse({});

  const where = buildCompanyWhere(user.id, f);
  const [total, items] = await Promise.all([
    prisma.company.count({ where }),
    prisma.company.findMany({
      where,
      orderBy: buildCompanyOrderBy(f.sort),
      skip: (f.page - 1) * f.pageSize,
      take: f.pageSize,
      select: {
        id: true,
        name: true,
        category: true,
        city: true,
        state: true,
        phone: true,
        instagram: true,
        website: true,
        websiteStatus: true,
        leadScore: true,
        discoveredAt: true,
        lead: { select: { id: true, status: true } },
      },
    }),
  ]);
  const pages = Math.max(1, Math.ceil(total / f.pageSize));

  const hrefFor = (page: number) => {
    const p = new URLSearchParams(params);
    p.set("page", String(page));
    return `/companies?${p.toString()}`;
  };
  const exportParams = new URLSearchParams(params);
  exportParams.delete("page");
  const exportHref = `/api/export/csv?${exportParams.toString()}`;
  const hasFilters = Array.from(params.keys()).some((k) => k !== "page");

  return (
    <div className="space-y-5">
      <PageHeader
        title="Empresas encontradas"
        subtitle="Resultados das suas pesquisas. Filtre, ordene por Lead Score e salve as melhores como leads."
        actions={
          <a href={exportHref} className="btn-ghost">
            <IconDownload width={16} height={16} />
            Exportar CSV
          </a>
        }
      />

      <form method="get" action="/companies" className="card card-pad space-y-4">
        {f.searchId ? <input type="hidden" name="searchId" value={f.searchId} /> : null}
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <label className="label" htmlFor="q">
              Nome
            </label>
            <input id="q" name="q" className="input" defaultValue={f.q ?? ""} placeholder="Buscar pelo nome" />
          </div>
          <div>
            <label className="label" htmlFor="segment">
              Segmento / categoria
            </label>
            <input id="segment" name="segment" className="input" defaultValue={f.segment ?? ""} placeholder="Ex.: pizzaria" />
          </div>
          <div>
            <label className="label" htmlFor="city">
              Cidade
            </label>
            <input id="city" name="city" className="input" defaultValue={f.city ?? ""} />
          </div>
          <div>
            <label className="label" htmlFor="state">
              Estado
            </label>
            <select id="state" name="state" className="input" defaultValue={f.state ?? ""}>
              <option value="">Todos</option>
              {BR_STATES.map((s) => (
                <option key={s.uf} value={s.uf}>
                  {s.uf}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="status">
              Situação do site
            </label>
            <select id="status" name="status" className="input" defaultValue={f.status ?? ""}>
              <option value="">Todas</option>
              {WEBSITE_STATUSES.map((s) => (
                <option key={s} value={s}>
                  {WEBSITE_STATUS_LABELS[s]}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="minScore">
              Lead Score mínimo
            </label>
            <select id="minScore" name="minScore" className="input" defaultValue={f.minScore !== undefined ? String(f.minScore) : ""}>
              <option value="">Qualquer</option>
              <option value="40">40+ (moderada ou melhor)</option>
              <option value="60">60+ (boa ou melhor)</option>
              <option value="80">80+ (prioritária)</option>
            </select>
          </div>
          <div>
            <label className="label" htmlFor="sort">
              Ordenar por
            </label>
            <select id="sort" name="sort" className="input" defaultValue={f.sort}>
              <option value="score_desc">Maior pontuação</option>
              <option value="recent">Mais recentes</option>
              <option value="reviews">Mais avaliações</option>
              <option value="name">Nome (A–Z)</option>
            </select>
          </div>
          <div className="flex flex-wrap items-end gap-x-4 gap-y-2 pb-2 text-sm text-zinc-300">
            <label className="flex items-center gap-2">
              <input type="checkbox" name="onlyNoSite" value="1" defaultChecked={f.onlyNoSite} className="accent-electric-500" />
              Só sem site
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" name="hasPhone" value="1" defaultChecked={f.hasPhone} className="accent-electric-500" />
              Com telefone
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" name="hasInstagram" value="1" defaultChecked={f.hasInstagram} className="accent-electric-500" />
              Com Instagram
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" name="onlyLeads" value="1" defaultChecked={f.onlyLeads} className="accent-electric-500" />
              Só leads
            </label>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button type="submit" className="btn-primary">
            Aplicar filtros
          </button>
          {hasFilters ? (
            <Link href="/companies" className="btn-ghost">
              Limpar
            </Link>
          ) : null}
          {f.searchId ? <span className="badge border-electric-500/30 text-electric-300">Filtrando por uma pesquisa específica</span> : null}
        </div>
      </form>

      {items.length === 0 ? (
        <EmptyState
          title={hasFilters ? "Nenhuma empresa com esses filtros" : "Nenhuma empresa ainda"}
          text={hasFilters ? "Tente remover alguns filtros." : "Faça uma pesquisa para trazer estabelecimentos reais do Google Places."}
          href={hasFilters ? "/companies" : "/search"}
          cta={hasFilters ? "Limpar filtros" : "Nova pesquisa"}
        />
      ) : (
        <>
          <div className="card overflow-x-auto">
            <table className="w-full min-w-[980px] border-collapse">
              <thead className="border-b border-white/[0.06]">
                <tr>
                  <th className="th">Empresa</th>
                  <th className="th">Categoria</th>
                  <th className="th">Cidade</th>
                  <th className="th">Telefone</th>
                  <th className="th">Instagram</th>
                  <th className="th">Site</th>
                  <th className="th">Situação</th>
                  <th className="th">Score</th>
                  <th className="th">Descoberta</th>
                  <th className="th">Lead</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.05]">
                {items.map((c) => (
                  <tr key={c.id} className="hover:bg-white/[0.02]">
                    <td className="td max-w-[240px]">
                      <Link href={`/companies/${c.id}`} className="block truncate font-medium text-zinc-100 hover:text-electric-300">
                        {c.name}
                      </Link>
                    </td>
                    <td className="td max-w-[160px] truncate">{c.category ?? <span className="text-zinc-600">Não informado</span>}</td>
                    <td className="td whitespace-nowrap">
                      {c.city ? `${c.city}${c.state ? ` - ${c.state}` : ""}` : <span className="text-zinc-600">Não informado</span>}
                    </td>
                    <td className="td whitespace-nowrap">{c.phone ?? <span className="text-zinc-600">Não informado</span>}</td>
                    <td className="td max-w-[150px] truncate">
                      {c.instagram ? (
                        <a href={c.instagram} target="_blank" rel="noopener noreferrer" className="text-electric-300 hover:underline">
                          {instagramHandle(c.instagram)}
                        </a>
                      ) : (
                        <span className="text-zinc-600">Não informado</span>
                      )}
                    </td>
                    <td className="td max-w-[170px] truncate">
                      {c.website ? (
                        <a href={c.website} target="_blank" rel="noopener noreferrer" className="text-electric-300 hover:underline">
                          {stripProtocol(c.website)}
                        </a>
                      ) : (
                        <span className="text-zinc-600">Não informado</span>
                      )}
                    </td>
                    <td className="td">
                      <WebsiteBadge status={c.websiteStatus} />
                    </td>
                    <td className="td">
                      <ScoreBadge score={c.leadScore} />
                    </td>
                    <td className="td whitespace-nowrap text-zinc-500">{formatDate(c.discoveredAt)}</td>
                    <td className="td">
                      <SaveLeadButton companyId={c.id} lead={c.lead} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pagination page={f.page} pages={pages} total={total} pageSize={f.pageSize} hrefFor={hrefFor} />
        </>
      )}
    </div>
  );
}
