import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { AiPanel } from "@/components/AiPanel";
import { IconExternal } from "@/components/Icons";
import { RecheckButton } from "@/components/RecheckButton";
import { SaveLeadButton } from "@/components/SaveLeadButton";
import { Notice, PageHeader, ScoreBadge, WebsiteBadge } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { VERIFICATION_LABELS } from "@/lib/constants";
import { getAiConfig } from "@/lib/env";
import { formatDateTime, instagramHandle, stripProtocol } from "@/lib/format";
import { isLikelyBrazilMobile, toBrazilDigits, whatsappLink } from "@/lib/phone";
import { getCompanyDetail } from "@/lib/queries";

export const metadata: Metadata = { title: "Detalhes da empresa" };
export const dynamic = "force-dynamic";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="text-xs text-zinc-500">{label}</dt>
      <dd className="mt-0.5 break-words text-sm text-zinc-200">{children}</dd>
    </div>
  );
}

const NA = <span className="text-zinc-600">Não informado</span>;

function ext(url: string, label: string) {
  return (
    <a href={url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-electric-300 hover:underline">
      {label}
      <IconExternal width={12} height={12} />
    </a>
  );
}

export default async function CompanyPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const { id } = await params;

  const detail = await getCompanyDetail(user.id, id);
  if (!detail) notFound();
  const { company, score } = detail;
  const ai = getAiConfig();

  const whatsappDigits = company.whatsapp ?? (isLikelyBrazilMobile(company.phone) ? toBrazilDigits(company.phone) : null);
  const manualWa = whatsappLink(whatsappDigits);
  const phoneDigits = toBrazilDigits(company.phone);

  return (
    <div className="space-y-6">
      <p className="text-sm">
        <Link href="/companies" className="text-zinc-500 hover:text-zinc-300">
          ← Empresas
        </Link>
      </p>

      <PageHeader
        title={company.name}
        subtitle={[company.category, [company.neighborhood, company.city, company.state].filter(Boolean).join(", ")].filter(Boolean).join(" · ")}
        actions={
          <>
            <WebsiteBadge status={company.websiteStatus} />
            <ScoreBadge score={company.leadScore} />
          </>
        }
      />

      <div className="flex flex-wrap items-center gap-3">
        <SaveLeadButton companyId={company.id} lead={company.lead ? { id: company.lead.id, status: company.lead.status } : null} size="md" />
        <RecheckButton companyId={company.id} />
        {company.mapsUrl ? (
          <a href={company.mapsUrl} target="_blank" rel="noopener noreferrer" className="btn-ghost">
            <IconExternal width={16} height={16} />
            Ver no Google Maps
          </a>
        ) : null}
        {manualWa ? (
          <a href={manualWa} target="_blank" rel="noopener noreferrer" className="btn-ghost">
            <IconExternal width={16} height={16} />
            Abrir WhatsApp
          </a>
        ) : null}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <section className="card card-pad lg:col-span-2">
          <h2 className="mb-4 text-sm font-semibold text-white">Dados da empresa</h2>
          <dl className="grid gap-4 sm:grid-cols-2">
            <Field label="Nome comercial">{company.name}</Field>
            <Field label="Categoria">{company.category ?? NA}</Field>
            <Field label="Endereço">{company.address ?? NA}</Field>
            <Field label="Cidade / Estado">{company.city ? `${company.city}${company.state ? ` - ${company.state}` : ""}` : NA}</Field>
            <Field label="Telefone">
              {company.phone ? (
                <>
                  {company.phone}
                  {phoneDigits ? (
                    <a href={`tel:+${phoneDigits}`} className="ml-2 text-xs text-electric-300 hover:underline">
                      ligar
                    </a>
                  ) : null}
                </>
              ) : (
                NA
              )}
            </Field>
            <Field label="WhatsApp (divulgado publicamente)">
              {company.whatsapp ? ext(`https://wa.me/${company.whatsapp}`, company.whatsapp) : NA}
            </Field>
            <Field label="Instagram">{company.instagram ? ext(company.instagram, instagramHandle(company.instagram)) : NA}</Field>
            <Field label="Facebook">{company.facebook ? ext(company.facebook, stripProtocol(company.facebook)) : NA}</Field>
            <Field label="Site oficial">{company.website ? ext(company.website, stripProtocol(company.website)) : NA}</Field>
            <Field label="Avaliação no Google">
              {company.rating !== null ? `${company.rating.toFixed(1).replace(".", ",")} ★ (${company.ratingCount ?? 0} avaliações)` : NA}
            </Field>
            <Field label="Fonte">{company.source}</Field>
            <Field label="Descoberta em">{formatDateTime(company.discoveredAt)}</Field>
            <Field label="Dados do Google atualizados em">{formatDateTime(company.dataRefreshedAt)}</Field>
            <Field label="Pesquisa de origem">
              {company.search ? (
                <Link href={`/companies?searchId=${company.search.id}`} className="text-electric-300 hover:underline">
                  {company.search.query}
                </Link>
              ) : (
                NA
              )}
            </Field>
          </dl>
        </section>

        <section className="card card-pad">
          <h2 className="mb-1 text-sm font-semibold text-white">Lead Score</h2>
          <p className="mb-4 text-xs text-zinc-500">{score.tierLabel}</p>
          <p className="mb-4 text-4xl font-semibold tracking-tight text-electric-300">
            {score.score}
            <span className="text-lg text-zinc-600">/100</span>
          </p>
          <ul className="space-y-2.5">
            {score.breakdown.map((b) => (
              <li key={b.key}>
                <div className="mb-1 flex justify-between text-xs">
                  <span className="text-zinc-400">{b.label}</span>
                  <span className="font-mono text-zinc-500">
                    {b.points}/{b.max}
                  </span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
                  <div className="h-full rounded-full bg-electric-500" style={{ width: `${b.max ? (b.points / b.max) * 100 : 0}%` }} />
                </div>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-xs text-zinc-500">Heurística de priorização. Não garante interesse comercial.</p>
        </section>
      </div>

      <section className="card card-pad space-y-3">
        <h2 className="text-sm font-semibold text-white">Verificação do site</h2>
        <div className="flex flex-wrap items-center gap-3">
          <WebsiteBadge status={company.websiteStatus} />
          <span className="text-xs text-zinc-500">
            Verificado em {formatDateTime(company.websiteCheckedAt)} ·{" "}
            {company.verificationMethod ? (VERIFICATION_LABELS[company.verificationMethod] ?? company.verificationMethod) : "método não informado"}
          </span>
        </div>
        {company.websiteNote ? <p className="text-sm text-zinc-300">{company.websiteNote}</p> : null}
        <Notice tone="info">
          Ausência de site cadastrado não é certeza de que a empresa não tem site. Use &ldquo;Reverificar&rdquo; para refazer a checagem e confirme
          manualmente antes de abordar.
        </Notice>
      </section>

      <AiPanel
        companyId={company.id}
        aiConfigured={ai.configured}
        aiLabel={`${ai.provider} · ${ai.model}`}
        whatsappDigits={whatsappDigits}
        instagramUrl={company.instagram}
      />
    </div>
  );
}
