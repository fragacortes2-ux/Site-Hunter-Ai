import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { DeleteAccount } from "@/components/DeleteAccount";
import { Notice, PageHeader } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { allowRegistration, getIntegrationStatus } from "@/lib/env";
import { formatDate } from "@/lib/format";
import { prisma } from "@/lib/db";

export const metadata: Metadata = { title: "Configurações" };
export const dynamic = "force-dynamic";

function Row({ label, ok, detail }: { label: string; ok: boolean; detail: string }) {
  return (
    <li className="flex flex-wrap items-start justify-between gap-2 py-3">
      <div>
        <p className="text-sm font-medium text-zinc-100">{label}</p>
        <p className="mt-0.5 text-xs text-zinc-500">{detail}</p>
      </div>
      <span
        className={`badge ${ok ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-300" : "border-amber-500/30 bg-amber-500/10 text-amber-300"}`}
      >
        {ok ? "Configurado" : "Não configurado"}
      </span>
    </li>
  );
}

export default async function SettingsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const s = getIntegrationStatus();
  const record = await prisma.user.findUnique({ where: { id: user.id }, select: { createdAt: true } });

  return (
    <div className="space-y-6">
      <PageHeader title="Configurações" subtitle="Estado das integrações, limites de uso e privacidade. Chaves de API nunca são exibidas aqui." />

      <section className="card card-pad">
        <h2 className="text-sm font-semibold text-white">Integrações (arquivo .env)</h2>
        <ul className="mt-2 divide-y divide-white/[0.06]">
          <Row label="Login seguro (AUTH_SECRET)" ok={s.authSecret} detail="Segredo de pelo menos 32 caracteres para assinar as sessões." />
          <Row
            label="Google Places API (GOOGLE_PLACES_API_KEY)"
            ok={s.places}
            detail="Obrigatória para pesquisar empresas. Sem ela, nenhuma pesquisa é feita e nenhum dado é inventado."
          />
          <Row
            label="Busca extra de sites"
            ok={s.searchConfigured}
            detail={
              s.searchProvider === "none"
                ? "Desativada (SEARCH_PROVIDER=none): a situação “sem site” vale só para o cadastro do Google."
                : `Provedor: ${s.searchProvider}.`
            }
          />
          <Row
            label="Inteligência artificial"
            ok={s.aiConfigured}
            detail={`Provedor: ${s.aiProvider} · modelo: ${s.aiModel}. Necessária para análises e mensagens.`}
          />
        </ul>
        <p className="mt-3 text-xs text-zinc-500">Depois de editar o .env, pare e inicie o servidor novamente.</p>
      </section>

      <section className="card card-pad">
        <h2 className="mb-3 text-sm font-semibold text-white">Limites de uso (controle de custos)</h2>
        <dl className="grid gap-3 text-sm sm:grid-cols-2 lg:grid-cols-3">
          <div>
            <dt className="text-xs text-zinc-500">Pesquisas por usuário em 24 h</dt>
            <dd className="text-zinc-200">{s.limits.maxSearchesPerDay}</dd>
          </div>
          <div>
            <dt className="text-xs text-zinc-500">Resultados por pesquisa</dt>
            <dd className="text-zinc-200">{s.limits.maxResultsPerSearch}</dd>
          </div>
          <div>
            <dt className="text-xs text-zinc-500">Requisições ao Google por mês (total)</dt>
            <dd className="text-zinc-200">{s.limits.maxPlacesRequestsPerMonth}</dd>
          </div>
          <div>
            <dt className="text-xs text-zinc-500">Gerações de IA em 24 h</dt>
            <dd className="text-zinc-200">{s.limits.maxAiCallsPerDay}</dd>
          </div>
          <div>
            <dt className="text-xs text-zinc-500">Buscas extras por pesquisa</dt>
            <dd className="text-zinc-200">{s.limits.searchVerifyMaxPerSearch}</dd>
          </div>
          <div>
            <dt className="text-xs text-zinc-500">Cadastro de novos usuários</dt>
            <dd className="text-zinc-200">{allowRegistration() ? "Aberto" : "Desativado"}</dd>
          </div>
        </dl>
      </section>

      <section className="card card-pad space-y-3">
        <h2 className="text-sm font-semibold text-white">Privacidade e LGPD</h2>
        <ul className="list-disc space-y-1.5 pl-5 text-sm text-zinc-400">
          <li>O sistema usa apenas dados comerciais publicados no cadastro público de empresas do Google Places e em páginas públicas verificadas.</li>
          <li>
            Empresas que você não salvou como lead são apagadas automaticamente {s.limits.retentionDays > 0 ? `após ${s.limits.retentionDays} dias` : "(retenção desativada)"}{" "}
            sem atualização, para respeitar os termos do Google.
          </li>
          <li>Nenhuma mensagem é enviada automaticamente. Você revisa e envia cada contato manualmente, respeitando quem pedir para não ser contatado.</li>
        </ul>
        <Notice tone="info">
          Conta criada em {formatDate(record?.createdAt)}. Você pode excluir a conta e todos os dados associados a qualquer momento.
        </Notice>
        <DeleteAccount />
      </section>
    </div>
  );
}
