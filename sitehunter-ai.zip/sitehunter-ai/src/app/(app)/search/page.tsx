import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { SearchForm } from "@/components/SearchForm";
import { Notice, PageHeader } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { getIntegrationStatus } from "@/lib/env";
import { placesRequestsThisMonth } from "@/lib/limits";

export const metadata: Metadata = { title: "Nova pesquisa" };
export const dynamic = "force-dynamic";

type SP = Record<string, string | string[] | undefined>;
const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";

export default async function SearchPage({ searchParams }: { searchParams: Promise<SP> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const sp = await searchParams;
  const status = getIntegrationStatus();

  const [usedToday, usedMonth] = await Promise.all([
    prisma.search.count({ where: { userId: user.id, createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } } }),
    placesRequestsThisMonth(),
  ]);
  const { maxSearchesPerDay, maxResultsPerSearch, maxPlacesRequestsPerMonth } = status.limits;
  const blockedByLimit = usedToday >= maxSearchesPerDay || usedMonth >= maxPlacesRequestsPerMonth;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Nova pesquisa"
        subtitle="Busque estabelecimentos reais no Google Places e verifique automaticamente quais não têm um site oficial identificado."
      />

      {!status.places ? (
        <Notice tone="error">
          <strong>Google Places não configurado.</strong> Sem a chave <code className="font-mono">GOOGLE_PLACES_API_KEY</code> o sistema não inventa
          resultados: a pesquisa fica desativada. Siga o passo a passo do README (seção &ldquo;Configurar o Google Places&rdquo;), salve a chave no arquivo{" "}
          <code className="font-mono">.env</code> e reinicie o servidor.
        </Notice>
      ) : null}

      {blockedByLimit ? (
        <Notice tone="warn">
          Limite de uso atingido ({usedToday}/{maxSearchesPerDay} pesquisas em 24 h; {usedMonth}/{maxPlacesRequestsPerMonth} requisições ao Google no mês).
          Ajuste os limites no <code className="font-mono">.env</code> se quiser continuar.
        </Notice>
      ) : null}

      <SearchForm
        disabled={!status.places || blockedByLimit}
        defaults={{
          segment: first(sp.segment),
          companyName: first(sp.companyName),
          city: first(sp.city),
          state: first(sp.state),
          neighborhood: first(sp.neighborhood),
          radiusKm: first(sp.radiusKm),
        }}
      />

      <section className="card card-pad text-sm text-zinc-400">
        <h2 className="mb-2 text-sm font-semibold text-white">Como funciona e quais são os limites</h2>
        <ul className="list-disc space-y-1.5 pl-5">
          <li>
            Cada pesquisa traz até <strong className="text-zinc-200">{maxResultsPerSearch}</strong> estabelecimentos (o Google entrega no máximo 60 por busca) e
            usa 1 a 3 requisições ao Google.
          </li>
          <li>
            Você já fez <strong className="text-zinc-200">{usedToday}</strong> de {maxSearchesPerDay} pesquisas nas últimas 24 h. Uso mensal do Google nesta
            instalação: {usedMonth}/{maxPlacesRequestsPerMonth} requisições.
          </li>
          <li>
            &ldquo;Sem site identificado&rdquo; significa que nenhum site próprio foi localizado nas fontes consultadas
            {status.searchConfigured ? ` (Google Places + ${status.searchProvider})` : " (somente Google Places, pois a busca extra não está ativa)"}. Não é
            prova de que o negócio não tenha site.
          </li>
          <li>
            O Google cobra por requisição. Configure orçamento e cotas no Google Cloud (veja o README) e consulte os preços vigentes.{" "}
            <Link href="/settings" className="text-electric-300 hover:underline">
              Ver estado das integrações
            </Link>
            .
          </li>
        </ul>
      </section>
    </div>
  );
}
