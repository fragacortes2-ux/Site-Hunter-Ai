// Geração de CSV (módulo puro, testado em tests/csv.test.ts).
// Separador ";" e BOM UTF-8 para abrir corretamente no Excel em português.
// Células que começam com = + - @ são prefixadas com apóstrofo para evitar injeção de fórmulas.

export type CsvColumn<T> = {
  header: string;
  value: (row: T) => string | number | boolean | Date | null | undefined;
};

export function escapeCsvCell(input: string | number | boolean | Date | null | undefined): string {
  if (input === null || input === undefined) return "";
  let s = input instanceof Date ? input.toISOString() : String(input);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  if (/[";\r\n]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
  return s;
}

export function toCsv<T>(rows: T[], columns: CsvColumn<T>[]): string {
  const head = columns.map((c) => escapeCsvCell(c.header)).join(";");
  const body = rows.map((row) => columns.map((c) => escapeCsvCell(c.value(row))).join(";"));
  return "﻿" + [head, ...body].join("\r\n") + "\r\n";
}
