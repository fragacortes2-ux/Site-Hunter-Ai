// Utilitários de telefone brasileiro (módulo puro, testado em tests/phone.test.ts).

/** Retorna só os dígitos com DDI 55 (ex.: "5511987654321") ou null se não parecer um telefone BR válido. */
export function toBrazilDigits(phone: string | null | undefined): string | null {
  if (!phone) return null;
  let d = phone.replace(/\D/g, "");
  d = d.replace(/^0+/, "");
  if (d.startsWith("55") && (d.length === 12 || d.length === 13)) return d;
  if (d.length === 10 || d.length === 11) return "55" + d;
  return null;
}

/** Celular brasileiro: DDD + 9 dígitos começando por 9. Só celulares costumam ter WhatsApp. */
export function isLikelyBrazilMobile(phone: string | null | undefined): boolean {
  const d = toBrazilDigits(phone);
  if (!d) return false;
  const local = d.slice(2);
  return local.length === 11 && local[2] === "9";
}

/** Link wa.me para o usuário abrir manualmente a conversa (nunca é enviado automaticamente). */
export function whatsappLink(digits: string | null | undefined, text?: string): string | null {
  const d = (digits ?? "").replace(/\D/g, "");
  if (d.length < 10) return null;
  const base = `https://wa.me/${d}`;
  return text ? `${base}?text=${encodeURIComponent(text)}` : base;
}
