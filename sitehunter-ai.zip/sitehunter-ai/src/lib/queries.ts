// Consultas compartilhadas entre páginas (Server Components) e rotas de API.
import { prisma } from "@/lib/db";
import { computeLeadScore } from "@/lib/score";
import { dayKey } from "@/lib/format";

export async function getCompanyDetail(userId: string, id: string) {
  const company = await prisma.company.findFirst({
    where: { id, userId },
    include: {
      lead: { include: { reminders: { orderBy: [{ done: "asc" }, { dueAt: "asc" }] } } },
      search: { select: { id: true, query: true, createdAt: true } },
    },
  });
  if (!company) return null;
  const score = computeLeadScore({
    websiteStatus: company.websiteStatus,
    phone: company.phone,
    whatsapp: company.whatsapp,
    instagram: company.instagram,
    facebook: company.facebook,
    ratingCount: company.ratingCount,
    rating: company.rating,
    segment: company.segment,
    category: company.category,
    address: company.address,
    mapsUrl: company.mapsUrl,
  });
  return { company, score };
}

export async function getDashboardStats(userId: string) {
  const since = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
  const now = new Date();
  const weekAhead = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

  const [byStatus, priority, good, moderate, low, searchCount, resultsAgg, leadsByStatus, recentSearches, reminders, top] =
    await Promise.all([
      prisma.company.groupBy({ by: ["websiteStatus"], where: { userId }, _count: { _all: true } }),
      prisma.company.count({ where: { userId, leadScore: { gte: 80 } } }),
      prisma.company.count({ where: { userId, leadScore: { gte: 60, lt: 80 } } }),
      prisma.company.count({ where: { userId, leadScore: { gte: 40, lt: 60 } } }),
      prisma.company.count({ where: { userId, leadScore: { lt: 40 } } }),
      prisma.search.count({ where: { userId } }),
      prisma.search.aggregate({ where: { userId }, _sum: { resultCount: true } }),
      prisma.lead.groupBy({ by: ["status"], where: { userId }, _count: { _all: true } }),
      prisma.search.findMany({ where: { userId, createdAt: { gte: since } }, select: { createdAt: true } }),
      prisma.reminder.findMany({
        where: { userId, done: false, dueAt: { lte: weekAhead } },
        orderBy: { dueAt: "asc" },
        take: 8,
        include: { lead: { select: { id: true, company: { select: { id: true, name: true } } } } },
      }),
      prisma.company.findMany({
        where: { userId, websiteStatus: "NO_SITE" },
        orderBy: [{ leadScore: "desc" }, { discoveredAt: "desc" }],
        take: 5,
        select: { id: true, name: true, city: true, state: true, category: true, leadScore: true, phone: true },
      }),
    ]);

  const statusCount = (s: string) => byStatus.find((b) => b.websiteStatus === s)?._count._all ?? 0;
  const noSite = statusCount("NO_SITE");
  const hasSite = statusCount("HAS_SITE");
  const unavailable = statusCount("UNAVAILABLE");
  const pending = statusCount("PENDING");
  const total = noSite + hasSite + unavailable + pending;

  const days: { key: string; count: number }[] = [];
  for (let i = 13; i >= 0; i -= 1) {
    days.push({ key: dayKey(new Date(Date.now() - i * 24 * 60 * 60 * 1000)), count: 0 });
  }
  for (const s of recentSearches) {
    const k = dayKey(s.createdAt);
    const slot = days.find((d) => d.key === k);
    if (slot) slot.count += 1;
  }

  return {
    total,
    noSite,
    hasSite,
    unavailable,
    pending,
    noSiteRate: total > 0 ? noSite / total : 0,
    priority,
    tiers: { priority, good, moderate, low },
    searchCount,
    resultsReturned: resultsAgg._sum.resultCount ?? 0,
    leadsByStatus: Object.fromEntries(leadsByStatus.map((l) => [l.status, l._count._all])) as Record<string, number>,
    searchesPerDay: days,
    reminders: reminders.map((r) => ({
      id: r.id,
      dueAt: r.dueAt,
      note: r.note,
      overdue: r.dueAt < now,
      companyId: r.lead.company.id,
      companyName: r.lead.company.name,
    })),
    top,
  };
}
