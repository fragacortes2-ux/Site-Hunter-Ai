// Lead Score — módulo puro (sem dependências), testado em tests/score.test.ts.
//
// Pontuação 0–100. Não é garantia de interesse comercial: é uma heurística para
// ordenar a fila de prospecção. Pesos (soma máxima = 100):
//   Situação do site ........ até 40  (sem site 40 · indisponível 30 · pendente 12 · possui 0)
//   Telefone público ........ 15
//   Instagram ............... 8
//   WhatsApp público ........ 4
//   Avaliações (volume) ..... até 15
//   Relevância do segmento .. até 8
//   Qualidade dos dados ..... até 10
// Empresas com site confirmado têm a pontuação limitada a 25 (baixa prioridade).

export type WebsiteStatusValue = "NO_SITE" | "HAS_SITE" | "UNAVAILABLE" | "PENDING";

export type LeadScoreInput = {
  websiteStatus: WebsiteStatusValue;
  phone?: string | null;
  whatsapp?: string | null;
  instagram?: string | null;
  facebook?: string | null;
  ratingCount?: number | null;
  rating?: number | null;
  segment?: string | null;
  category?: string | null;
  address?: string | null;
  mapsUrl?: string | null;
};

export type ScoreTier = "PRIORITY" | "GOOD" | "MODERATE" | "LOW";

export type ScoreBreakdownItem = {
  key: string;
  label: string;
  points: number;
  max: number;
};

export type LeadScoreResult = {
  score: number;
  tier: ScoreTier;
  tierLabel: string;
  breakdown: ScoreBreakdownItem[];
};

export const HAS_SITE_SCORE_CAP = 25;

export function normalizeText(value: string | null | undefined): string {
  return (value ?? "")
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .trim();
}

const HIGH_RELEVANCE = [
  "restaurante",
  "pizzaria",
  "barbearia",
  "barber",
  "salao",
  "beleza",
  "cabeleireir",
  "estetica",
  "clinica",
  "dentista",
  "odonto",
  "academia",
  "oficina",
  "mecanica",
  "petshop",
  "pet shop",
  "veterinari",
  "advogad",
  "contabil",
];

const MEDIUM_RELEVANCE = [
  "loja",
  "roupa",
  "boutique",
  "mercado",
  "padaria",
  "imobiliaria",
  "prestador",
  "servico",
  "cafe",
  "lanchonete",
  "bar",
  "autopecas",
];

export function segmentRelevance(segment?: string | null, category?: string | null): number {
  const text = `${normalizeText(segment)} ${normalizeText(category)}`;
  if (!text.trim()) return 4;
  if (HIGH_RELEVANCE.some((k) => text.includes(k))) return 8;
  if (MEDIUM_RELEVANCE.some((k) => text.includes(k))) return 6;
  return 4;
}

export function reviewsPoints(ratingCount?: number | null): number {
  const n = ratingCount ?? 0;
  if (n >= 200) return 15;
  if (n >= 100) return 13;
  if (n >= 50) return 11;
  if (n >= 20) return 8;
  if (n >= 10) return 6;
  if (n >= 3) return 3;
  return 0;
}

export function sitePoints(status: WebsiteStatusValue): number {
  switch (status) {
    case "NO_SITE":
      return 40;
    case "UNAVAILABLE":
      return 30;
    case "PENDING":
      return 12;
    case "HAS_SITE":
    default:
      return 0;
  }
}

export function dataQualityPoints(input: LeadScoreInput): number {
  let pts = 0;
  if (input.address) pts += 3;
  if (input.category) pts += 2;
  if (input.rating != null) pts += 2;
  if (input.mapsUrl) pts += 1;
  const channels = [input.phone, input.whatsapp, input.instagram, input.facebook].filter(Boolean).length;
  if (channels >= 2) pts += 2;
  return pts;
}

export function tierFromScore(score: number): { tier: ScoreTier; label: string } {
  if (score >= 80) return { tier: "PRIORITY", label: "Oportunidade prioritária" };
  if (score >= 60) return { tier: "GOOD", label: "Boa oportunidade" };
  if (score >= 40) return { tier: "MODERATE", label: "Oportunidade moderada" };
  return { tier: "LOW", label: "Baixa prioridade" };
}

export function computeLeadScore(input: LeadScoreInput): LeadScoreResult {
  const breakdown: ScoreBreakdownItem[] = [
    { key: "site", label: "Situação do site", points: sitePoints(input.websiteStatus), max: 40 },
    { key: "phone", label: "Telefone público", points: input.phone ? 15 : 0, max: 15 },
    { key: "instagram", label: "Instagram", points: input.instagram ? 8 : 0, max: 8 },
    { key: "whatsapp", label: "WhatsApp público", points: input.whatsapp ? 4 : 0, max: 4 },
    { key: "reviews", label: "Volume de avaliações", points: reviewsPoints(input.ratingCount), max: 15 },
    {
      key: "segment",
      label: "Relevância do segmento",
      points: segmentRelevance(input.segment, input.category),
      max: 8,
    },
    { key: "quality", label: "Qualidade das informações", points: dataQualityPoints(input), max: 10 },
  ];

  let score = breakdown.reduce((sum, item) => sum + item.points, 0);
  if (input.websiteStatus === "HAS_SITE") score = Math.min(score, HAS_SITE_SCORE_CAP);
  score = Math.max(0, Math.min(100, Math.round(score)));

  const { tier, label } = tierFromScore(score);
  return { score, tier, tierLabel: label, breakdown };
}
