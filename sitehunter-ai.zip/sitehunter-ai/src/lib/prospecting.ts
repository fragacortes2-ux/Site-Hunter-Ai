// Núcleo de prospecção: busca no Google Places, verificação de site, Lead Score e gravação.
import { prisma } from "@/lib/db";
import { ApiError } from "@/lib/http";
import { getLimits, getSearchProvider, isPlacesConfigured } from "@/lib/env";
import {
  assertPlacesBudget,
  assertSearchAllowed,
  purgeExpiredCompanies,
  recordPlacesUsage,
} from "@/lib/limits";
import { geocodeWithPlaces, getPlaceDetails, searchPlacesText, type LatLng, type PlaceRecord } from "@/lib/places";
import { checkReachable } from "@/lib/siteVerifier";
import { webSearch } from "@/lib/webSearch";
import { classifyUrl, extractSocials, pickCandidatesFromSearch, type Socials } from "@/lib/siteClassifier";
import { computeLeadScore, type WebsiteStatusValue } from "@/lib/score";
import type { SearchInput } from "@/lib/validators";

type Outcome = {
  websiteStatus: WebsiteStatusValue;
  website: string | null;
  socials: Socials;
  note: string;
  method: string;
};

type PlacesPhase = { done: true; outcome: Outcome } | { done: false; socials: Socials; reason: string };

function mergeSocials(a: Socials, b: Socials): Socials {
  return {
    instagram: a.instagram ?? b.instagram,
    facebook: a.facebook ?? b.facebook,
    whatsapp: a.whatsapp ?? b.whatsapp,
  };
}

export async function mapPool<T, R>(items: T[], limit: number, fn: (item: T, index: number) => Promise<R>): Promise<R[]> {
  const results = new Array<R>(items.length);
  let next = 0;
  async function worker(): Promise<void> {
    while (true) {
      const i = next;
      next += 1;
      if (i >= items.length) return;
      results[i] = await fn(items[i], i);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => worker()));
  return results;
}

/** Fase 1: usa o endereço cadastrado no Google Places e valida se ele responde. */
async function verifyFromPlaces(websiteUri: string | null): Promise<PlacesPhase> {
  const socials = extractSocials([websiteUri]);
  const c = classifyUrl(websiteUri);

  if (c.kind === "official" && c.url) {
    const r = await checkReachable(c.url);
    if (r.state === "ok") {
      const finalKind = classifyUrl(r.finalUrl ?? c.url);
      if (finalKind.kind !== "official") {
        return {
          done: false,
          socials: mergeSocials(socials, extractSocials([r.finalUrl])),
          reason: "O endereço cadastrado no Google redireciona para rede social/diretório, não para um site próprio.",
        };
      }
      return {
        done: true,
        outcome: {
          websiteStatus: "HAS_SITE",
          website: c.url,
          socials,
          note: `Site informado no Google Places. ${r.note}`,
          method: "places+http",
        },
      };
    }
    if (r.state === "unavailable") {
      return {
        done: true,
        outcome: {
          websiteStatus: "UNAVAILABLE",
          website: c.url,
          socials,
          note: `Site informado no Google Places, mas inacessível: ${r.note}`,
          method: "places+http",
        },
      };
    }
    return {
      done: true,
      outcome: {
        websiteStatus: "PENDING",
        website: c.url,
        socials,
        note: `Site informado no Google Places; não foi possível confirmar: ${r.note}`,
        method: "places+http",
      },
    };
  }

  let reason = "Nenhum site cadastrado no Google Places.";
  if (c.kind === "social") reason = "O endereço cadastrado no Google é rede social/agregador de links, não um site próprio.";
  else if (c.kind === "directory") reason = "O endereço cadastrado no Google é de diretório/plataforma, não um site próprio.";
  return { done: false, socials, reason };
}

/** Fase 2: sem site no Google — tenta confirmar por mecanismo de busca (se configurado). */
async function verifyBySearch(
  name: string,
  city: string | null,
  socials: Socials,
  reason: string,
  canSearch: boolean,
): Promise<Outcome> {
  const provider = getSearchProvider();

  if (provider.name === "none" || !provider.configured) {
    return {
      websiteStatus: "NO_SITE",
      website: null,
      socials,
      method: "places-only",
      note: `${reason} Sem verificação por busca configurada: confirme manualmente antes de abordar.`,
    };
  }
  if (!canSearch) {
    return {
      websiteStatus: "PENDING",
      website: null,
      socials,
      method: "places-only",
      note: `${reason} Limite de consultas de busca desta pesquisa atingido; use "Reverificar" depois.`,
    };
  }

  try {
    const results = await webSearch(`"${name}" ${city ?? ""}`.trim());
    const pick = pickCandidatesFromSearch(results, name);
    const merged: Socials = {
      instagram: socials.instagram ?? pick.instagram,
      facebook: socials.facebook ?? pick.facebook,
      whatsapp: socials.whatsapp,
    };

    if (pick.official) {
      const r = await checkReachable(pick.official.url);
      const note = `Site candidato encontrado por busca (${provider.name}): ${pick.official.host}. Confirme se é o site oficial. ${r.note}`;
      const status: WebsiteStatusValue =
        r.state === "ok" ? "HAS_SITE" : r.state === "unavailable" ? "UNAVAILABLE" : "PENDING";
      return { websiteStatus: status, website: pick.official.url, socials: merged, method: "search+http", note };
    }

    return {
      websiteStatus: "NO_SITE",
      website: null,
      socials: merged,
      method: "places+search",
      note: `${reason} A busca (${provider.name}) também não encontrou site oficial.`,
    };
  } catch (e) {
    const msg = e instanceof Error ? e.message : "erro desconhecido";
    return {
      websiteStatus: "PENDING",
      website: null,
      socials,
      method: "places+search-error",
      note: `${reason} Falha na verificação por busca: ${msg}`,
    };
  }
}

export function buildTextQuery(i: SearchInput): string {
  const what = [i.companyName, i.segment].filter(Boolean).join(" ");
  const where = [i.neighborhood, i.city, i.state].filter(Boolean).join(", ");
  return `${what} em ${where}`;
}

type CompanyFields = {
  name: string;
  category: string | null;
  segment: string | null;
  address: string | null;
  neighborhood: string | null;
  city: string | null;
  state: string | null;
  phone: string | null;
  whatsapp: string | null;
  instagram: string | null;
  facebook: string | null;
  website: string | null;
  websiteStatus: WebsiteStatusValue;
  websiteNote: string;
  websiteCheckedAt: Date;
  verificationMethod: string;
  rating: number | null;
  ratingCount: number | null;
  mapsUrl: string | null;
  source: string;
  leadScore: number;
  dataRefreshedAt: Date;
};

function fieldsFrom(place: PlaceRecord, outcome: Outcome, segment: string | null): CompanyFields {
  const leadScore = computeLeadScore({
    websiteStatus: outcome.websiteStatus,
    phone: place.phone,
    whatsapp: outcome.socials.whatsapp,
    instagram: outcome.socials.instagram,
    facebook: outcome.socials.facebook,
    ratingCount: place.ratingCount,
    rating: place.rating,
    segment,
    category: place.category,
    address: place.address,
    mapsUrl: place.mapsUrl,
  }).score;

  const now = new Date();
  return {
    name: place.name,
    category: place.category,
    segment,
    address: place.address,
    neighborhood: place.neighborhood,
    city: place.city,
    state: place.state,
    phone: place.phone,
    whatsapp: outcome.socials.whatsapp,
    instagram: outcome.socials.instagram,
    facebook: outcome.socials.facebook,
    website: outcome.website,
    websiteStatus: outcome.websiteStatus,
    websiteNote: outcome.note,
    websiteCheckedAt: now,
    verificationMethod: outcome.method,
    rating: place.rating,
    ratingCount: place.ratingCount,
    mapsUrl: place.mapsUrl,
    source: "Google Places",
    leadScore,
    dataRefreshedAt: now,
  };
}

export type SearchSummary = {
  searchId: string;
  total: number;
  newCount: number;
  noSite: number;
  hasSite: number;
  unavailable: number;
  pending: number;
  placesRequests: number;
  searchVerification: string;
  warning: string | null;
};

export async function runSearch(userId: string, input: SearchInput): Promise<SearchSummary> {
  if (!isPlacesConfigured()) {
    throw new ApiError(503, "GOOGLE_PLACES_API_KEY não configurada. Veja o README (seção Google Places).");
  }
  const limits = getLimits();
  const maxResults = limits.maxResultsPerSearch;
  const estimated = Math.ceil(maxResults / 20) + (input.radiusKm ? 1 : 0);
  await assertSearchAllowed(userId, estimated);
  await purgeExpiredCompanies(userId);

  const textQuery = buildTextQuery(input);
  let requests = 0;
  let center: LatLng | null = null;
  if (input.radiusKm) {
    const locationText = [input.neighborhood, input.city, input.state, "Brasil"].filter(Boolean).join(", ");
    center = await geocodeWithPlaces(locationText);
    requests += 1;
  }

  const found = await searchPlacesText({
    textQuery,
    maxResults,
    center,
    radiusMeters: input.radiusKm ? input.radiusKm * 1000 : undefined,
  });
  requests += found.requests;
  const places = found.places;

  // Fase 1 (em paralelo): site cadastrado no Google + teste HTTP.
  const phase1 = await mapPool(places, 6, (p) => verifyFromPlaces(p.websiteUri));

  // Fase 2 (sequencial, respeitando limite de consultas): busca extra para quem não tem site próprio.
  const provider = getSearchProvider();
  let budget = limits.searchVerifyMaxPerSearch;
  const outcomes: Outcome[] = [];
  for (let i = 0; i < places.length; i += 1) {
    const p1 = phase1[i];
    if (p1.done) {
      outcomes.push(p1.outcome);
      continue;
    }
    const canSearch = budget > 0;
    if (canSearch && provider.configured) budget -= 1;
    outcomes.push(await verifyBySearch(places[i].name, places[i].city, p1.socials, p1.reason, canSearch));
  }

  const search = await prisma.search.create({
    data: {
      userId,
      query: textQuery,
      segment: input.segment ?? null,
      companyName: input.companyName ?? null,
      city: input.city,
      state: input.state ?? null,
      neighborhood: input.neighborhood ?? null,
      radiusKm: input.radiusKm ?? null,
      resultCount: places.length,
      noSiteCount: outcomes.filter((o) => o.websiteStatus === "NO_SITE").length,
      placesRequests: requests,
    },
  });

  const existing = await prisma.company.findMany({
    where: { userId, placeId: { in: places.map((p) => p.placeId) } },
    select: { placeId: true, instagram: true, facebook: true, whatsapp: true },
  });
  const existingIds = new Set(existing.map((e) => e.placeId));
  type KnownSocials = { instagram: string | null; facebook: string | null; whatsapp: string | null };
  const existingByPlace = new Map<string, KnownSocials>(existing.map((e): [string, KnownSocials] => [e.placeId, e]));
  const segmentLabel = input.segment ?? null;

  if (places.length > 0) {
    await prisma.$transaction(
      places.map((p, i) => {
        // Não apaga redes sociais/WhatsApp já encontrados em pesquisas ou reverificações anteriores.
        const prev = existingByPlace.get(p.placeId);
        const outcome: Outcome = prev
          ? {
              ...outcomes[i],
              socials: {
                instagram: outcomes[i].socials.instagram ?? prev.instagram,
                facebook: outcomes[i].socials.facebook ?? prev.facebook,
                whatsapp: outcomes[i].socials.whatsapp ?? prev.whatsapp,
              },
            }
          : outcomes[i];
        const f = fieldsFrom(p, outcome, segmentLabel);
        return prisma.company.upsert({
          where: { userId_placeId: { userId, placeId: p.placeId } },
          create: { userId, searchId: search.id, placeId: p.placeId, ...f },
          update: { ...f, segment: f.segment ?? undefined, searchId: search.id },
        });
      }),
    );
  }

  const count = (s: WebsiteStatusValue) => outcomes.filter((o) => o.websiteStatus === s).length;
  const searchVerification =
    provider.name === "none"
      ? "Somente Google Places (busca extra desativada)"
      : provider.configured
        ? `Google Places + ${provider.name}`
        : `Busca extra (${provider.name}) sem chave configurada`;

  return {
    searchId: search.id,
    total: places.length,
    newCount: places.filter((p) => !existingIds.has(p.placeId)).length,
    noSite: count("NO_SITE"),
    hasSite: count("HAS_SITE"),
    unavailable: count("UNAVAILABLE"),
    pending: count("PENDING"),
    placesRequests: requests,
    searchVerification,
    warning: found.partialError
      ? `Resultados parciais: ${found.partialError}`
      : places.length === 0
        ? "O Google não retornou estabelecimentos para esta combinação. Tente outro segmento ou região."
        : null,
  };
}

/** Atualiza os dados do Google (Place Details) e refaz a verificação do site de uma empresa. */
export async function recheckCompany(userId: string, companyId: string) {
  const company = await prisma.company.findFirst({ where: { id: companyId, userId } });
  if (!company) throw new ApiError(404, "Empresa não encontrada.");

  let place: PlaceRecord | null = null;
  let placeGone = false;
  if (isPlacesConfigured()) {
    await assertPlacesBudget(1);
    place = await getPlaceDetails(company.placeId);
    await recordPlacesUsage(userId, "place_details", 1);
    placeGone = place === null;
  }

  const websiteUri = place?.websiteUri ?? company.website;
  const phase1 = await verifyFromPlaces(websiteUri);
  const outcome: Outcome = phase1.done
    ? phase1.outcome
    : await verifyBySearch(place?.name ?? company.name, place?.city ?? company.city, phase1.socials, phase1.reason, true);

  const merged: Socials = {
    instagram: outcome.socials.instagram ?? company.instagram,
    facebook: outcome.socials.facebook ?? company.facebook,
    whatsapp: outcome.socials.whatsapp ?? company.whatsapp,
  };

  const next = {
    name: place?.name ?? company.name,
    category: place?.category ?? company.category,
    address: place?.address ?? company.address,
    neighborhood: place?.neighborhood ?? company.neighborhood,
    city: place?.city ?? company.city,
    state: place?.state ?? company.state,
    phone: place?.phone ?? company.phone,
    rating: place ? place.rating : company.rating,
    ratingCount: place ? place.ratingCount : company.ratingCount,
    mapsUrl: place?.mapsUrl ?? company.mapsUrl,
  };

  const leadScore = computeLeadScore({
    websiteStatus: outcome.websiteStatus,
    phone: next.phone,
    whatsapp: merged.whatsapp,
    instagram: merged.instagram,
    facebook: merged.facebook,
    ratingCount: next.ratingCount,
    rating: next.rating,
    segment: company.segment,
    category: next.category,
    address: next.address,
    mapsUrl: next.mapsUrl,
  }).score;

  const note = placeGone
    ? `${outcome.note} Atenção: o local não foi encontrado no Google (pode ter sido removido).`
    : outcome.note;

  const now = new Date();
  return prisma.company.update({
    where: { id: company.id },
    data: {
      ...next,
      whatsapp: merged.whatsapp,
      instagram: merged.instagram,
      facebook: merged.facebook,
      website: outcome.website,
      websiteStatus: outcome.websiteStatus,
      websiteNote: note,
      websiteCheckedAt: now,
      verificationMethod: outcome.method,
      leadScore,
      dataRefreshedAt: place ? now : company.dataRefreshedAt,
    },
  });
}
