// Leitura centralizada das variáveis de ambiente. Só roda no servidor.

function intEnv(name: string, fallback: number, min: number, max: number): number {
  const raw = process.env[name];
  const n = raw ? Number.parseInt(raw, 10) : Number.NaN;
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

export function getLimits() {
  return {
    maxSearchesPerDay: intEnv("MAX_SEARCHES_PER_DAY", 15, 1, 1000),
    maxResultsPerSearch: intEnv("MAX_RESULTS_PER_SEARCH", 40, 1, 60),
    maxPlacesRequestsPerMonth: intEnv("MAX_PLACES_REQUESTS_PER_MONTH", 2000, 1, 1_000_000),
    maxAiCallsPerDay: intEnv("MAX_AI_CALLS_PER_DAY", 60, 1, 10_000),
    searchVerifyMaxPerSearch: intEnv("SEARCH_VERIFY_MAX_PER_SEARCH", 30, 0, 200),
    retentionDays: intEnv("GOOGLE_DATA_RETENTION_DAYS", 30, 0, 3650),
  };
}

export function isPlacesConfigured(): boolean {
  return Boolean(process.env.GOOGLE_PLACES_API_KEY);
}

export type SearchProviderName = "none" | "brave" | "google_cse";

export function getSearchProvider(): { name: SearchProviderName; configured: boolean } {
  const raw = (process.env.SEARCH_PROVIDER || "none").trim().toLowerCase();
  if (raw === "brave") {
    return { name: "brave", configured: Boolean(process.env.BRAVE_SEARCH_API_KEY) };
  }
  if (raw === "google_cse") {
    return {
      name: "google_cse",
      configured: Boolean(process.env.GOOGLE_CSE_API_KEY) && Boolean(process.env.GOOGLE_CSE_ID),
    };
  }
  return { name: "none", configured: false };
}

export type AiProviderName = "openai" | "anthropic" | "openai_compatible";

export type AiConfig = {
  provider: AiProviderName;
  model: string;
  apiKey: string;
  baseUrl: string;
  configured: boolean;
};

export function getAiConfig(): AiConfig {
  const raw = (process.env.AI_PROVIDER || "openai").trim().toLowerCase();
  const provider: AiProviderName =
    raw === "anthropic" ? "anthropic" : raw === "openai_compatible" ? "openai_compatible" : "openai";

  let apiKey = "";
  let baseUrl = "https://api.openai.com/v1";
  let defaultModel = "gpt-4o-mini";

  if (provider === "openai") {
    apiKey = process.env.OPENAI_API_KEY || "";
  } else if (provider === "anthropic") {
    apiKey = process.env.ANTHROPIC_API_KEY || "";
    baseUrl = "https://api.anthropic.com/v1";
    defaultModel = "claude-haiku-5-5";
  } else {
    apiKey = process.env.AI_COMPATIBLE_API_KEY || "";
    baseUrl = (process.env.AI_BASE_URL || "").replace(/\/+$/, "");
  }

  const model = (process.env.AI_MODEL || "").trim() || defaultModel;
  const configured = Boolean(apiKey) && Boolean(model) && Boolean(baseUrl);
  return { provider, model, apiKey, baseUrl, configured };
}

export function allowRegistration(): boolean {
  return (process.env.ALLOW_REGISTRATION || "true").trim().toLowerCase() !== "false";
}

export function authSecretOk(): boolean {
  return (process.env.AUTH_SECRET || "").length >= 32;
}

/** Estado das integrações para exibir na interface (nunca expõe valores de chaves). */
export function getIntegrationStatus() {
  const search = getSearchProvider();
  const ai = getAiConfig();
  return {
    places: isPlacesConfigured(),
    searchProvider: search.name,
    searchConfigured: search.configured,
    aiProvider: ai.provider,
    aiModel: ai.model,
    aiConfigured: ai.configured,
    authSecret: authSecretOk(),
    limits: getLimits(),
  };
}
