import { z } from "zod";
import { LEAD_STATUSES } from "@/lib/constants";

const emptyToUndefined = (v: unknown) => (typeof v === "string" && v.trim() === "" ? undefined : v);

export const registerSchema = z.object({
  name: z.string().trim().min(2, "Informe seu nome.").max(80),
  email: z.string().trim().toLowerCase().email("E-mail inválido.").max(160),
  password: z
    .string()
    .min(10, "A senha precisa ter pelo menos 10 caracteres.")
    .max(100, "A senha pode ter no máximo 100 caracteres."),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("E-mail inválido.").max(160),
  password: z.string().min(1, "Informe a senha.").max(100),
});

export const searchSchema = z
  .object({
    segment: z.preprocess(emptyToUndefined, z.string().trim().max(80).optional()),
    companyName: z.preprocess(emptyToUndefined, z.string().trim().max(100).optional()),
    city: z.string().trim().min(2, "Informe a cidade.").max(80),
    state: z.preprocess(
      emptyToUndefined,
      z
        .string()
        .trim()
        .length(2, "Use a sigla do estado (ex.: SP).")
        .transform((s) => s.toUpperCase())
        .optional(),
    ),
    neighborhood: z.preprocess(emptyToUndefined, z.string().trim().max(80).optional()),
    radiusKm: z.preprocess(
      (v) => (v === "" || v === null ? undefined : v),
      z.coerce.number().int().min(1).max(50).optional(),
    ),
  })
  .refine((v) => Boolean(v.segment || v.companyName), {
    message: "Informe o segmento ou o nome da empresa.",
    path: ["segment"],
  });

export type SearchInput = z.infer<typeof searchSchema>;

export const leadCreateSchema = z.object({ companyId: z.string().min(1) });

export const leadPatchSchema = z.object({
  status: z.enum(LEAD_STATUSES).optional(),
  notes: z.string().max(5000).optional(),
  contactedAt: z
    .string()
    .datetime({ offset: true })
    .nullable()
    .optional(),
});

export const reminderCreateSchema = z.object({
  dueAt: z.string().datetime({ offset: true, message: "Data inválida." }),
  note: z.string().trim().min(1, "Descreva o lembrete.").max(300),
});

export const reminderPatchSchema = z.object({ done: z.boolean() });

export const aiSchema = z.object({
  companyId: z.string().min(1),
  kind: z.enum(["analysis", "whatsapp", "instagram", "site_models"]),
  tone: z.enum(["profissional", "amigavel", "direto"]).optional(),
  senderName: z.preprocess(emptyToUndefined, z.string().trim().max(80).optional()),
  agencyName: z.preprocess(emptyToUndefined, z.string().trim().max(80).optional()),
  offer: z.preprocess(emptyToUndefined, z.string().trim().max(400).optional()),
});

export const deleteAccountSchema = z.object({ password: z.string().min(1).max(100) });
