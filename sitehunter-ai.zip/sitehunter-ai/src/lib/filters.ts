import { z } from "zod";
import type { Prisma } from "@prisma/client";
import { WEBSITE_STATUSES } from "@/lib/constants";

const emptyToUndefined = (v: unknown) => (typeof v === "string" && v.trim() === "" ? undefined : v);
const flag = z.preprocess((v) => v === "1" || v === "true" || v === true, z.boolean());
const optStr = z.preprocess(emptyToUndefined, z.string().trim().max(100).optional());

export const companyFilterSchema = z.object({
  q: optStr,
  segment: optStr,
  city: optStr,
  state: optStr,
  searchId: optStr,
  status: z.preprocess(emptyToUndefined, z.enum(WEBSITE_STATUSES).optional()),
  minScore: z.preprocess(emptyToUndefined, z.coerce.number().int().min(0).max(100).optional()),
  onlyNoSite: flag,
  hasPhone: flag,
  hasInstagram: flag,
  onlyLeads: flag,
  sort: z.preprocess(emptyToUndefined, z.enum(["score_desc", "recent", "name", "reviews"]).default("score_desc")),
  page: z.preprocess(emptyToUndefined, z.coerce.number().int().min(1).max(10_000).default(1)),
  pageSize: z.preprocess(emptyToUndefined, z.coerce.number().int().min(1).max(100).default(20)),
});

export type CompanyFilters = z.infer<typeof companyFilterSchema>;

export function parseCompanyFilters(params: URLSearchParams): CompanyFilters {
  return companyFilterSchema.parse(Object.fromEntries(params.entries()));
}

export function buildCompanyWhere(userId: string, f: CompanyFilters): Prisma.CompanyWhereInput {
  const and: Prisma.CompanyWhereInput[] = [];

  if (f.q) and.push({ name: { contains: f.q, mode: "insensitive" } });
  if (f.segment) {
    and.push({
      OR: [
        { segment: { contains: f.segment, mode: "insensitive" } },
        { category: { contains: f.segment, mode: "insensitive" } },
      ],
    });
  }
  if (f.city) and.push({ city: { contains: f.city, mode: "insensitive" } });
  if (f.state) and.push({ state: { equals: f.state.toUpperCase() } });
  if (f.onlyNoSite) and.push({ websiteStatus: "NO_SITE" });
  else if (f.status) and.push({ websiteStatus: f.status });
  if (f.hasPhone) and.push({ phone: { not: null } });
  if (f.hasInstagram) and.push({ instagram: { not: null } });
  if (f.minScore !== undefined) and.push({ leadScore: { gte: f.minScore } });
  if (f.searchId) and.push({ searchId: f.searchId });
  if (f.onlyLeads) and.push({ lead: { isNot: null } });

  return { userId, ...(and.length ? { AND: and } : {}) };
}

export function buildCompanyOrderBy(sort: CompanyFilters["sort"]): Prisma.CompanyOrderByWithRelationInput[] {
  switch (sort) {
    case "recent":
      return [{ discoveredAt: "desc" }];
    case "name":
      return [{ name: "asc" }];
    case "reviews":
      return [{ ratingCount: { sort: "desc", nulls: "last" } }, { leadScore: "desc" }];
    case "score_desc":
    default:
      return [{ leadScore: "desc" }, { discoveredAt: "desc" }];
  }
}
