// Busca web opcional para verificação extra de sites (Brave Search API ou Google Programmable Search).
import { getSearchProvider } from "@/lib/env";
import type { SearchResultItem } from "@/lib/siteClassifier";

let lastCallAt = 0;
async function throttle(minIntervalMs: number): Promise<void> {
  const wait = lastCallAt + minIntervalMs - Date.now();
  if (wait > 0) await new Promise((r) => setTimeout(r, wait));
  lastCallAt = Date.now();
}

type BraveResponse = {
  web?: { results?: Array<{ url?: string; title?: string; description?: string }> };
};

type CseResponse = {
  items?: Array<{ link?: string; title?: string; snippet?: string }>;
  error?: { message?: string };
};

export async function webSearch(query: string): Promise<SearchResultItem[]> {
  const provider = getSearchProvider();
  if (!provider.configured) throw new Error("Provedor de busca não configurado.");

  if (provider.name === "brave") {
    // O plano gratuito da Brave limita a ~1 consulta por segundo.
    await throttle(1100);
    const params = new URLSearchParams({ q: query, country: "br", search_lang: "pt", count: "10" });
    const res = await fetch(`https://api.search.brave.com/res/v1/web/search?${params.toString()}`, {
      headers: {
        Accept: "application/json",
        "X-Subscription-Token": process.env.BRAVE_SEARCH_API_KEY || "",
      },
      signal: AbortSignal.timeout(15_000),
      cache: "no-store",
    });
    if (!res.ok) throw new Error(`Brave Search respondeu HTTP ${res.status}.`);
    const data = (await res.json()) as BraveResponse;
    return (data.web?.results ?? [])
      .filter((r): r is { url: string; title?: string; description?: string } => typeof r.url === "string")
      .map((r) => ({ url: r.url, title: r.title ?? null, snippet: r.description ?? null }));
  }

  if (provider.name === "google_cse") {
    await throttle(300);
    const params = new URLSearchParams({
      key: process.env.GOOGLE_CSE_API_KEY || "",
      cx: process.env.GOOGLE_CSE_ID || "",
      q: query,
      num: "10",
      gl: "br",
      lr: "lang_pt",
    });
    const res = await fetch(`https://www.googleapis.com/customsearch/v1?${params.toString()}`, {
      signal: AbortSignal.timeout(15_000),
      cache: "no-store",
    });
    const data = (await res.json().catch(() => ({}))) as CseResponse;
    if (!res.ok) throw new Error(`Google Custom Search respondeu HTTP ${res.status}. ${data.error?.message ?? ""}`.trim());
    return (data.items ?? [])
      .filter((r): r is { link: string; title?: string; snippet?: string } => typeof r.link === "string")
      .map((r) => ({ url: r.link, title: r.title ?? null, snippet: r.snippet ?? null }));
  }

  return [];
}
