// Formatação para a interface (funciona no servidor e no navegador).
export const APP_TIMEZONE = "America/Sao_Paulo";

type DateInput = Date | string | number | null | undefined;

export function formatDate(value: DateInput): string {
  if (!value) return "—";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "—";
  return new Intl.DateTimeFormat("pt-BR", { timeZone: APP_TIMEZONE, dateStyle: "short" }).format(d);
}

export function formatDateTime(value: DateInput): string {
  if (!value) return "—";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "—";
  return new Intl.DateTimeFormat("pt-BR", {
    timeZone: APP_TIMEZONE,
    dateStyle: "short",
    timeStyle: "short",
  }).format(d);
}

/** YYYY-MM-DD no fuso do app (usado para agrupar pesquisas por dia). */
export function dayKey(value: Date): string {
  return new Intl.DateTimeFormat("en-CA", { timeZone: APP_TIMEZONE }).format(value);
}

export function shortDayLabel(key: string): string {
  const [, m, d] = key.split("-");
  return `${d}/${m}`;
}

export function formatPercent(value: number): string {
  return `${(value * 100).toFixed(1).replace(".", ",")}%`;
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat("pt-BR").format(value);
}

export function stripProtocol(url: string | null | undefined): string {
  if (!url) return "";
  return url.replace(/^https?:\/\//i, "").replace(/\/$/, "");
}

/** Converte "YYYY-MM-DDTHH:mm" (input datetime-local, horário de Brasília) em ISO com fuso -03:00. */
export function localInputToIso(value: string): string {
  return `${value}:00-03:00`;
}

/** Converte uma data ISO para o formato do input datetime-local (horário de Brasília). */
export function isoToLocalInput(value: DateInput): string {
  if (!value) return "";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "";
  const parts = new Intl.DateTimeFormat("sv-SE", {
    timeZone: APP_TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).format(d);
  return parts.replace(" ", "T");
}

/** "https://www.instagram.com/minha_loja/" -> "@minha_loja" */
export function instagramHandle(url: string | null | undefined): string {
  if (!url) return "";
  const m = url.match(/instagram\.com\/([^/?#]+)/i);
  return m ? `@${m[1]}` : stripProtocol(url);
}
