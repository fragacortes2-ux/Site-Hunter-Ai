import { NextResponse, type NextRequest } from "next/server";
import { ZodError } from "zod";

export class ApiError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

export function json(data: unknown, status = 200): NextResponse {
  return NextResponse.json(data, { status, headers: { "Cache-Control": "no-store" } });
}

function errorResponse(e: unknown): NextResponse {
  if (e instanceof ApiError) {
    return json({ error: e.message }, e.status);
  }
  if (e instanceof ZodError) {
    const first = e.issues[0];
    const where = first && first.path.length ? `${first.path.join(".")}: ` : "";
    return json({ error: `${where}${first?.message ?? "Dados inválidos."}` }, 400);
  }
  console.error("[api] erro inesperado:", e);
  return json({ error: "Erro interno do servidor." }, 500);
}

/** Envolve um handler de rota sem parâmetros dinâmicos, tratando erros de forma padronizada. */
export function route(fn: (req: NextRequest) => Promise<Response>) {
  return async (req: NextRequest): Promise<Response> => {
    try {
      return await fn(req);
    } catch (e) {
      return errorResponse(e);
    }
  };
}

/** Envolve um handler de rota com parâmetros dinâmicos (Next.js 15: params é uma Promise). */
export function routeWithParams<P>(fn: (req: NextRequest, params: P) => Promise<Response>) {
  return async (req: NextRequest, ctx: { params: Promise<P> }): Promise<Response> => {
    try {
      return await fn(req, await ctx.params);
    } catch (e) {
      return errorResponse(e);
    }
  };
}

export async function readJson(req: NextRequest): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    throw new ApiError(400, "Corpo da requisição inválido (JSON esperado).");
  }
}
