import { prisma } from "@/lib/db";
import { ApiError } from "@/lib/http";
import { getLimits } from "@/lib/env";

const DAY_MS = 24 * 60 * 60 * 1000;

function monthStartUtc(): Date {
  const d = new Date();
  d.setUTCDate(1);
  d.setUTCHours(0, 0, 0, 0);
  return d;
}

/** Soma das requisições ao Google Places no mês corrente (todas as contas). */
export async function placesRequestsThisMonth(): Promise<number> {
  const since = monthStartUtc();
  const [searches, other] = await Promise.all([
    prisma.search.aggregate({ where: { createdAt: { gte: since } }, _sum: { placesRequests: true } }),
    prisma.placesUsage.aggregate({ where: { createdAt: { gte: since } }, _sum: { requests: true } }),
  ]);
  return (searches._sum.placesRequests ?? 0) + (other._sum.requests ?? 0);
}

export async function assertPlacesBudget(requestsNeeded: number): Promise<void> {
  const { maxPlacesRequestsPerMonth } = getLimits();
  const used = await placesRequestsThisMonth();
  if (used + requestsNeeded > maxPlacesRequestsPerMonth) {
    throw new ApiError(
      429,
      `Teto mensal de requisições ao Google Places atingido (${used}/${maxPlacesRequestsPerMonth}). Ajuste MAX_PLACES_REQUESTS_PER_MONTH se quiser continuar.`,
    );
  }
}

export async function recordPlacesUsage(userId: string, kind: string, requests: number): Promise<void> {
  await prisma.placesUsage.create({ data: { userId, kind, requests } });
}

/** Bloqueia a pesquisa se o usuário passou do limite diário ou se o teto mensal global do Google seria excedido. */
export async function assertSearchAllowed(userId: string, requestsNeeded: number): Promise<void> {
  const limits = getLimits();

  const last24h = await prisma.search.count({
    where: { userId, createdAt: { gte: new Date(Date.now() - DAY_MS) } },
  });
  if (last24h >= limits.maxSearchesPerDay) {
    throw new ApiError(
      429,
      `Limite de ${limits.maxSearchesPerDay} pesquisas nas últimas 24 horas atingido. Tente mais tarde ou ajuste MAX_SEARCHES_PER_DAY.`,
    );
  }

  await assertPlacesBudget(requestsNeeded);
}

export async function assertAiAllowed(userId: string): Promise<void> {
  const limits = getLimits();
  const count = await prisma.aiUsage.count({
    where: { userId, createdAt: { gte: new Date(Date.now() - DAY_MS) } },
  });
  if (count >= limits.maxAiCallsPerDay) {
    throw new ApiError(429, `Limite de ${limits.maxAiCallsPerDay} gerações de IA nas últimas 24 horas atingido.`);
  }
}

/** Remove dados do Google de empresas NÃO salvas como lead após o período de retenção. */
export async function purgeExpiredCompanies(userId: string): Promise<number> {
  const { retentionDays } = getLimits();
  if (retentionDays <= 0) return 0;
  const cutoff = new Date(Date.now() - retentionDays * DAY_MS);
  const res = await prisma.company.deleteMany({
    where: { userId, lead: { is: null }, dataRefreshedAt: { lt: cutoff } },
  });
  return res.count;
}
