export const BR_STATES: Array<{ uf: string; name: string }> = [
  { uf: "AC", name: "Acre" },
  { uf: "AL", name: "Alagoas" },
  { uf: "AP", name: "Amapá" },
  { uf: "AM", name: "Amazonas" },
  { uf: "BA", name: "Bahia" },
  { uf: "CE", name: "Ceará" },
  { uf: "DF", name: "Distrito Federal" },
  { uf: "ES", name: "Espírito Santo" },
  { uf: "GO", name: "Goiás" },
  { uf: "MA", name: "Maranhão" },
  { uf: "MT", name: "Mato Grosso" },
  { uf: "MS", name: "Mato Grosso do Sul" },
  { uf: "MG", name: "Minas Gerais" },
  { uf: "PA", name: "Pará" },
  { uf: "PB", name: "Paraíba" },
  { uf: "PR", name: "Paraná" },
  { uf: "PE", name: "Pernambuco" },
  { uf: "PI", name: "Piauí" },
  { uf: "RJ", name: "Rio de Janeiro" },
  { uf: "RN", name: "Rio Grande do Norte" },
  { uf: "RS", name: "Rio Grande do Sul" },
  { uf: "RO", name: "Rondônia" },
  { uf: "RR", name: "Roraima" },
  { uf: "SC", name: "Santa Catarina" },
  { uf: "SP", name: "São Paulo" },
  { uf: "SE", name: "Sergipe" },
  { uf: "TO", name: "Tocantins" },
];

export const SEGMENT_SUGGESTIONS = [
  "Restaurantes",
  "Pizzarias",
  "Barbearias",
  "Salões de beleza",
  "Oficinas mecânicas",
  "Lojas de roupas",
  "Clínicas",
  "Dentistas",
  "Academias",
  "Mercados",
  "Padarias",
  "Imobiliárias",
  "Prestadores de serviços",
  "Pet shops",
  "Escritórios de advocacia",
  "Clínicas de estética",
];

export const WEBSITE_STATUS_LABELS: Record<string, string> = {
  NO_SITE: "Sem site identificado",
  HAS_SITE: "Possui site",
  UNAVAILABLE: "Site indisponível",
  PENDING: "Verificação pendente",
};

export const LEAD_STATUS_LABELS: Record<string, string> = {
  NEW: "Novo",
  CONTACTED: "Contato realizado",
  INTERESTED: "Interessado",
  CLIENT: "Cliente",
  LOST: "Perdido",
};

export const LEAD_STATUSES = ["NEW", "CONTACTED", "INTERESTED", "CLIENT", "LOST"] as const;
export const WEBSITE_STATUSES = ["NO_SITE", "HAS_SITE", "UNAVAILABLE", "PENDING"] as const;

export const VERIFICATION_LABELS: Record<string, string> = {
  "places-only": "Somente cadastro do Google Places (sem busca extra)",
  "places+http": "Google Places + teste de acesso ao endereço",
  "places+search": "Google Places + busca extra na web",
  "search+http": "Busca extra na web + teste de acesso ao endereço",
  "places+search-error": "Google Places (a busca extra falhou)",
};
