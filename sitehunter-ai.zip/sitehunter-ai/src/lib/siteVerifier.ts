// Validação de URLs: verifica se um endereço responde, com proteção contra SSRF.
import dns from "node:dns/promises";
import net from "node:net";
import { isPrivateAddress } from "@/lib/ssrf";
import { normalizeUrl } from "@/lib/siteClassifier";

export type ReachState = "ok" | "unavailable" | "unknown";

export type ReachResult = {
  state: ReachState;
  httpStatus?: number;
  finalUrl?: string;
  note: string;
};

class BlockedHostError extends Error {}

async function assertPublicHost(hostname: string): Promise<void> {
  const host = hostname.replace(/^\[|\]$/g, "");
  if (net.isIP(host)) {
    if (isPrivateAddress(host)) throw new BlockedHostError("endereço interno");
    return;
  }
  const records = await dns.lookup(host, { all: true });
  if (records.length === 0) throw new BlockedHostError("sem endereço");
  if (records.some((r) => isPrivateAddress(r.address))) throw new BlockedHostError("endereço interno");
}

function errorCode(e: unknown): string {
  const err = e as { code?: string; cause?: { code?: string }; name?: string };
  return err?.cause?.code ?? err?.code ?? err?.name ?? "UNKNOWN";
}

const TLS_CODES = new Set([
  "CERT_HAS_EXPIRED",
  "DEPTH_ZERO_SELF_SIGNED_CERT",
  "SELF_SIGNED_CERT_IN_CHAIN",
  "UNABLE_TO_VERIFY_LEAF_SIGNATURE",
  "ERR_TLS_CERT_ALTNAME_INVALID",
  "UNABLE_TO_GET_ISSUER_CERT_LOCALLY",
]);

const REDIRECTS = new Set([301, 302, 303, 307, 308]);
const BOT_BLOCK_STATUSES = new Set([401, 403, 405, 406, 429, 451, 999]);

/**
 * Verifica se uma URL responde. Segue até 4 redirecionamentos (validando cada destino contra SSRF).
 * - ok: respondeu (inclui sites que bloqueiam robôs com 401/403/429 — o site existe)
 * - unavailable: domínio inexistente, conexão recusada, 404/410 ou erro 5xx
 * - unknown: tempo esgotado, erro de certificado ou falha ambígua (fica "verificação pendente")
 */
export async function checkReachable(rawUrl: string): Promise<ReachResult> {
  let url = normalizeUrl(rawUrl);
  if (!url) return { state: "unknown", note: "URL inválida." };

  for (let hop = 0; hop <= 4; hop += 1) {
    const u = new URL(url);

    try {
      await assertPublicHost(u.hostname);
    } catch (e) {
      if (e instanceof BlockedHostError) {
        return { state: "unknown", note: "Endereço bloqueado por segurança (rede interna)." };
      }
      const code = errorCode(e);
      if (code === "ENOTFOUND") return { state: "unavailable", note: "Domínio não encontrado (DNS)." };
      return { state: "unknown", note: `Falha ao resolver o domínio (${code}).` };
    }

    let res: Response;
    try {
      res = await fetch(url, {
        method: "GET",
        redirect: "manual",
        signal: AbortSignal.timeout(8000),
        cache: "no-store",
        headers: {
          "User-Agent": "Mozilla/5.0 (compatible; SiteHunterBot/1.0; verificacao de site comercial)",
          Accept: "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8",
          "Accept-Language": "pt-BR,pt;q=0.9",
        },
      });
    } catch (e) {
      const code = errorCode(e);
      if (code === "ENOTFOUND") return { state: "unavailable", note: "Domínio não encontrado (DNS)." };
      if (code === "ECONNREFUSED") return { state: "unavailable", note: "Conexão recusada pelo servidor." };
      if (TLS_CODES.has(code)) return { state: "unknown", note: "Certificado SSL inválido ou expirado." };
      if (code === "TimeoutError" || code === "AbortError" || code === "UND_ERR_CONNECT_TIMEOUT") {
        return { state: "unknown", note: "Tempo esgotado ao acessar o site." };
      }
      return { state: "unknown", note: `Falha ao acessar o site (${code}).` };
    }

    try {
      await res.body?.cancel();
    } catch {
      /* ignora */
    }

    if (REDIRECTS.has(res.status)) {
      const loc = res.headers.get("location");
      if (!loc) return { state: "unknown", httpStatus: res.status, note: "Redirecionamento sem destino." };
      let next: URL;
      try {
        next = new URL(loc, url);
      } catch {
        return { state: "unknown", httpStatus: res.status, note: "Redirecionamento inválido." };
      }
      if (next.protocol !== "http:" && next.protocol !== "https:") {
        return { state: "unknown", httpStatus: res.status, note: "Redirecionamento para protocolo não suportado." };
      }
      url = next.toString();
      continue;
    }

    if (res.status >= 200 && res.status < 300) {
      return { state: "ok", httpStatus: res.status, finalUrl: url, note: `Respondeu HTTP ${res.status}.` };
    }
    if (BOT_BLOCK_STATUSES.has(res.status)) {
      return {
        state: "ok",
        httpStatus: res.status,
        finalUrl: url,
        note: `O servidor respondeu HTTP ${res.status} (bloqueia verificação automática, mas existe).`,
      };
    }
    if (res.status === 404 || res.status === 410 || res.status >= 500) {
      return { state: "unavailable", httpStatus: res.status, finalUrl: url, note: `Respondeu HTTP ${res.status}.` };
    }
    return { state: "unknown", httpStatus: res.status, finalUrl: url, note: `Resposta inesperada HTTP ${res.status}.` };
  }

  return { state: "unknown", note: "Muitos redirecionamentos." };
}
