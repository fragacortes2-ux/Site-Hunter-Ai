// Integração com Google Places API (New) — https://places.googleapis.com/v1
// Documentação: https://developers.google.com/maps/documentation/places/web-service/text-search
import { ApiError } from "@/lib/http";

const BASE = "https://places.googleapis.com/v1";

export type PlaceRecord = {
  placeId: string;
  name: string;
  category: string | null;
  address: string | null;
  neighborhood: string | null;
  city: string | null;
  state: string | null;
  phone: string | null;
  websiteUri: string | null;
  rating: number | null;
  ratingCount: number | null;
  mapsUrl: string | null;
  businessStatus: string | null;
};

type GAddressComponent = { longText?: string; shortText?: string; types?: string[] };
type GPlace = {
  id?: string;
  displayName?: { text?: string };
  formattedAddress?: string;
  addressComponents?: GAddressComponent[];
  nationalPhoneNumber?: string;
  internationalPhoneNumber?: string;
  websiteUri?: string;
  rating?: number;
  userRatingCount?: number;
  primaryTypeDisplayName?: { text?: string };
  googleMapsUri?: string;
  businessStatus?: string;
  location?: { latitude?: number; longitude?: number };
};

const PLACE_FIELDS = [
  "id",
  "displayName",
  "formattedAddress",
  "addressComponents",
  "nationalPhoneNumber",
  "internationalPhoneNumber",
  "websiteUri",
  "rating",
  "userRatingCount",
  "primaryTypeDisplayName",
  "googleMapsUri",
  "businessStatus",
];

const SEARCH_FIELD_MASK = [...PLACE_FIELDS.map((f) => `places.${f}`), "nextPageToken"].join(",");
const DETAILS_FIELD_MASK = PLACE_FIELDS.join(",");

function apiKey(): string {
  const key = process.env.GOOGLE_PLACES_API_KEY;
  if (!key) {
    throw new ApiError(503, "GOOGLE_PLACES_API_KEY não configurada. Veja o README (seção Google Places).");
  }
  return key;
}

function googleError(status: number, body: unknown): ApiError {
  const err = (body as { error?: { message?: string; status?: string } } | null)?.error;
  const detail = err?.message ? ` Detalhe do Google: ${err.message.slice(0, 300)}` : "";
  if (status === 429) {
    return new ApiError(429, `Cota do Google Places excedida.${detail}`);
  }
  if (status === 400) {
    return new ApiError(502, `O Google recusou a requisição.${detail}`);
  }
  if (status === 401 || status === 403) {
    return new ApiError(
      502,
      `O Google negou o acesso. Confira se a "Places API (New)" está ativada, se a cobrança está habilitada no projeto e se as restrições da chave permitem esta API.${detail}`,
    );
  }
  return new ApiError(502, `Falha ao consultar o Google Places (HTTP ${status}).${detail}`);
}

async function placesFetch(path: string, init: RequestInit, fieldMask: string): Promise<unknown> {
  let res: Response;
  try {
    res = await fetch(`${BASE}${path}`, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": apiKey(),
        "X-Goog-FieldMask": fieldMask,
      },
      signal: AbortSignal.timeout(20_000),
      cache: "no-store",
    });
  } catch (e) {
    if (e instanceof ApiError) throw e;
    throw new ApiError(502, "Não foi possível conectar ao Google Places (rede ou tempo esgotado).");
  }
  const text = await res.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }
  if (!res.ok) {
    if (res.status === 404) return null;
    throw googleError(res.status, data);
  }
  return data;
}

function component(components: GAddressComponent[] | undefined, types: string[]): GAddressComponent | undefined {
  if (!components) return undefined;
  for (const t of types) {
    const found = components.find((c) => c.types?.includes(t));
    if (found) return found;
  }
  return undefined;
}

export function parsePlace(g: GPlace): PlaceRecord | null {
  if (!g.id || !g.displayName?.text) return null;
  const comps = g.addressComponents;
  const city = component(comps, ["administrative_area_level_2", "locality"])?.longText ?? null;
  const state = component(comps, ["administrative_area_level_1"])?.shortText ?? null;
  const neighborhood = component(comps, ["sublocality_level_1", "sublocality", "neighborhood"])?.longText ?? null;
  const phone = g.nationalPhoneNumber || g.internationalPhoneNumber || null;
  return {
    placeId: g.id,
    name: g.displayName.text,
    category: g.primaryTypeDisplayName?.text ?? null,
    address: g.formattedAddress ?? null,
    neighborhood,
    city,
    state,
    phone,
    websiteUri: g.websiteUri ?? null,
    rating: typeof g.rating === "number" ? g.rating : null,
    ratingCount: typeof g.userRatingCount === "number" ? g.userRatingCount : null,
    mapsUrl: g.googleMapsUri ?? null,
    businessStatus: g.businessStatus ?? null,
  };
}

export type LatLng = { latitude: number; longitude: number };

/** Obtém o ponto central de um local (usado só quando o usuário informa raio). Consome 1 requisição. */
export async function geocodeWithPlaces(locationText: string): Promise<LatLng | null> {
  const data = (await placesFetch(
    "/places:searchText",
    {
      method: "POST",
      body: JSON.stringify({ textQuery: locationText, languageCode: "pt-BR", regionCode: "BR", pageSize: 1 }),
    },
    "places.location",
  )) as { places?: GPlace[] } | null;
  const loc = data?.places?.[0]?.location;
  if (loc && typeof loc.latitude === "number" && typeof loc.longitude === "number") {
    return { latitude: loc.latitude, longitude: loc.longitude };
  }
  return null;
}

export type TextSearchOptions = {
  textQuery: string;
  maxResults: number;
  center?: LatLng | null;
  radiusMeters?: number;
};

export type TextSearchResult = {
  places: PlaceRecord[];
  requests: number;
  partialError: string | null;
};

/** Busca por texto com paginação (máx. 20 por página, 60 no total — limite do Google). */
export async function searchPlacesText(opts: TextSearchOptions): Promise<TextSearchResult> {
  const places: PlaceRecord[] = [];
  const seen = new Set<string>();
  let token: string | undefined;
  let requests = 0;
  let partialError: string | null = null;

  const baseBody: Record<string, unknown> = {
    textQuery: opts.textQuery,
    languageCode: "pt-BR",
    regionCode: "BR",
    pageSize: 20,
  };
  if (opts.center) {
    baseBody.locationBias = {
      circle: {
        center: { latitude: opts.center.latitude, longitude: opts.center.longitude },
        radius: Math.min(50_000, Math.max(100, opts.radiusMeters ?? 5000)),
      },
    };
  }

  while (places.length < opts.maxResults && requests < 3) {
    const body = token ? { ...baseBody, pageToken: token } : baseBody;
    let data: { places?: GPlace[]; nextPageToken?: string } | null;
    try {
      requests += 1;
      data = (await placesFetch(
        "/places:searchText",
        { method: "POST", body: JSON.stringify(body) },
        SEARCH_FIELD_MASK,
      )) as { places?: GPlace[]; nextPageToken?: string } | null;
    } catch (e) {
      if (requests === 1) throw e;
      partialError = e instanceof Error ? e.message : "Falha ao buscar a página seguinte.";
      break;
    }

    for (const g of data?.places ?? []) {
      const rec = parsePlace(g);
      if (!rec || seen.has(rec.placeId)) continue;
      if (rec.businessStatus === "CLOSED_PERMANENTLY") continue;
      seen.add(rec.placeId);
      places.push(rec);
      if (places.length >= opts.maxResults) break;
    }

    token = data?.nextPageToken;
    if (!token) break;
  }

  return { places, requests, partialError };
}

/** Atualiza os dados de um local pelo place_id (Place Details). Retorna null se o local não existir mais. */
export async function getPlaceDetails(placeId: string): Promise<PlaceRecord | null> {
  const data = (await placesFetch(
    `/places/${encodeURIComponent(placeId)}`,
    { method: "GET" },
    DETAILS_FIELD_MASK,
  )) as GPlace | null;
  if (!data) return null;
  return parsePlace(data);
}
