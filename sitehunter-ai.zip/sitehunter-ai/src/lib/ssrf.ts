// Proteção contra SSRF: impede que a verificação de sites acesse endereços internos.
import net from "node:net";

export function isPrivateAddress(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split(".").map(Number);
    return (
      a === 0 ||
      a === 10 ||
      a === 127 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 192 && b === 0) ||
      (a === 198 && (b === 18 || b === 19)) ||
      a >= 224
    );
  }
  if (net.isIPv6(ip)) {
    const l = ip.toLowerCase();
    if (l === "::1" || l === "::") return true;
    if (l.startsWith("::ffff:")) {
      const v4 = l.slice(7);
      return net.isIPv4(v4) ? isPrivateAddress(v4) : true;
    }
    return /^(fc|fd|fe8|fe9|fea|feb|ff)/.test(l);
  }
  return true;
}
