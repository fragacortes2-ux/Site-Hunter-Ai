// Classificação de URLs e correspondência de resultados de busca — módulo puro,
// sem dependências, testado em tests/siteClassifier.test.ts.
//
// Heurística: um endereço só é considerado "site oficial" quando NÃO é rede social,
// agregador de links, marketplace/delivery ou diretório. Isso evita tratar uma página
// de Instagram/Facebook cadastrada no Google como se fosse um site próprio.

export type UrlKind = "official" | "social" | "directory" | "invalid";
export type SocialPlatform = "instagram" | "facebook" | "whatsapp" | "other";

export type ClassifiedUrl = {
  kind: UrlKind;
  url: string | null;
  host: string | null;
  platform?: SocialPlatform;
};

const SOCIAL_DOMAINS: Array<[string, SocialPlatform]> = [
  ["instagram.com", "instagram"],
  ["instagr.am", "instagram"],
  ["facebook.com", "facebook"],
  ["fb.com", "facebook"],
  ["fb.me", "facebook"],
  ["wa.me", "whatsapp"],
  ["whatsapp.com", "whatsapp"],
  ["linktr.ee", "other"],
  ["beacons.ai", "other"],
  ["bio.link", "other"],
  ["lnk.bio", "other"],
  ["tiktok.com", "other"],
  ["youtube.com", "other"],
  ["youtu.be", "other"],
  ["twitter.com", "other"],
  ["x.com", "other"],
  ["linkedin.com", "other"],
  ["pinterest.com", "other"],
  ["t.me", "other"],
  ["threads.net", "other"],
];

const DIRECTORY_DOMAINS = [
  "google.com",
  "google.com.br",
  "goo.gl",
  "g.page",
  "g.co",
  "ifood.com.br",
  "rappi.com.br",
  "ubereats.com",
  "99food.com.br",
  "keeta.com",
  "anota.ai",
  "menudino.com",
  "tripadvisor.com",
  "tripadvisor.com.br",
  "yelp.com",
  "guiamais.com.br",
  "telelistas.net",
  "apontador.com.br",
  "foursquare.com",
  "booking.com",
  "airbnb.com.br",
  "olx.com.br",
  "mercadolivre.com.br",
  "reclameaqui.com.br",
  "econodata.com.br",
  "casadosdados.com.br",
  "cnpj.biz",
  "solutudo.com.br",
  "wikipedia.org",
  "doctoralia.com.br",
  "boaconsulta.com",
  "gympass.com",
  "wellhub.com",
  "vivareal.com.br",
  "zapimoveis.com.br",
];

function hostMatches(host: string, domain: string): boolean {
  return host === domain || host.endsWith("." + domain);
}

/** Normaliza uma URL: aceita "exemplo.com.br", exige http/https e remove espaços. */
export function normalizeUrl(raw: string | null | undefined): string | null {
  if (!raw) return null;
  let value = raw.trim();
  if (!value) return null;
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(value)) value = "https://" + value;
  try {
    const u = new URL(value);
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    if (!u.hostname || !u.hostname.includes(".")) return null;
    if (u.username || u.password) return null;
    return u.toString();
  } catch {
    return null;
  }
}

export function hostOf(url: string | null | undefined): string | null {
  const n = normalizeUrl(url);
  if (!n) return null;
  return new URL(n).hostname.toLowerCase().replace(/^www\./, "");
}

export function classifyUrl(raw: string | null | undefined): ClassifiedUrl {
  const url = normalizeUrl(raw);
  if (!url) return { kind: "invalid", url: null, host: null };
  const host = new URL(url).hostname.toLowerCase().replace(/^www\./, "");

  for (const [domain, platform] of SOCIAL_DOMAINS) {
    if (hostMatches(host, domain)) return { kind: "social", url, host, platform };
  }
  if (host === "api.whatsapp.com" || host === "chat.whatsapp.com") {
    return { kind: "social", url, host, platform: "whatsapp" };
  }
  for (const domain of DIRECTORY_DOMAINS) {
    if (hostMatches(host, domain)) return { kind: "directory", url, host };
  }
  return { kind: "official", url, host };
}

const INSTAGRAM_RESERVED = new Set([
  "p",
  "reel",
  "reels",
  "explore",
  "stories",
  "accounts",
  "tv",
  "direct",
  "about",
  "legal",
  "developer",
  "web",
  "share",
]);

const FACEBOOK_RESERVED = new Set([
  "sharer",
  "sharer.php",
  "share.php",
  "dialog",
  "plugins",
  "tr",
  "login",
  "login.php",
  "watch",
  "groups",
  "events",
  "marketplace",
  "policies",
  "help",
  "hashtag",
  "reel",
  "story.php",
  "photo",
  "photo.php",
  "permalink.php",
]);

function firstPathSegment(url: string): string | null {
  const seg = new URL(url).pathname.split("/").filter(Boolean)[0];
  return seg ? decodeURIComponent(seg) : null;
}

/** Retorna a URL de perfil do Instagram (https://www.instagram.com/usuario) ou null. */
export function instagramProfileUrl(raw: string | null | undefined): string | null {
  const c = classifyUrl(raw);
  if (c.kind !== "social" || c.platform !== "instagram" || !c.url) return null;
  const seg = firstPathSegment(c.url);
  if (!seg) return null;
  const handle = seg.replace(/^@/, "");
  if (INSTAGRAM_RESERVED.has(handle.toLowerCase())) return null;
  if (!/^[A-Za-z0-9._]{1,30}$/.test(handle)) return null;
  return `https://www.instagram.com/${handle}`;
}

/** Retorna a URL de página do Facebook ou null (ignora links de compartilhamento). */
export function facebookPageUrl(raw: string | null | undefined): string | null {
  const c = classifyUrl(raw);
  if (c.kind !== "social" || c.platform !== "facebook" || !c.url) return null;
  const seg = firstPathSegment(c.url);
  if (!seg) return null;
  if (FACEBOOK_RESERVED.has(seg.toLowerCase())) return null;
  const u = new URL(c.url);
  if (seg.toLowerCase() === "profile.php") {
    const id = u.searchParams.get("id");
    return id && /^\d+$/.test(id) ? `https://www.facebook.com/profile.php?id=${id}` : null;
  }
  return `https://www.facebook.com/${encodeURIComponent(seg)}`;
}

/**
 * Extrai o número de WhatsApp de links públicos (wa.me/55..., api.whatsapp.com/send?phone=55...).
 * Links "wa.me/message/XXXX" não contêm número e retornam null.
 */
export function whatsappNumberFromUrl(raw: string | null | undefined): string | null {
  const c = classifyUrl(raw);
  if (c.kind !== "social" || c.platform !== "whatsapp" || !c.url) return null;
  const u = new URL(c.url);
  let digits = "";
  if (c.host === "wa.me") {
    const seg = u.pathname.split("/").filter(Boolean)[0] ?? "";
    if (seg.toLowerCase() === "message") return null;
    digits = seg.replace(/\D/g, "");
  } else {
    const phone = u.searchParams.get("phone") ?? "";
    digits = phone.replace(/\D/g, "");
  }
  return digits.length >= 10 && digits.length <= 15 ? digits : null;
}

export type Socials = {
  instagram: string | null;
  facebook: string | null;
  whatsapp: string | null;
};

/** Extrai Instagram, Facebook e WhatsApp de uma lista de URLs públicas. */
export function extractSocials(urls: Array<string | null | undefined>): Socials {
  const out: Socials = { instagram: null, facebook: null, whatsapp: null };
  for (const raw of urls) {
    out.instagram ??= instagramProfileUrl(raw);
    out.facebook ??= facebookPageUrl(raw);
    out.whatsapp ??= whatsappNumberFromUrl(raw);
  }
  return out;
}

// ---------------------------------------------------------------------------
// Correspondência de resultados de busca com o nome da empresa
// ---------------------------------------------------------------------------

const STOPWORDS = new Set([
  "de", "da", "do", "das", "dos", "e", "the", "and", "ltda", "me", "eireli", "epp", "sa",
  "restaurante", "pizzaria", "barbearia", "barber", "shop", "salao", "clinica", "academia",
  "oficina", "mecanica", "loja", "lojas", "mercado", "padaria", "imobiliaria", "bar", "cafe",
  "studio", "estudio", "center", "centro", "petshop", "pet", "odontologia", "dentista",
  "consultorio", "auto", "autopecas", "lanchonete", "boutique", "advocacia", "contabilidade",
  "servicos", "salon", "beleza", "estetica", "express", "grupo",
]);

function strip(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase();
}

/** Palavras distintivas do nome comercial (sem acentos, sem termos genéricos). */
export function nameTokens(name: string): string[] {
  const tokens = strip(name)
    .replace(/[^a-z0-9]+/g, " ")
    .split(" ")
    .filter((t) => t.length >= 3 && !STOPWORDS.has(t));
  return Array.from(new Set(tokens)).slice(0, 4);
}

export type SearchResultItem = {
  url: string;
  title?: string | null;
  snippet?: string | null;
};

export type SearchPick = {
  official: { url: string; host: string } | null;
  instagram: string | null;
  facebook: string | null;
};

function hostSlug(host: string): string {
  const parts = host.split(".");
  // remove TLD e sufixos comuns (com.br, net.br, etc.)
  const cut = parts.length >= 3 && parts[parts.length - 2].length <= 3 ? 2 : 1;
  return strip(parts.slice(0, parts.length - cut).join("")).replace(/[^a-z0-9]/g, "");
}

function matchesName(slug: string, title: string, tokens: string[]): boolean {
  if (tokens.length === 0) return false;
  const inSlug = tokens.filter((t) => slug.includes(t));
  if (inSlug.length === 0) return false;
  const titleNorm = strip(title).replace(/[^a-z0-9]+/g, " ");
  const matched = tokens.filter((t) => slug.includes(t) || titleNorm.includes(t));
  return matched.length >= Math.min(2, tokens.length);
}

/**
 * Escolhe, entre resultados de uma busca, o provável site oficial e perfis sociais da empresa.
 * É conservador: exige que o domínio (ou o @ do perfil) contenha palavra do nome da empresa.
 * O resultado é um indício — o sistema registra o método e pede confirmação ao usuário.
 */
export function pickCandidatesFromSearch(results: SearchResultItem[], businessName: string): SearchPick {
  const tokens = nameTokens(businessName);
  const pick: SearchPick = { official: null, instagram: null, facebook: null };
  if (tokens.length === 0) return pick;

  for (const r of results) {
    const c = classifyUrl(r.url);
    if (c.kind === "invalid" || !c.url || !c.host) continue;
    const title = `${r.title ?? ""} ${r.snippet ?? ""}`;

    if (c.kind === "official") {
      if (!pick.official && matchesName(hostSlug(c.host), title, tokens)) {
        pick.official = { url: c.url, host: c.host };
      }
    } else if (c.kind === "social" && c.platform === "instagram") {
      const profile = instagramProfileUrl(c.url);
      if (profile && !pick.instagram) {
        const handle = strip(profile.split("/").pop() ?? "").replace(/[^a-z0-9]/g, "");
        if (matchesName(handle, title, tokens)) pick.instagram = profile;
      }
    } else if (c.kind === "social" && c.platform === "facebook") {
      const page = facebookPageUrl(c.url);
      if (page && !pick.facebook) {
        const handle = strip(decodeURIComponent(page.split("/").pop() ?? "")).replace(/[^a-z0-9]/g, "");
        if (matchesName(handle, title, tokens)) pick.facebook = page;
      }
    }
  }
  return pick;
}
